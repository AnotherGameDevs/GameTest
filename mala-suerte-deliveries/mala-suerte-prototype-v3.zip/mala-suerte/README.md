# Mala Suerte — prototype

Co-op Mexican folklore horror for 1–5 players. Godot **4.7** (Compatibility renderer).
Everything is greybox and placeholder audio. All the code works, so you can test the loops before making real art.

## Open it
1. Unzip, open Godot 4.7 → **Import** → pick `project.godot`.
2. Press **F5** (Run Project). The menu opens.
3. **Play solo** → pick a mode card → **Start the night**.

## Controls
| Key | Action |
|---|---|
| WASD | move |
| Shift | sprint (stamina) |
| C | crouch (quieter) |
| F | flashlight (battery) |
| E | interact / hold E for long actions / mash E when grabbed |
| G | drop held item |
| Tab | look at your secret Lotería card |
| M | map of the pueblo |
| Esc | pause menu (settings, bestiary, leave) |
| F1 | **dev menu** (solo / host) |
| F3 | debug info (creature states, noise, position; also shows creatures on the map) |
| F8 | write a quick playtest note |

As a ghost after dying: WASD fly, Shift up, C down.

## Solo playtesting tools
**Lobby → Playtest options**
- **Difficulty**: easy, normal or hard. This changes creature speed and aggression.
- **Get-up lives**: how many times you can hold E to pick yourself up when downed. Solo defaults to 1; 0 is hardcore.
- **Lotería card**: random, no card, or force a specific card to test it.
- **Seed**: type a number to replay the exact same night (same item spots, same Ofrenda guest, same Limpia curse).
- **Creatures**: turn each one on or off to test them in isolation.
- **Night length: Endless (practice)** never reaches dawn.

**F1 dev menu (in game)**
- Teleport to any area.
- Summon La Llorona, make La Lechuza whistle, wake La Mano, freeze all creatures.
- Add 30 minutes, jump to 5:50 AM, run at 1×, 2× or 4× speed, pause the objective.
- Bring the next objective item, matches or batteries to you.
- Reveal the answer (who the Ofrenda guest is, which creature cursed the Limpia).
- Swap your card live.
- God mode, noclip, revive, knock yourself down.
- Force a win or a loss.

**After every night**: the end screen shows your stats: distance walked, times downed and grabbed, close calls, notes read, items picked up. It also has **Replay same seed**. Every night is appended to `playtest_log.csv`, and F8 notes go to `playtest_notes.txt`. Both are in the folder that the **Open playtest log folder** button opens (Godot's `user://`).

**Bestiario**: from the menu, lobby or pause menu. It covers every creature's rule and how to survive it, all 8 cards, the 4 modes, and the controls.

## Test multiplayer on one PC
- Godot: **Debug → Customize Run Instances → Enable Multiple Instances → 2**, then F5.
- Window 1: **Host a game**. Window 2: IP `127.0.0.1` → **Join**.
- With friends: the host shares their IP (shown in the lobby). Same Wi-Fi works directly. Over the internet, forward UDP port **24567**, or use Tailscale / Radmin VPN / Hamachi. Steam lobbies come later.

## The 4 modes
| Mode | Goal | Lose if |
|---|---|---|
| **El Velorio** | Keep 6 candles around the body lit until 6 AM. Matches (cerillos) are hidden in the pueblo. | 1 or fewer candles lit for 20 s, or everyone down |
| **La Procesión** | Carry the coffin to the camposanto (north end of the road). Carrier is slow, no flashlight. Teammates within 3 m speed it up. | Dawn, or everyone down |
| **La Ofrenda** | Read 4 clue notes to work out who's coming home (3 possible people). Bring their 4 items to the altar in the casa. Wrong item = La Llorona hunts whoever placed it. | Dawn |
| **La Limpia** | Only ONE creature is out. Examine its signs, read the curandera's notebook in the troje, put egg + the right herb on the altar, then hold E for 8 s. | Dawn |

## Creatures (rules to learn)
- **La Llorona.** You hear her weeping from where she is. When it suddenly sounds far away and muffled, she has noticed you (the HUD says so too). Get out of her sight and keep quiet (crouch or stand still) for 3 s and she loses you. Staring at her, sprinting near her or letting her get close makes her charge: then sprint round a corner and crouch.
- **La Lechuza.** She whistles from rooftops. Don't look up at her while she whistles, or she marks you and dives. Only a roof over your head saves you.
- **La Mano Peluda.** Indoors, keep moving. Stand still on the floorboards about 3.5 s and it grabs your ankle. Mash E or get a friend to pull you free.

## Lotería cards (secret modifiers)
Drawn at the start of each night (1 or 2 each, set in the lobby). Only you see yours.
El Borracho (sway), La Luna (weak light), El Corazón (2× noise + heartbeat), El Diablito (hallucinations), La Muerte (no revive), El Alacrán (poisoned stamina), La Campana (bell rings when you sprint), La Sirena (voices call your name).
Add more in `player/cards.gd`.

## Where things are
| File | What it does |
|---|---|
| `main.gd` | menu ↔ game switching |
| `autoload/net.gd` | solo / host / join, lobby, card dealing |
| `autoload/settings.gd` | all settings (saved to `user://settings.cfg`) |
| `autoload/sfx.gd` | procedural placeholder sounds; swap in real audio here |
| `game.gd` | one night: spawns everything, the host is the referee (RPCs) |
| `world/map.gd` | the pueblo greybox: streets, houses with patios, tienda, plaza + capilla, troje, arroyo, camposanto. `house()` builds a whole house from a rectangle |
| `world/palette.gd` | materials (PS1 shader + generated noise textures) |
| `player/player.gd` | first-person controller, flashlight, stamina, card effects |
| `creatures/*.gd` | Llorona, Lechuza, Mano Peluda AI |
| `modes/*.gd` | the 4 game modes. Copy one to make a new mode |
| `ui/*.gd` | menu, lobby, settings, HUD, Lotería card drawing |
| `shaders/post.gdshader` | pixelation, dithering, brightness, damage/fear effects |
| `shaders/ps1.gdshader` | vertex wobble + nearest textures (mipmapped far away), depth bias for flat overlays |
| `tools/autotest.gd` | automated tests / screenshots (not used in normal play) |

### Swapping in your own models later
In `world/map.gd` each building is made from `box()` calls. Keep the boxes that have collision, but you can set their mesh invisible and drop your `.glb` model on top. The same goes for creatures: `build_visual()` in each creature script returns the look, so return your model instead.

## Automated tests (optional)
```
godot --path . -- --autotest=logic:velorio            (also procesion / ofrenda / limpia)
godot --path . -- --autotest=aisuite:llorona_nav      (she can reach every house, the troje, plaza, capilla, creek, camposanto...)
godot --path . -- --autotest=aisuite:llorona_behavior (notice/stalk/charge tells, hiding works, walking away doesn't, stare, catch, hearing)
godot --path . -- --autotest=navprobe                 (fast navmesh path check to every test spot)
godot --path . -- --autotest=shimmer                  (measures floor flicker while moving)
godot --path . -- --autotest=views --shots=/tmp/v     (aerial + street screenshots of the pueblo)
godot --path . -- --autotest=llshots --shots=/tmp/v   (screenshots of La Llorona's warnings)
godot --path . -- --autotest=aisuite:lechuza          (whistle cycle, marking, roof shelter, return to perch)
godot --path . -- --autotest=aisuite:mano             (every building, jittery network movement, struggle, cooldown)
godot --path . -- --autotest=aisuite:soak             (bot plays a whole night with all creatures)
godot --path . -- --autotest=aisuite:difficulty
godot --path . -- --autotest=mouse                    (real mouse input → camera)
godot --path . -- --autotest=tools                    (lobby options, dev menu, lives, log)
```
All of these pass as of this build.

## Changes in this build
- **Floor flicker fixed.** The PS1 vertex snap now skips vertices behind the camera (they smeared the big ground quads every frame), big surfaces are split into ~3 m pieces, far textures are mipmapped, and roads/water get a small depth bias so they never z-fight the ground. Measured over a slow strafe: sparkling ground pixels 1.26% → 0.30%. Also fixed: turning **Vertex wobble off in Settings made the whole world render black**.
- **The pueblo is compact and lived-in.** About 60 m from the casa to the camposanto gate (was 112 m), one main street with sidewalks and a cross street, houses wall to wall with patios and alleys behind them, a tienda, a plaza with a kiosk and the capilla, the troje with its gallinero, the arroyo along the west edge, utility poles, streetlights, parked trucks. No Día de Muertos dressing on the map itself.
- **La Llorona is readable.** See the Creatures section: one tell per state, a HUD line telling you when she has noticed YOU and what to do, a bar that fills while you hide, and "She lost you." when it worked.

## Known prototype limits
- Nobody can join mid-night. Card secrecy is UI-only (the data is sent to every client).
- Invincible mode only protects the host or a solo player.
- Pausing only freezes the game in solo.
