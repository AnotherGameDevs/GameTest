extends Node
## Lobby + connection handling. Solo uses Godot's offline peer, so the same
## game code runs whether you're alone, hosting, or joining.

signal players_changed
signal lobby_changed
signal connection_failed(reason: String)
signal connected
signal disconnected(reason: String)
signal game_started(config: Dictionary)
signal returned_to_lobby

const CardsDB := preload("res://player/cards.gd")
const DEFAULT_PORT := 24567
const MAX_PLAYERS := 5

const MODES := ["velorio", "procesion", "ofrenda", "limpia"]
const NIGHT_LENGTHS := {"short": 240.0, "normal": 480.0, "long": 720.0, "endless": 99999.0}
const DIFFICULTY := {"easy": 0.8, "normal": 1.0, "hard": 1.25}

var players := {}          # peer_id -> {"name": String, "color": int}
var lobby := {
	"mode": "velorio", "night": "normal", "cards": 1,
	"difficulty": "normal",
	"lives": 1,                 # times each player can pick themselves up when downed
	"card": "random",           # or force one card id for testing
	"seed": 0,                  # 0 = random; set a number to replay the same night
	"creatures": ["llorona", "lechuza", "mano"],
}
var is_solo := true
var in_game := false


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)


func my_id() -> int:
	return multiplayer.get_unique_id()


func is_host() -> bool:
	return multiplayer.is_server()


# --- Starting / joining -------------------------------------------------------

func start_solo() -> void:
	leave(false)
	is_solo = true
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	players = {1: {"name": Settings.player_name, "color": 0}}
	players_changed.emit()
	connected.emit()


func host(port := DEFAULT_PORT) -> Error:
	leave(false)
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, MAX_PLAYERS)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	is_solo = false
	players = {1: {"name": Settings.player_name, "color": 0}}
	players_changed.emit()
	connected.emit()
	return OK


func join(ip: String, port := DEFAULT_PORT) -> Error:
	leave(false)
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, port)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	is_solo = false
	return OK


func leave(emit := true) -> void:
	if multiplayer.multiplayer_peer and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	players.clear()
	in_game = false
	is_solo = true
	if emit:
		disconnected.emit("")


# --- Lobby sync ----------------------------------------------------------------

func set_lobby_option(key: String, value) -> void:
	if not is_host():
		return
	lobby[key] = value
	if is_solo:
		lobby_changed.emit()
	else:
		_sync_lobby.rpc(lobby)


@rpc("authority", "call_local", "reliable")
func _sync_lobby(data: Dictionary) -> void:
	lobby = data
	lobby_changed.emit()


@rpc("authority", "call_local", "reliable")
func _sync_players(data: Dictionary) -> void:
	players = data
	players_changed.emit()


@rpc("any_peer", "reliable")
func _register(player_name: String) -> void:
	if not is_host():
		return
	var id := multiplayer.get_remote_sender_id()
	if in_game:
		# No mid-game joins in the prototype.
		multiplayer.multiplayer_peer.disconnect_peer(id)
		return
	var used := []
	for p in players.values():
		used.append(p["color"])
	var color := 0
	while color in used:
		color += 1
	players[id] = {"name": player_name.substr(0, 16), "color": color}
	_sync_players.rpc(players)
	_sync_lobby.rpc_id(id, lobby)


func _on_peer_connected(_id: int) -> void:
	pass


func _on_peer_disconnected(id: int) -> void:
	if is_host() and players.has(id):
		players.erase(id)
		_sync_players.rpc(players)


func _on_connected_to_server() -> void:
	_register.rpc_id(1, Settings.player_name)
	connected.emit()


func _on_connection_failed() -> void:
	leave(false)
	connection_failed.emit("Couldn't connect. Check the IP and that the host forwarded port %d (UDP)." % DEFAULT_PORT)


func _on_server_disconnected() -> void:
	leave(false)
	disconnected.emit("The host closed the game.")


# --- Game start / end ------------------------------------------------------------

func start_game() -> void:
	if not is_host():
		return
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var ids := players.keys()
	ids.sort()
	var deck := CardsDB.ALL.duplicate()
	var cards := {}
	var per: int = int(lobby.get("cards", 1))
	var forced: String = lobby.get("card", "random")
	deck.erase(forced)
	for id in ids:
		var hand := []
		if forced == "none":
			cards[id] = hand
			continue
		if forced != "random":
			hand.append(forced)
		for i in per - hand.size():
			if deck.is_empty():
				deck = CardsDB.ALL.duplicate()
			var idx := rng.randi_range(0, deck.size() - 1)
			hand.append(deck[idx])
			deck.remove_at(idx)
		cards[id] = hand
	var seed_value: int = int(lobby.get("seed", 0))
	var config := {
		"mode": lobby["mode"],
		"seed": seed_value if seed_value != 0 else rng.randi_range(1, 999999),
		"difficulty": lobby.get("difficulty", "normal"),
		"lives": int(lobby.get("lives", 1)),
		"creatures": lobby.get("creatures", ["llorona", "lechuza", "mano"]),
		"night_seconds": NIGHT_LENGTHS.get(lobby["night"], 480.0),
		"players": players.duplicate(true),
		"cards": cards,
	}
	if is_solo:
		_start_game(config)
	else:
		_start_game.rpc(config)


@rpc("authority", "call_local", "reliable")
func _start_game(config: Dictionary) -> void:
	in_game = true
	game_started.emit(config)


func back_to_lobby() -> void:
	if not is_host():
		return
	if is_solo:
		_back_to_lobby()
	else:
		_back_to_lobby.rpc()


@rpc("authority", "call_local", "reliable")
func _back_to_lobby() -> void:
	in_game = false
	returned_to_lobby.emit()
