extends Node
## Player settings, saved to user://settings.cfg.
## Anything that changes emits `changed` so the game can react live.

signal changed

const PATH := "user://settings.cfg"

var player_name := "Jugador"
var last_ip := "127.0.0.1"

# Audio (0..1)
var master_volume := 0.8
var ambience_volume := 0.7
var sfx_volume := 0.9

# Controls
var mouse_sensitivity := 0.25
var invert_y := false
var fov := 75.0

# Display
var fullscreen := false
var vsync := true
var brightness := 1.0          # 0.6 .. 1.6, applied in the post-process shader

# PS1 look
var pixelation := true         # off = full resolution
var pixel_size := 3            # 2..6 screen pixels per game pixel
var dithering := true
var vertex_wobble := true

# Testing helpers
var invincible := false
var show_debug := false

const KEYS := [
	"player_name", "last_ip", "master_volume", "ambience_volume", "sfx_volume",
	"mouse_sensitivity", "invert_y", "fov", "fullscreen", "vsync", "brightness",
	"pixelation", "pixel_size", "dithering", "vertex_wobble", "invincible", "show_debug",
]


func _ready() -> void:
	_ensure_buses()
	load_settings()
	apply()


func _ensure_buses() -> void:
	for bus_name in ["Ambience", "SFX"]:
		if AudioServer.get_bus_index(bus_name) == -1:
			AudioServer.add_bus()
			var idx := AudioServer.bus_count - 1
			AudioServer.set_bus_name(idx, bus_name)
			AudioServer.set_bus_send(idx, "Master")


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(PATH) != OK:
		return
	for k in KEYS:
		if cfg.has_section_key("settings", k):
			set(k, cfg.get_value("settings", k))


func save_settings() -> void:
	var cfg := ConfigFile.new()
	for k in KEYS:
		cfg.set_value("settings", k, get(k))
	cfg.save(PATH)


func set_value(key: String, value) -> void:
	set(key, value)
	apply()
	save_settings()


func apply() -> void:
	_set_bus("Master", master_volume)
	_set_bus("Ambience", ambience_volume)
	_set_bus("SFX", sfx_volume)
	if not DisplayServer.get_name() == "headless":
		var mode := DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen else DisplayServer.WINDOW_MODE_WINDOWED
		if DisplayServer.window_get_mode() != mode:
			DisplayServer.window_set_mode(mode)
		DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if vsync else DisplayServer.VSYNC_DISABLED)
	changed.emit()


func _set_bus(bus_name: String, v: float) -> void:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx == -1:
		return
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(v, 0.0001)))
	AudioServer.set_bus_mute(idx, v <= 0.001)
