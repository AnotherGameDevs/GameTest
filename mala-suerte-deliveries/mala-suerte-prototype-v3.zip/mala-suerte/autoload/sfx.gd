extends Node
## Procedurally generated placeholder sounds, so the prototype needs no audio files.
## Swap any of these for real recordings later: replace the stream in `streams`.

const RATE := 22050

var streams := {}
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rng.seed = 1337
	streams["wind"] = _make(_wind(), true)
	streams["heartbeat"] = _make(_heartbeat(), false)
	streams["bell"] = _make(_bell(), false)
	streams["cry"] = _make(_cry(), true)
	streams["whistle"] = _make(_whistle(), false)
	streams["step"] = _make(_step(), false)
	streams["whisper"] = _make(_whisper(), false)
	streams["match"] = _make(_match(), false)
	streams["puff"] = _make(_puff(), false)
	streams["grab"] = _make(_grab(), false)
	streams["sting"] = _make(_sting(), false)
	streams["click"] = _make(_click(), false)
	streams["pickup"] = _make(_pickup(), false)
	streams["drone"] = _make(_drone(), true)
	streams["screech"] = _make(_screech(), false)
	streams["win"] = _make(_win(), false)


## Plays a non-positional sound. Returns the player so callers can stop it.
func play(name: String, volume_db := 0.0, pitch := 1.0, bus := "SFX") -> AudioStreamPlayer:
	if not streams.has(name):
		return null
	var p := AudioStreamPlayer.new()
	p.stream = streams[name]
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.bus = bus
	add_child(p)
	p.play()
	if not (streams[name] as AudioStreamWAV).loop_mode:
		p.finished.connect(p.queue_free)
	return p


## Plays a positional sound at a world position.
func play_at(name: String, pos: Vector3, parent: Node, volume_db := 0.0, pitch := 1.0, max_dist := 40.0) -> AudioStreamPlayer3D:
	if not streams.has(name) or parent == null or not parent.is_inside_tree():
		return null
	var p := AudioStreamPlayer3D.new()
	p.stream = streams[name]
	p.volume_db = volume_db
	p.pitch_scale = pitch
	p.max_distance = max_dist
	p.unit_size = 6.0
	p.bus = "SFX"
	parent.add_child(p)
	p.global_position = pos
	p.play()
	p.finished.connect(p.queue_free)
	return p


func _make(samples: PackedFloat32Array, loop: bool) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(samples.size() * 2)
	for i in samples.size():
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	s.data = data
	if loop:
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = samples.size()
	return s


func _buf(seconds: float) -> PackedFloat32Array:
	var a := PackedFloat32Array()
	a.resize(int(seconds * RATE))
	return a


func _noise() -> float:
	return _rng.randf_range(-1.0, 1.0)


func _wind() -> PackedFloat32Array:
	var a := _buf(6.0)
	var lp := 0.0
	var lp2 := 0.0
	for i in a.size():
		var t := float(i) / RATE
		lp = lerpf(lp, _noise(), 0.03)
		lp2 = lerpf(lp2, lp, 0.05)
		var gust := 0.55 + 0.45 * sin(TAU * t / 6.0) * sin(TAU * t / 3.0 + 1.0)
		a[i] = lp2 * 2.6 * gust
	# smooth the loop seam
	for i in 600:
		var k := float(i) / 600.0
		a[i] *= k
		a[a.size() - 1 - i] *= k
	return a


func _heartbeat() -> PackedFloat32Array:
	var a := _buf(0.9)
	for i in a.size():
		var t := float(i) / RATE
		var v := 0.0
		for start in [0.0, 0.28]:
			var d: float = t - start
			if d >= 0.0:
				v += sin(TAU * 48.0 * d) * exp(-d * 18.0) * (1.0 if start == 0.0 else 0.7)
		a[i] = v * 0.9
	return a


func _bell() -> PackedFloat32Array:
	var a := _buf(2.0)
	for i in a.size():
		var t := float(i) / RATE
		var e := exp(-t * 2.2)
		a[i] = (sin(TAU * 620.0 * t) + 0.6 * sin(TAU * 1496.0 * t) + 0.4 * sin(TAU * 2120.0 * t) + 0.25 * sin(TAU * 3010.0 * t)) * e * 0.3
	return a


func _cry() -> PackedFloat32Array:
	# Long wailing sob, loops. "Ay, mis hijos..." stand-in.
	var a := _buf(5.0)
	var phase := 0.0
	var lp := 0.0
	for i in a.size():
		var t := float(i) / RATE
		var cycle := fmod(t, 2.5) / 2.5
		var f := lerpf(560.0, 330.0, cycle) * (1.0 + 0.03 * sin(TAU * 5.5 * t))
		phase += TAU * f / RATE
		var env := sin(PI * cycle) * (0.7 + 0.3 * sin(TAU * 1.7 * t))
		lp = lerpf(lp, _noise(), 0.2)
		var voice := sin(phase) + 0.45 * sin(phase * 2.0) + 0.2 * sin(phase * 3.01)
		a[i] = (voice * 0.28 + lp * 0.12) * env
	return a


func _whistle() -> PackedFloat32Array:
	var a := _buf(1.4)
	var phase := 0.0
	for i in a.size():
		var t := float(i) / RATE
		var seg := 0.0 if t < 0.55 else (1.0 if t > 0.75 else -1.0)
		if seg < 0.0:
			a[i] = 0.0
			continue
		var lt := t if seg == 0.0 else t - 0.75
		var f := lerpf(2300.0, 1700.0, lt / 0.6)
		phase += TAU * f / RATE
		a[i] = sin(phase) * sin(PI * clampf(lt / 0.6, 0.0, 1.0)) * 0.35
	return a


func _step() -> PackedFloat32Array:
	var a := _buf(0.14)
	var lp := 0.0
	for i in a.size():
		var t := float(i) / RATE
		lp = lerpf(lp, _noise(), 0.25)
		a[i] = lp * exp(-t * 40.0) * 1.4
	return a


func _whisper() -> PackedFloat32Array:
	var a := _buf(1.6)
	var lp := 0.0
	var hp_prev := 0.0
	for i in a.size():
		var t := float(i) / RATE
		var n := _noise()
		lp = lerpf(lp, n, 0.5)
		var band := lp - hp_prev
		hp_prev = lerpf(hp_prev, lp, 0.1)
		var syll := maxf(0.0, sin(TAU * 2.6 * t)) * sin(PI * t / 1.6)
		a[i] = band * syll * 0.9
	return a


func _match() -> PackedFloat32Array:
	var a := _buf(0.6)
	for i in a.size():
		var t := float(i) / RATE
		var strike := exp(-t * 25.0)
		var hiss := 0.25 * exp(-t * 4.0)
		a[i] = _noise() * (strike * 0.8 + hiss)
	return a


func _puff() -> PackedFloat32Array:
	var a := _buf(0.35)
	var lp := 0.0
	for i in a.size():
		var t := float(i) / RATE
		lp = lerpf(lp, _noise(), 0.08)
		a[i] = lp * sin(PI * t / 0.35) * 2.0
	return a


func _grab() -> PackedFloat32Array:
	var a := _buf(1.0)
	var lp := 0.0
	for i in a.size():
		var t := float(i) / RATE
		lp = lerpf(lp, _noise(), 0.04)
		a[i] = (lp * 3.0 + sin(TAU * 70.0 * t) * 0.3) * exp(-t * 2.5)
	return a


func _sting() -> PackedFloat32Array:
	var a := _buf(1.2)
	var phase := 0.0
	for i in a.size():
		var t := float(i) / RATE
		var f := 900.0 * exp(-t * 1.5) + 120.0
		phase += TAU * f / RATE
		a[i] = (sign(sin(phase)) * 0.25 + _noise() * 0.35) * exp(-t * 2.0)
	return a


func _screech() -> PackedFloat32Array:
	var a := _buf(0.9)
	var phase := 0.0
	for i in a.size():
		var t := float(i) / RATE
		var f := 2600.0 + 600.0 * sin(TAU * 30.0 * t)
		phase += TAU * f / RATE
		a[i] = (sin(phase) * 0.3 + _noise() * 0.25) * sin(PI * t / 0.9)
	return a


func _click() -> PackedFloat32Array:
	var a := _buf(0.05)
	for i in a.size():
		var t := float(i) / RATE
		a[i] = sin(TAU * 900.0 * t) * exp(-t * 90.0) * 0.4
	return a


func _pickup() -> PackedFloat32Array:
	var a := _buf(0.18)
	for i in a.size():
		var t := float(i) / RATE
		a[i] = sin(TAU * lerpf(500.0, 900.0, t / 0.18) * t) * exp(-t * 14.0) * 0.4
	return a


func _drone() -> PackedFloat32Array:
	var a := _buf(4.0)
	for i in a.size():
		var t := float(i) / RATE
		a[i] = (sin(TAU * 55.0 * t) + 0.5 * sin(TAU * 82.5 * t) + 0.3 * sin(TAU * 110.25 * t)) * 0.18 * (0.8 + 0.2 * sin(TAU * 0.5 * t))
	return a


func _win() -> PackedFloat32Array:
	var a := _buf(2.0)
	var notes := [261.6, 329.6, 392.0, 523.3]
	for i in a.size():
		var t := float(i) / RATE
		var v := 0.0
		for n in notes.size():
			var d: float = t - n * 0.18
			if d > 0.0:
				v += sin(TAU * notes[n] * d) * exp(-d * 2.0)
		a[i] = v * 0.18
	return a
