extends CharacterBody3D
## Base for folklore creatures. The host runs the AI; everyone else just sees
## the synced position/state. Each creature has a rule players have to learn.

const Palette := preload("res://world/palette.gd")
const PlayerScript := preload("res://player/player.gd")

var game: Node = null
var map: Node = null
var active := true        # synced
var anim := 0             # synced, meaning depends on the creature
var agent: NavigationAgent3D
var visual: Node3D
var _sync: MultiplayerSynchronizer


func setup(game_node: Node, map_node: Node, creature_name: String) -> void:
	game = game_node
	map = map_node
	name = creature_name


func _ready() -> void:
	add_to_group("creature")
	collision_layer = 4
	collision_mask = 1
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.7
	col.shape = cap
	col.position.y = 0.85
	add_child(col)
	agent = NavigationAgent3D.new()
	agent.path_desired_distance = 0.8
	agent.target_desired_distance = 1.0
	agent.radius = 0.45
	agent.height = 1.8
	add_child(agent)
	visual = build_visual()
	add_child(visual)

	_sync = MultiplayerSynchronizer.new()
	_sync.name = "Sync"
	var cfg := SceneReplicationConfig.new()
	for prop in sync_props():
		var path := NodePath("." + prop)
		cfg.add_property(path)
		cfg.property_set_replication_mode(path, SceneReplicationConfig.REPLICATION_MODE_ALWAYS)
	_sync.replication_config = cfg
	_sync.root_path = NodePath("..")
	_sync.replication_interval = 0.05
	add_child(_sync)
	_sync.set_multiplayer_authority(1)
	creature_ready()


func sync_props() -> Array:
	return [":position", ":rotation", ":active", ":anim"]


func is_active() -> bool:
	return active


# Overridden by each creature
func build_visual() -> Node3D:
	return Node3D.new()

func creature_ready() -> void:
	pass

func server_tick(_delta: float) -> void:
	pass

func client_tick(_delta: float) -> void:
	pass


func _physics_process(delta: float) -> void:
	visible = active
	if multiplayer.is_server() and game and game.running:
		server_tick(delta)
	client_tick(delta)


# --- Helpers (host) -----------------------------------------------------------------

func move_to(target: Vector3, speed: float, _delta: float) -> void:
	agent.target_position = target
	var next := agent.get_next_path_position()
	var d := next - global_position
	d.y = 0
	if d.length() < 0.05:
		velocity = Vector3.ZERO
		return
	var dir := d.normalized()
	velocity = Vector3(dir.x * speed, -2.0, dir.z * speed)
	move_and_slide()
	face(global_position + dir)


func face(p: Vector3) -> void:
	var d := p - global_position
	d.y = 0
	if d.length() > 0.01:
		rotation.y = lerp_angle(rotation.y, atan2(-d.x, -d.z), 0.2)


func alive_players() -> Array:
	var out := []
	for p in get_tree().get_nodes_in_group("players"):
		if p.state == PlayerScript.State.ALIVE or p.state == PlayerScript.State.GRABBED:
			out.append(p)
	return out


func can_see(p: Node3D, max_dist := 30.0) -> bool:
	var from := global_position + Vector3.UP * 1.6
	var to: Vector3 = p.global_position + Vector3.UP * 1.4
	if from.distance_to(to) > max_dist:
		return false
	var q := PhysicsRayQueryParameters3D.create(from, to, 1)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func local_player() -> Node:
	return game.get_player(multiplayer.get_unique_id()) if game else null


func local_camera() -> Camera3D:
	return get_viewport().get_camera_3d()


## True if the local camera is looking straight at a point and nothing blocks it.
func local_looking_at(p: Vector3, min_dot := 0.95, max_dist := 20.0) -> bool:
	var cam := local_camera()
	if cam == null:
		return false
	var to := p - cam.global_position
	if to.length() > max_dist:
		return false
	var fwd := -cam.global_transform.basis.z
	if fwd.dot(to.normalized()) < min_dot:
		return false
	var q := PhysicsRayQueryParameters3D.create(cam.global_position, p, 1)
	return get_world_3d().direct_space_state.intersect_ray(q).is_empty()


static func m(mesh: Mesh, mat: Material, pos := Vector3.ZERO, scl := Vector3.ONE, rot := Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.scale = scl
	mi.rotation_degrees = rot
	return mi
