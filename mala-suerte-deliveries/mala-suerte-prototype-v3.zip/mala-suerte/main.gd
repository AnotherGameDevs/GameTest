extends Node
## Entry point: shows the menu, swaps in a Game when a night starts.

const GameScript := preload("res://game.gd")
const MenuScript := preload("res://ui/menu.gd")

var menu: Control
var menu_layer: CanvasLayer
var game: Node3D


func _ready() -> void:
	RenderingServer.set_default_clear_color(Color("#0d0a0b"))
	menu_layer = CanvasLayer.new()
	add_child(menu_layer)
	menu = Control.new()
	menu.set_script(MenuScript)
	menu_layer.add_child(menu)
	Net.game_started.connect(_on_game_started)
	Net.returned_to_lobby.connect(_on_back_to_lobby)
	Net.disconnected.connect(func(_r): _free_game())

	# Automated testing: godot -- --autotest=solo:velorio  (see tools/autotest.gd)
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--autotest"):
			var t := Node.new()
			t.set_script(load("res://tools/autotest.gd"))
			t.name = "Autotest"
			add_child(t)
			break


func _on_game_started(config: Dictionary) -> void:
	_free_game()
	menu_layer.visible = false
	game = Node3D.new()
	game.set_script(GameScript)
	game.start(config)
	add_child(game)


func _on_back_to_lobby() -> void:
	_free_game()
	menu_layer.visible = true
	menu.show_lobby()


func _free_game() -> void:
	get_tree().paused = false
	if game and is_instance_valid(game):
		remove_child(game)
		game.queue_free()
	game = null
	menu_layer.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
