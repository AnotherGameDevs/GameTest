extends "res://modes/mode_base.gd"
## LA LIMPIA — something has cursed the rancho. Only ONE creature is out tonight.
## Find its signs, work out which one it is, bring an egg + the right herb to
## the altar in the troje, and perform the cleansing while it fights back.
## (The remedies here are game rules, not real curandera practice.)

const CURSES := ["llorona", "lechuza", "mano"]
const REMEDY := {"llorona": "ruda", "lechuza": "copal", "mano": "romero"}
const SIGN_TEXT := {
	"llorona": ["Wet footprints", "Bare, wet footprints. Small. They come from the direction of the water… and stop here."],
	"lechuza": ["Feathers", "Feathers as long as your forearm. Too big for any owl. They smell like burnt hair."],
	"mano": ["Scratches", "Deep claw marks gouged into the boards. From underneath. Something tried to come up."],
}

var curse := ""
var slots := {"egg": "", "herb": ""}      # item kinds placed
var ritual_ready := false
var _drone: AudioStreamPlayer


func map_markers() -> Array:
	return [[map.barn_altar_pos, "altar", Color("#b89a5a")], [map.coop_pos, "eggs", Color("#f2ead8")]]


func dev_answer() -> String:
	return "The curse is %s — remedy: egg + %s" % [curse.to_upper(), REMEDY[curse]]


func dev_next_item() -> String:
	if slots["egg"] == "":
		return "huevo"
	if slots["herb"] == "":
		return REMEDY[curse]
	return ""


func title() -> String:
	return "La Limpia"


func creature_list() -> Array:
	return [curse]


func objective_text() -> String:
	return "Something cursed this rancho. Examine its signs, figure out what it is, and bring an EGG + the right HERB to the altar in the TROJE (barn). The curandera's notebook is there."


func status_text() -> String:
	var s := "Altar: egg %s   herb %s" % ["✓" if slots["egg"] != "" else "—", "✓" if slots["herb"] != "" else "—"]
	if ritual_ready:
		s += "\nThe altar is ready. Hold [E] at the altar to perform the limpia!"
	return s


func setup(game_node: Node, map_node: Node, seed_value: int) -> void:
	rng.seed = seed_value
	curse = CURSES[rng.randi_range(0, CURSES.size() - 1)]
	super.setup(game_node, map_node, seed_value)


func build() -> void:
	# Signs: 5 of the real curse, 1 decoy of each other kind
	var kinds := [curse, curse, curse, curse, curse]
	for c in CURSES:
		if c != curse:
			kinds.append(c)
	var spots := spot_list(map.sign_spots, kinds.size())
	for i in kinds.size():
		_sign(i, kinds[i], spots[i])
	# Ingredients
	var coop_spot: Vector3 = map.coop_pos + Vector3(0, 1.3, -1.2)
	game.spawn_item("huevo", "huevo", coop_spot)
	var herb_spots := spot_list(map.item_spots, 6)
	var herbs := ["ruda", "romero", "albahaca", "copal"]
	for i in herbs.size():
		game.spawn_item(herbs[i], herbs[i], herb_spots[i])
	game.spawn_item("pilas_0", "pilas", herb_spots[4])
	game.spawn_item("pilas_1", "pilas", herb_spots[5])
	note("cuaderno", map.barn_altar_pos + Vector3(0, 0.95, 0.7), "Cuaderno de la curandera",
		"Siempre un blanquillo.  (Always an egg.)\n\n" +
		"Para la que llora junto al agua: RUDA.\n(For the one who weeps by the water: rue.)\n\n" +
		"Para la que silba desde los techos: COPAL.\n(For the one who whistles from the rooftops: copal.)\n\n" +
		"Para lo que vive bajo las tablas: ROMERO.\n(For what lives under the floorboards: rosemary.)\n\n" +
		"Albahaca… para otras cosas.  (Basil… for other things.)")
	make_interactable("altar", map.barn_altar_pos + Vector3(0, 0.9, 0), Vector3(1.2, 1.2, 2.2))
	for z in [-0.7, 0.7]:
		var h := Node3D.new()
		game.get_node("World").add_child(h)
		h.position = map.barn_altar_pos + Vector3(0, 0.9, z)
		candle_mesh(h, Vector3.ZERO, 0.3)
		flame(h, Vector3(0, 0.35, 0), z < 0)
	_drone = Sfx.play("drone", -16.0, 1.0, "Ambience")
	tree_exiting.connect(func(): if _drone: _drone.queue_free())


func _sign(i: int, kind: String, pos: Vector3) -> void:
	var n := note("sign_%d" % i, pos, SIGN_TEXT[kind][0], SIGN_TEXT[kind][1])
	n.get_child(1).visible = false   # hide the paper; draw the sign instead
	var mat: Material
	match kind:
		"llorona":
			mat = Palette.color(Color("#1a2a33"))
			for k in 4:
				_flat(n, Vector3(0.18 * (k % 2) - 0.09, 0, -0.4 + k * 0.28), Vector3(0.1, 0.01, 0.22), mat)
		"lechuza":
			mat = Palette.color(Color("#c8bca2"), 0.3)
			for k in 3:
				_flat(n, Vector3(rng.randf_range(-0.2, 0.2), 0.01, rng.randf_range(-0.2, 0.2)), Vector3(0.05, 0.01, 0.35), mat, rng.randf_range(0, 180))
		"mano":
			mat = Palette.color(Color("#120c08"))
			for k in 3:
				_flat(n, Vector3(-0.12 + k * 0.12, 0, 0), Vector3(0.03, 0.01, 0.6), mat, 15)


func _flat(parent: Node3D, pos: Vector3, size: Vector3, mat: Material, rot_y := 0.0) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	parent.add_child(mi)
	mi.position = pos
	mi.rotation_degrees.y = rot_y


func prompt_for(node: Node, player: Node) -> String:
	if node.key != "altar":
		return ""
	var held: Node = game.held_item(player.peer_id)
	if held and held.kind in ["huevo", "ruda", "romero", "albahaca", "copal"]:
		return "[E] Place the %s on the altar" % held.display_name().to_lower()
	if ritual_ready:
		return "Hold [E] to perform the limpia"
	return "The altar needs an egg and the right herb."


func hold_for(node: Node, player: Node) -> float:
	if node.key == "altar" and ritual_ready and game.held_item(player.peer_id) == null:
		return 8.0
	return 0.0


func on_interact(node: Node, peer_id: int) -> void:
	if node.key != "altar":
		return
	var it: Node = game.held_item(peer_id)
	if it == null:
		if ritual_ready:
			game.server_end(true, "The egg cracks black in the water. The curse is lifted from the rancho.")
		return
	if it.kind == "huevo":
		if slots["egg"] != "":
			return
		game.server_item(it, 0, true, false, map.barn_altar_pos + Vector3(-0.1, 0.95, -0.25))
		game.mode_call("set_slot", ["egg", "huevo"])
	elif it.kind in ["ruda", "romero", "albahaca", "copal"]:
		if slots["herb"] != "":
			return
		if it.kind != REMEDY[curse]:
			game.server_item(it, 0, false, false, it.home)
			game.server_sound("sting", map.barn_altar_pos, 4.0, 40.0)
			game.server_toast_all("The herb crumbles to ash. Wrong remedy — and it knows you tried.")
			_provoke(peer_id)
			return
		game.server_item(it, 0, true, false, map.barn_altar_pos + Vector3(-0.1, 0.95, 0.25))
		game.mode_call("set_slot", ["herb", it.kind])
	else:
		return
	game.server_sound("pickup", map.barn_altar_pos, 0.0, 15.0)
	if slots["egg"] != "" and slots["herb"] != "":
		game.mode_call("set_ready", [true])
		game.server_toast_all("The altar is ready. It knows. Perform the limpia — hold [E] at the altar!")
		for p in game.get_players():
			if p.state == PlayerScript.State.ALIVE:
				_provoke(p.peer_id)
				break


func _provoke(peer_id: int) -> void:
	var c: Node = game.creatures_root.get_node_or_null(curse.capitalize())
	if c == null:
		return
	match curse:
		"llorona":
			c.enrage(20.0, peer_id)
		"lechuza":
			c.state = c.WHISTLE
			c.mark(peer_id)
		"mano":
			c.cooldown = 0.0


func on_dawn() -> void:
	game.server_end(false, "Dawn came, and the curse still holds the rancho.")


func set_slot(slot: String, kind: String) -> void:
	slots[slot] = kind


func set_ready(r: bool) -> void:
	ritual_ready = r
