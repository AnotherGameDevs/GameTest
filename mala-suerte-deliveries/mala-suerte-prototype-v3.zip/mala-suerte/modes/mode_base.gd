extends Node
## Base class for game modes. Every peer runs `setup` with the same seed, so the
## world comes out identical everywhere. Only the host runs `server_tick` and
## `on_interact`; it pushes changes to everyone with `game.mode_call(...)`.

const Palette := preload("res://world/palette.gd")
const Interactable := preload("res://world/interactable.gd")
const PlayerScript := preload("res://player/player.gd")

var game: Node
var map: Node
var rng := RandomNumberGenerator.new()


func setup(game_node: Node, map_node: Node, seed_value: int) -> void:
	game = game_node
	map = map_node
	rng.seed = seed_value
	build()


## Which creatures roam in this mode.
func creature_list() -> Array:
	return ["llorona", "lechuza", "mano"]


## Points of interest drawn on the map: [[Vector3, label, Color], ...]
func map_markers() -> Array:
	return []


## Dev menu: the solution for this night (who / which curse), or "".
func dev_answer() -> String:
	return ""


## Dev menu: name of the next item worth bringing to you, or "".
func dev_next_item() -> String:
	return ""


func title() -> String:
	return "MODE"

func objective_text() -> String:
	return ""

func status_text() -> String:
	return ""

func build() -> void:
	pass

func server_tick(_delta: float) -> void:
	pass

## Called when the clock hits 6:00 AM (host).
func on_dawn() -> void:
	game.server_end(true, "The sun rises. You made it through the night.")

## Called every physics frame for each creature (host). Lets modes react to them.
func on_creature_near(_creature: Node) -> void:
	pass

# Interactables made by this mode route here.
func prompt_for(_node: Node, _player: Node) -> String:
	return ""

func hold_for(_node: Node, _player: Node) -> float:
	return 0.0

func on_interact(_node: Node, _peer_id: int) -> void:
	pass

## Return a prompt string to override the default for an item, or "" for default.
func item_prompt(_item: Node, _player: Node) -> String:
	return ""

## Return true if the mode handled the item interaction itself.
func item_interact(_item: Node, _peer_id: int) -> bool:
	return false

func add_matches(_n: int) -> void:
	pass


# --- Helpers ------------------------------------------------------------------------

func make_interactable(k: String, pos: Vector3, size := Vector3(0.8, 0.8, 0.8), offset := Vector3.ZERO) -> Node3D:
	var it := Node3D.new()
	it.set_script(Interactable)
	it.setup(k, self, size, offset)
	game.get_node("World").add_child(it)
	it.global_position = pos
	return it


func spot_list(source: Array, count: int) -> Array:
	var pool := source.duplicate()
	var out := []
	for i in count:
		if pool.is_empty():
			pool = source.duplicate()
		var idx := rng.randi_range(0, pool.size() - 1)
		out.append(pool[idx])
		pool.remove_at(idx)
	return out


func flame(parent: Node3D, pos: Vector3, with_light := true) -> Node3D:
	var f := Node3D.new()
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.035
	sm.height = 0.1
	sm.radial_segments = 6
	sm.rings = 3
	mi.mesh = sm
	mi.material_override = Palette.color(Color("#ffb347"), 6.0)
	f.add_child(mi)
	if with_light:
		var l := OmniLight3D.new()
		l.light_color = Color("#ff9a3c")
		l.light_energy = 0.9
		l.omni_range = 3.5
		l.position.y = 0.1
		f.add_child(l)
	parent.add_child(f)
	f.position = pos
	return f


func candle_mesh(parent: Node3D, pos: Vector3, height := 0.3) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.04
	cm.bottom_radius = 0.045
	cm.height = height
	cm.radial_segments = 6
	mi.mesh = cm
	mi.material_override = Palette.surface("candle")
	parent.add_child(mi)
	mi.position = pos + Vector3(0, height * 0.5, 0)


func note(k: String, pos: Vector3, title_text: String, body: String) -> Node3D:
	var n := make_interactable(k, pos, Vector3(0.5, 0.3, 0.5))
	n.set_meta("note_title", title_text)
	n.set_meta("note_body", body)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.25, 0.01, 0.32)
	mi.mesh = bm
	mi.material_override = Palette.color(Color("#e8dcc0"), 0.5)
	mi.rotation_degrees.y = rng.randf_range(-30, 30)
	n.add_child(mi)
	return n
