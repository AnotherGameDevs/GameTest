extends "res://modes/mode_base.gd"
## LA OFRENDA — Día de Muertos night. Someone is trying to come home.
## Figure out WHO from the clues around the pueblo, then bring the four things
## they loved to the altar in the casa. A wrong offering invites the wrong guest.

const PROFILES := [
	{
		"name": "Don Ramón",
		"photo": "A man in his seventies, laughing, a wide hat pushed back on his head.",
		"items": ["sombrero", "tequila", "guitarra", "cigarros"],
		"clues": [
			"Ramón played at the plaza every Sunday until his fingers gave out. Nobody's touched those strings since.",
			"He'd stop by for a shot of the good stuff after mass. Blanco. Never reposado, he said it was for tourists.",
			"TIENDA LEDGER —  R.: 2 packs Faros. R.: 2 packs Faros. R.: 2 packs Faros (pay later).",
			"Papá never left the house without his hat. Not to church, not to the outhouse, not ever.",
		],
	},
	{
		"name": "Doña Lupe",
		"photo": "A small woman in a black rebozo, hands folded, eyes closed as if praying.",
		"items": ["rosario", "costurero", "cafe", "pan"],
		"clues": [
			"Lupe prayed every night at nine, beads clicking through her fingers. You could set a clock by it.",
			"Half the pueblo's pants were patched from that blue tin of hers. Needles, thread, buttons from 1970.",
			"Nobody made café de olla like her. Canela, piloncillo, in the clay pot. She'd want one more cup.",
			"TIENDA LEDGER —  L.: conchas, 2.  L.: conchas, 2.  L.: pan dulce, every morning without fail.",
		],
	},
	{
		"name": "Tío Chuy",
		"photo": "A heavy man grinning at the camera, a red cap on backwards.",
		"items": ["baraja", "radio", "cerveza", "gorra"],
		"clues": [
			"Chuy cheated at conquián every single Friday and we all let him win anyway. He kept the deck in his shirt.",
			"That little radio was always on the fútbol. He'd yell at it like the referee could hear him.",
			"TIENDA LEDGER —  Chuy: six cervezas (credit). Chuy: six cervezas (credit). Chuy: PAY YOUR TAB.",
			"His brother sent him a gringo baseball cap from Chicago. He never took it off after that.",
		],
	},
]

var profile := {}
var placed := []             # item kinds already on the altar
var mistakes := 0
var altar: Node3D


func map_markers() -> Array:
	return [[map.altar_pos, "ofrenda", Color("#e8901a")]]


func dev_answer() -> String:
	return "%s — wants: %s" % [profile["name"], ", ".join(profile["items"])]


func dev_next_item() -> String:
	for k in profile["items"]:
		if not (k in placed):
			return "of_" + k
	return ""


func title() -> String:
	return "La Ofrenda"


func objective_text() -> String:
	return "Someone is coming home tonight. Read the clues around the pueblo, then bring the 4 things they loved to the ofrenda in the casa."


func status_text() -> String:
	return "Offerings: %d/4    Wrong offerings: %d" % [placed.size(), mistakes]


func build() -> void:
	profile = PROFILES[rng.randi_range(0, PROFILES.size() - 1)]
	# Every possible offering appears somewhere; only 4 belong to the guest
	var kinds := []
	for p in PROFILES:
		kinds.append_array(p["items"])
	var spots := spot_list(map.item_spots, kinds.size() + 2)
	for i in kinds.size():
		game.spawn_item("of_" + kinds[i], kinds[i], spots[i])
	game.spawn_item("pilas_0", "pilas", spots[kinds.size()])
	game.spawn_item("pilas_1", "pilas", spots[kinds.size() + 1])

	# Clues
	var clue_spots := spot_list(map.note_spots, 4)
	var clues: Array = profile["clues"]
	for i in 4:
		note("clue_%d" % i, clue_spots[i], "A note", clues[i])
	# The photo on the altar
	var photo := note("photo", map.altar_pos + Vector3(0, 1.55, -0.25), "Retrato", "%s\n\n%s\n\nThe frame is empty of a name. Only the picture remains." % ["¿Quién?", profile["photo"]])
	photo.get_child(1).rotation_degrees = Vector3(70, 0, 0)

	# Altar interaction point
	altar = make_interactable("altar", map.altar_pos + Vector3(0, 0.9, 0.3), Vector3(2.6, 1.2, 1.0))
	# Cempasúchil petal path from the road into the house
	var world: Node3D = game.get_node("World")
	for i in 60:
		var t := float(i) / 60.0
		var p := Vector3(rng.randf_range(-0.6, 0.6), 0.04, lerpf(40.0, 4.0, t))
		if t > 0.85:
			p = Vector3(lerpf(0.0, -2.5, (t - 0.85) / 0.15), 0.12, lerpf(9.5, 5.5, (t - 0.85) / 0.15))
		var petal := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.12, 0.02, 0.12)
		petal.mesh = bm
		petal.material_override = Palette.color(Color("#e8901a"), 0.6)
		world.add_child(petal)
		petal.position = p
	for x in [-1.2, 1.2]:
		var h := Node3D.new()
		world.add_child(h)
		h.position = map.altar_pos + Vector3(x, 0.8, 0.3)
		candle_mesh(h, Vector3.ZERO, 0.25)
		flame(h, Vector3(0, 0.3, 0), x < 0)


func prompt_for(node: Node, player: Node) -> String:
	if node.key != "altar":
		return ""
	var held: Node = game.held_item(player.peer_id)
	if held and held.kind != "coffin" and held.kind != "pilas":
		return "[E] Place the %s on the ofrenda" % held.display_name().to_lower()
	return "The ofrenda: %d/4 offerings. Bring what they loved." % placed.size()


func on_interact(node: Node, peer_id: int) -> void:
	if node.key != "altar":
		return
	var it: Node = game.held_item(peer_id)
	if it == null:
		return
	if it.kind in profile["items"] and not (it.kind in placed):
		var slot := placed.size()
		var pos: Vector3 = map.altar_pos + Vector3(-0.9 + slot * 0.6, 0.86, 0.15)
		game.server_item(it, 0, true, false, pos)
		game.mode_call("set_placed", [placed + [it.kind]])
		game.server_sound("win", pos, -10.0, 15.0)
		if slot + 1 >= 4:
			game.server_end(true, "%s found the way home. The candles flicker once, warmly." % profile["name"])
		else:
			game.server_toast_all("The candles on the ofrenda flicker. That was theirs.")
	else:
		game.server_item(it, 0, false, false, it.home)
		game.mode_call("set_mistakes", [mistakes + 1])
		game.server_sound("sting", map.altar_pos, 4.0, 40.0)
		game.server_toast_all("That didn't belong to them. Something else heard the invitation…")
		var ll: Node = game.creatures_root.get_node_or_null("Llorona")
		if ll:
			ll.enrage(12.0, peer_id)


func on_dawn() -> void:
	game.server_end(false, "Dawn came. %s never found the way home." % profile["name"])


func set_placed(list: Array) -> void:
	placed = list


func set_mistakes(n: int) -> void:
	mistakes = n
