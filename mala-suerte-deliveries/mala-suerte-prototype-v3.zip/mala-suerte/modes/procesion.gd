extends "res://modes/mode_base.gd"
## LA PROCESIÓN — carry the coffin from the casa to the camposanto before dawn.
## The carrier is slow and can't use a flashlight. Teammates walking next to
## the coffin help carry it (faster). Someone should scout ahead with a light.

var coffin: Node3D
var _alert_cd := 25.0


func map_markers() -> Array:
	return [[coffin.global_position, "coffin", Color("#d6c08a")], [map.cemetery_goal, "camposanto", Color("#ff9a3c")]]


func dev_next_item() -> String:
	return "coffin"


func title() -> String:
	return "La Procesión"


func objective_text() -> String:
	return "Carry the coffin up the road to the CAMPOSANTO before dawn. Carriers can't use a light — stay close to help carry."


func status_text() -> String:
	if coffin == null:
		return ""
	var d := Vector2(coffin.global_position.x - map.cemetery_goal.x, coffin.global_position.z - map.cemetery_goal.z).length()
	var who := "on the ground"
	if coffin.holder != 0:
		var p: Node = game.get_player(coffin.holder)
		who = "carried by %s" % (p.display_name if p else "?")
	return "Camposanto: %d m    Coffin: %s" % [int(d), who]


func build() -> void:
	coffin = game.spawn_item("coffin", "coffin", map.body_pos + Vector3(0, 1.05, 0))
	# Veladoras (jar candles) lining the road to the camposanto
	var world: Node3D = game.get_node("World")
	for i in map.procession_route.size():
		var pt: Vector3 = map.procession_route[i]
		var side := 1.0 if i % 2 == 0 else -1.0
		var holder := Node3D.new()
		world.add_child(holder)
		holder.position = pt + Vector3(2.9 * side, 0.07, 0)
		candle_mesh(holder, Vector3.ZERO, 0.25)
		flame(holder, Vector3(0, 0.3, 0), i % 4 == 0)
	# Some batteries to keep the scout's light going
	var spots := spot_list(map.item_spots, 3)
	for i in 3:
		game.spawn_item("pilas_%d" % i, "pilas", spots[i])


func item_prompt(item: Node, player: Node) -> String:
	if item.kind == "coffin":
		if game.held_item(player.peer_id) != null:
			return "Hands full — [G] drop"
		return "[E] Lift the coffin"
	return ""


func server_tick(delta: float) -> void:
	if coffin == null:
		return
	var d := Vector2(coffin.global_position.x - map.cemetery_goal.x, coffin.global_position.z - map.cemetery_goal.z).length()
	if d < map.cemetery_goal_radius:
		game.server_end(true, "The dead rest in the camposanto. The procession made it.")
		return
	# The dead attract attention: every so often La Llorona is drawn to the coffin
	_alert_cd -= delta
	if _alert_cd <= 0.0:
		_alert_cd = rng.randf_range(25.0, 40.0) * (1.0 - game.progress() * 0.4)
		var ll: Node = game.creatures_root.get_node_or_null("Llorona")
		if ll and ll.active and coffin.holder != 0 and ll.state == ll.WANDER:
			ll.target_peer = coffin.holder
			ll.state = ll.NOTICE
			ll.notice_t = ll.NOTICE_TIME
			game.server_toast_all("Somewhere behind you, the weeping goes faint and far away…")


func on_dawn() -> void:
	game.server_end(false, "Dawn caught the procession on the road. The dead were never buried.")
