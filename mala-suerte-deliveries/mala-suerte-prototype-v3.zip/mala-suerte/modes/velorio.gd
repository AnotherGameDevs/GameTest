extends "res://modes/mode_base.gd"
## EL VELORIO — hold the wake until dawn.
## Six candles burn around the body. The wind (and La Llorona) keep putting
## them out. Relighting costs matches, so someone has to go out into the
## pueblo to find more. If the room goes dark for too long, the dead are taken.

const DARK_LIMIT := 20.0

var lit := []                 # bool per candle
var flames := []
var matches := 4
var dark_time := 0.0          # host
var warning := false
var _wind_cd := 20.0


func map_markers() -> Array:
	return [[map.body_pos, "the wake", Color("#ffb347")]]


func dev_answer() -> String:
	return "Keep at least 2 candles lit. Matches left: %d" % matches


func dev_next_item() -> String:
	return "cerillos"


func title() -> String:
	return "El Velorio"


func objective_text() -> String:
	return "Keep the candles around the body lit until dawn. Find matches (cerillos) in the pueblo."


func status_text() -> String:
	var n := lit.count(true)
	var s := "Candles lit: %d/%d    Matches: %d" % [n, lit.size(), matches]
	if warning:
		s += "\nTHE ROOM IS GOING DARK — the dead are being taken!"
	return s


func build() -> void:
	var world: Node3D = game.get_node("World")
	# The body under a white sheet
	var body := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.9, 0.28, 0.6)
	body.mesh = bm
	body.material_override = Palette.surface("cloth_white")
	world.add_child(body)
	body.position = map.body_pos + Vector3(0, 0.94, 0)
	var head := MeshInstance3D.new()
	var hm := SphereMesh.new()
	hm.radius = 0.16
	hm.height = 0.3
	hm.radial_segments = 8
	hm.rings = 4
	head.mesh = hm
	head.material_override = Palette.surface("cloth_white")
	world.add_child(head)
	head.position = map.body_pos + Vector3(-0.85, 1.12, 0)

	for i in map.candle_spots.size():
		var spot: Vector3 = map.candle_spots[i]
		var c := make_interactable("candle_%d" % i, spot + Vector3(0, 0.6, 0), Vector3(0.5, 1.2, 0.5))
		var stand := MeshInstance3D.new()
		var sm := CylinderMesh.new()
		sm.top_radius = 0.07
		sm.bottom_radius = 0.12
		sm.height = 1.0
		sm.radial_segments = 6
		stand.mesh = sm
		stand.material_override = Palette.color(Color("#3a2a1a"))
		c.add_child(stand)
		stand.position.y = -0.1
		candle_mesh(c, Vector3(0, 0.4, 0), 0.35)
		flames.append(flame(c, Vector3(0, 0.82, 0), i % 2 == 0))
		lit.append(true)

	var spots := spot_list(map.item_spots, 9)
	for i in 6:
		game.spawn_item("cerillos_%d" % i, "cerillos", spots[i])
	for i in 3:
		game.spawn_item("pilas_%d" % i, "pilas", spots[6 + i])


func server_tick(delta: float) -> void:
	var prog: float = game.progress()
	_wind_cd -= delta
	if _wind_cd <= 0.0:
		_wind_cd = rng.randf_range(16.0, 28.0) * (1.0 - prog * 0.5) / game.diff
		_blow_out_random()
	var n := lit.count(true)
	if n <= 1:
		dark_time += delta
	else:
		dark_time = maxf(0.0, dark_time - delta * 2.0)
	var w := dark_time > 3.0
	if w != warning:
		game.mode_call("set_warning", [w])
	if dark_time > DARK_LIMIT:
		game.server_end(false, "The candles died. When you lit them again, the table was empty.")


func on_creature_near(c: Node) -> void:
	if c.name != "Llorona" or not c.active:
		return
	if c.global_position.distance_to(map.body_pos) < 7.0 and rng.randf() < 0.012:
		_blow_out_random()


func _blow_out_random() -> void:
	var on := []
	for i in lit.size():
		if lit[i]:
			on.append(i)
	if on.is_empty():
		return
	var i: int = on[rng.randi_range(0, on.size() - 1)]
	game.mode_call("set_candle", [i, false])
	game.server_sound("puff", map.candle_spots[i] + Vector3.UP, 0.0, 20.0)


func prompt_for(node: Node, _player: Node) -> String:
	if not String(node.key).begins_with("candle_"):
		return ""
	var i := int(String(node.key).trim_prefix("candle_"))
	if lit[i]:
		return ""
	if matches <= 0:
		return "No matches left — find cerillos in the pueblo"
	return "[E] Light the candle  (matches: %d)" % matches


func on_interact(node: Node, _peer_id: int) -> void:
	if not String(node.key).begins_with("candle_"):
		return
	var i := int(String(node.key).trim_prefix("candle_"))
	if lit[i] or matches <= 0:
		return
	game.mode_call("set_matches", [matches - 1])
	game.mode_call("set_candle", [i, true])
	game.server_sound("match", map.candle_spots[i] + Vector3.UP, 0.0, 15.0)


func add_matches(n: int) -> void:
	game.mode_call("set_matches", [matches + n])
	game.server_toast_all("+%d matches" % n)


# --- Synced setters (run on every peer) ---

func set_candle(i: int, on: bool) -> void:
	lit[i] = on
	flames[i].visible = on


func set_matches(n: int) -> void:
	matches = n


func set_warning(w: bool) -> void:
	warning = w
