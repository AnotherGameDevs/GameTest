class_name Cards
extends RefCounted
## The Lotería deck used as secret negative modifiers.
## Each player draws card(s) at the start of a night. Only you see yours.

const ALL := ["borracho", "luna", "corazon", "diablito", "muerte", "alacran", "campana", "sirena"]

const INFO := {
	"borracho": {
		"num": 13, "name": "EL BORRACHO",
		"desc": "Your body won't walk straight. The world sways.",
		"color": Color("#7a4b2a"),
	},
	"luna": {
		"num": 17, "name": "LA LUNA",
		"desc": "Your flashlight is weak and its battery drains twice as fast.",
		"color": Color("#2c3a63"),
	},
	"corazon": {
		"num": 27, "name": "EL CORAZÓN",
		"desc": "Your heart pounds so loud they can hear it. You make twice the noise.",
		"color": Color("#8c1c22"),
	},
	"diablito": {
		"num": 2, "name": "EL DIABLITO",
		"desc": "You see things that aren't there. Not everything you see is real.",
		"color": Color("#a3261b"),
	},
	"muerte": {
		"num": 14, "name": "LA MUERTE",
		"desc": "No second chances. If you go down, you die. Nobody can revive you.",
		"color": Color("#1a1a1a"),
	},
	"alacran": {
		"num": 40, "name": "EL ALACRÁN",
		"desc": "Poisoned. Sprinting tires you fast and you recover slowly.",
		"color": Color("#6b5a1e"),
	},
	"campana": {
		"num": 43, "name": "LA CAMPANA",
		"desc": "A bell rings when you run. Everything hears it.",
		"color": Color("#9a7a22"),
	},
	"sirena": {
		"num": 9, "name": "LA SIRENA",
		"desc": "Voices call your name from the dark. Don't follow them.",
		"color": Color("#1f6b6b"),
	},
}


static func info(id: String) -> Dictionary:
	return INFO.get(id, {"num": 0, "name": id.to_upper(), "desc": "", "color": Color.GRAY})
