extends CharacterBody3D
## First-person player. The owning peer moves it; position/look/flashlight are
## synced to everyone else. Alive/downed/dead is decided by the host.

const CardsDB := preload("res://player/cards.gd")
const Palette := preload("res://world/palette.gd")

const WALK := 3.2
const SPRINT := 5.8
const CROUCH := 1.6
const GRAVITY := 18.0
const DOWNED_TIME := 45.0
const PLAYER_COLORS := [Color("#c0392b"), Color("#2e86c1"), Color("#27ae60"), Color("#d4ac0d"), Color("#8e44ad")]

enum State { ALIVE, DOWNED, DEAD, GRABBED }

var peer_id := 1
var display_name := "Jugador"
var color_idx := 0
var cards: Array = []          # only filled in for the local player (secret)
var state := State.ALIVE
var game: Node = null

# Synced
var head_pitch := 0.0
var flashlight_on := true
var crouching := false
var noise := 0.0

# Local only
var stamina := 1.0
var battery := 1.0
var downed_timer := 0.0
var fear := 0.0
var interact_target: Node = null
var hold_progress := 0.0
var _step_accum := 0.0
var _last_pos := Vector3.ZERO
var _bell_cd := 0.0
var _sway_t := 0.0
var _hallu_cd := 25.0
var _whisper_cd := 30.0
var _heart_cd := 0.0
var _exhausted := false
var noclip := false            # dev tool: fly through walls

var head: Node3D
var camera: Camera3D
var flashlight: SpotLight3D
var hand: Node3D
var ray: RayCast3D
var body_root: Node3D
var name_label: Label3D
var sync: MultiplayerSynchronizer


func setup(id: int, info: Dictionary, my_cards: Array, game_node: Node) -> void:
	peer_id = id
	name = str(id)
	display_name = info.get("name", "Jugador")
	color_idx = int(info.get("color", 0))
	cards = my_cards
	game = game_node
	set_multiplayer_authority(id)


func is_local() -> bool:
	return peer_id == multiplayer.get_unique_id()


func has_card(id: String) -> bool:
	return id in cards


func _ready() -> void:
	add_to_group("players")
	collision_layer = 2
	collision_mask = 1 | 2
	floor_snap_length = 0.3

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.75
	col.shape = cap
	col.position.y = 0.875
	col.name = "Col"
	add_child(col)

	_build_body()

	head = Node3D.new()
	head.name = "Head"
	head.position.y = 1.6
	add_child(head)

	flashlight = SpotLight3D.new()
	flashlight.light_color = Color("#fff1d6")
	flashlight.light_energy = 3.2
	flashlight.spot_range = 9.0 if has_card("luna") else 18.0
	flashlight.spot_angle = 26.0
	flashlight.spot_attenuation = 0.8
	flashlight.shadow_enabled = is_local()
	flashlight.position = Vector3(0.15, -0.1, -0.1)
	head.add_child(flashlight)

	hand = Node3D.new()
	hand.position = Vector3(0.35, -0.35, -0.6)
	head.add_child(hand)

	if is_local():
		camera = Camera3D.new()
		camera.current = true
		camera.fov = Settings.fov
		camera.near = 0.05
		camera.far = 260.0
		camera.cull_mask = 0xFFFFF & ~(1 << 9)   # hide our own body (layer 10)
		head.add_child(camera)
		ray = RayCast3D.new()
		ray.target_position = Vector3(0, 0, -2.8)
		ray.collision_mask = 1 | 8
		ray.collide_with_areas = true
		ray.add_exception(self)
		camera.add_child(ray)
		Settings.changed.connect(_on_settings_changed)
	else:
		name_label = Label3D.new()
		name_label.text = display_name
		name_label.font_size = 36
		name_label.pixel_size = 0.008
		name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		name_label.no_depth_test = false
		name_label.position.y = 2.15
		name_label.modulate = PLAYER_COLORS[color_idx % PLAYER_COLORS.size()].lightened(0.3)
		add_child(name_label)

	# Revive / free-from-hand interaction target for teammates
	var area := Area3D.new()
	area.name = "Interact"
	area.collision_layer = 8
	area.collision_mask = 0
	var acol := CollisionShape3D.new()
	var ash := CapsuleShape3D.new()
	ash.radius = 0.5
	ash.height = 1.8
	acol.shape = ash
	acol.position.y = 0.9
	area.add_child(acol)
	area.set_meta("owner_node", self)
	add_child(area)

	sync = MultiplayerSynchronizer.new()
	sync.name = "Sync"
	var cfg := SceneReplicationConfig.new()
	for prop in [":position", ":rotation", ":head_pitch", ":flashlight_on", ":crouching", ":noise"]:
		var path := NodePath("." + prop)
		cfg.add_property(path)
		cfg.property_set_replication_mode(path, SceneReplicationConfig.REPLICATION_MODE_ALWAYS)
	sync.replication_config = cfg
	sync.root_path = NodePath("..")
	sync.replication_interval = 0.05
	add_child(sync)
	sync.set_multiplayer_authority(peer_id)
	_last_pos = global_position


func _build_body() -> void:
	body_root = Node3D.new()
	body_root.name = "Body"
	add_child(body_root)
	var c: Color = PLAYER_COLORS[color_idx % PLAYER_COLORS.size()]
	var parts := []
	var torso := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = 0.33
	cm.height = 1.4
	cm.radial_segments = 8
	cm.rings = 2
	torso.mesh = cm
	torso.material_override = Palette.color(c.darkened(0.25))
	torso.position.y = 0.75
	parts.append(torso)
	var headm := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.2
	sm.height = 0.4
	sm.radial_segments = 8
	sm.rings = 4
	headm.mesh = sm
	headm.material_override = Palette.color(Color("#b07c55"))
	headm.position.y = 1.6
	parts.append(headm)
	var brim := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.42
	bm.bottom_radius = 0.42
	bm.height = 0.04
	bm.radial_segments = 10
	brim.mesh = bm
	brim.material_override = Palette.color(c)
	brim.position.y = 1.76
	parts.append(brim)
	var crown := MeshInstance3D.new()
	var crm := CylinderMesh.new()
	crm.top_radius = 0.1
	crm.bottom_radius = 0.2
	crm.height = 0.28
	crm.radial_segments = 8
	crown.mesh = crm
	crown.material_override = Palette.color(c)
	crown.position.y = 1.9
	parts.append(crown)
	for p in parts:
		body_root.add_child(p)
		if is_local():
			p.layers = 1 << 9


# --- Per-frame -------------------------------------------------------------------

func _physics_process(delta: float) -> void:
	if is_local():
		_local_physics(delta)
	head.rotation.x = head_pitch
	flashlight.visible = flashlight_on and state != State.DEAD and battery > 0.0
	body_root.visible = state != State.DEAD
	if name_label:
		name_label.visible = state != State.DEAD
	body_root.rotation.x = -PI * 0.42 if state == State.DOWNED else 0.0
	body_root.position.y = 0.3 if state == State.DOWNED else 0.0
	body_root.scale.y = 0.75 if crouching else 1.0
	_footsteps(delta)


func _local_physics(delta: float) -> void:
	var captured := Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
	var input := Vector2.ZERO
	if captured:
		input = Input.get_vector("move_left", "move_right", "move_forward", "move_back")

	if state == State.DEAD or noclip:
		_ghost_move(input, delta)
		return

	var can_move := state == State.ALIVE
	crouching = can_move and captured and Input.is_action_pressed("crouch")
	var wants_sprint := can_move and captured and Input.is_action_pressed("sprint") and input.y < 0.0 and not crouching
	var carry_mult: float = game.carry_speed_mult(peer_id) if game else 1.0
	if carry_mult < 1.0:
		wants_sprint = false

	# Stamina (El Alacrán: poisoned)
	var drain := 0.45 if has_card("alacran") else 0.22
	var regen := 0.07 if has_card("alacran") else 0.17
	var sprinting := wants_sprint and stamina > 0.0 and not _exhausted
	if sprinting:
		stamina = maxf(0.0, stamina - drain * delta)
		if stamina <= 0.0:
			_exhausted = true
	else:
		stamina = minf(1.0, stamina + regen * delta)
		if stamina > 0.35:
			_exhausted = false

	var speed := WALK
	if sprinting:
		speed = SPRINT
	elif crouching:
		speed = CROUCH
	speed *= carry_mult
	if not can_move:
		speed = 0.0

	# El Borracho: input drifts sideways
	if has_card("borracho") and input.length() > 0.1:
		_sway_t += delta
		input.x += sin(_sway_t * 1.1) * 0.35
	var dir := (global_transform.basis * Vector3(input.x, 0, input.y))
	dir.y = 0
	dir = dir.normalized() if dir.length() > 0.01 else Vector3.ZERO
	velocity.x = dir.x * speed
	velocity.z = dir.z * speed
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = -0.5
	move_and_slide()
	if global_position.y < -10.0:
		global_position = Vector3(0, 1, 9)

	# Noise level the creatures listen for (host reads this)
	var n := 0.5
	var horiz := Vector2(velocity.x, velocity.z).length()
	if horiz > 0.1:
		n = 2.0 if crouching else (14.0 if sprinting else 6.0)
	if has_card("corazon"):
		n *= 2.0
	if has_card("campana") and sprinting:
		n *= 2.0
		_bell_cd -= delta
		if _bell_cd <= 0.0:
			_bell_cd = 0.9
			game.rpc_bell(peer_id)
	noise = n

	# Flashlight battery (La Luna drains twice as fast)
	if flashlight_on and battery > 0.0:
		battery = maxf(0.0, battery - delta / (130.0 if has_card("luna") else 260.0))
	flashlight.light_energy = (2.0 if has_card("luna") else 3.2) * (0.4 + 0.6 * clampf(battery * 3.0, 0.0, 1.0))
	if battery < 0.15 and flashlight_on and randf() < 0.05:
		flashlight.light_energy *= 0.2   # flicker when nearly dead

	# Camera height for crouch / downed
	var target_h := 1.6
	if crouching:
		target_h = 1.0
	if state == State.DOWNED:
		target_h = 0.4
	head.position.y = lerpf(head.position.y, target_h, 10.0 * delta)

	# Card effects that only the local player experiences
	if camera:
		camera.rotation.z = sin(Time.get_ticks_msec() * 0.0012) * 0.06 if has_card("borracho") else 0.0
	_update_fear(delta)
	_card_events(delta)
	_update_interaction(delta)

	if state == State.DOWNED:
		downed_timer -= delta
	if state == State.GRABBED:
		head_pitch = lerpf(head_pitch, -0.95, 3.0 * delta)   # forced to look down at it


func _ghost_move(input: Vector2, delta: float) -> void:
	var dir := camera.global_transform.basis * Vector3(input.x, 0, input.y)
	var up := 0.0
	if Input.is_action_pressed("sprint"):
		up += 1.0
	if Input.is_action_pressed("crouch"):
		up -= 1.0
	global_position += (dir.normalized() * 7.0 + Vector3.UP * up * 4.0) * delta if dir.length() > 0.01 or up != 0.0 else Vector3.ZERO
	noise = 0.0
	interact_target = null
	hold_progress = 0.0


## Mouse look uses _input (not _unhandled_input) so no UI element can swallow it.
func _input(event: InputEvent) -> void:
	if not is_local() or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	if event is InputEventMouseMotion:
		if state == State.GRABBED:
			return   # it's holding your head down
		var s := Settings.mouse_sensitivity * 0.01
		rotate_y(-event.relative.x * s)
		var dy: float = event.relative.y * s * (-1.0 if Settings.invert_y else 1.0)
		head_pitch = clampf(head_pitch - dy, deg_to_rad(-85), deg_to_rad(85))


func _unhandled_input(event: InputEvent) -> void:
	if not is_local() or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED:
		return
	if event.is_action_pressed("flashlight") and state != State.DEAD:
		if game and game.carry_speed_mult(peer_id) < 1.0:
			game.toast_local("You can't hold a light while carrying the coffin.")
		else:
			flashlight_on = not flashlight_on
			Sfx.play("click", -6.0)
	elif event.is_action_pressed("drop") and state == State.ALIVE:
		game.request_drop()


func _on_settings_changed() -> void:
	if camera:
		camera.fov = Settings.fov


# --- Interaction -------------------------------------------------------------------

func _update_interaction(delta: float) -> void:
	interact_target = null
	if state == State.DEAD or Input.mouse_mode != Input.MOUSE_MODE_CAPTURED or (game.hud and game.hud.blocking()):
		hold_progress = 0.0
		return
	if state == State.GRABBED:
		# Struggle free by mashing E
		if Input.is_action_just_pressed("interact"):
			game.request_struggle()
		return
	if state == State.DOWNED:
		# Pick yourself up if you have lives left (lobby option)
		if int(game.lives.get(peer_id, 0)) > 0 and Input.is_action_pressed("interact"):
			hold_progress += delta / 4.0
			if hold_progress >= 1.0:
				hold_progress = 0.0
				game.request_self_revive()
		else:
			hold_progress = 0.0
		return
	if state != State.ALIVE:
		hold_progress = 0.0
		return
	ray.force_raycast_update()
	if ray.is_colliding():
		var c := ray.get_collider()
		var node: Node = c.get_meta("owner_node") if c and c.has_meta("owner_node") else null
		if node and node != self and node.has_method("get_prompt") and node.get_prompt(self) != "":
			interact_target = node
	if interact_target == null:
		hold_progress = 0.0
		return
	var hold_time: float = interact_target.hold_time(self) if interact_target.has_method("hold_time") else 0.0
	if hold_time <= 0.0:
		if Input.is_action_just_pressed("interact"):
			game.request_interact(interact_target)
		hold_progress = 0.0
	else:
		if Input.is_action_pressed("interact"):
			hold_progress += delta / hold_time
			if hold_progress >= 1.0:
				hold_progress = 0.0
				game.request_interact(interact_target)
		else:
			hold_progress = 0.0


## Prompt shown to a teammate looking at this player.
func get_prompt(other) -> String:
	if state == State.DOWNED:
		return "Hold [E] to revive %s" % display_name
	if state == State.GRABBED:
		return "Hold [E] to pull %s free" % display_name
	return ""


func hold_time(_other) -> float:
	return 3.0 if state == State.DOWNED else 1.0


# --- Fear, hallucinations, voices -----------------------------------------------------

func _update_fear(delta: float) -> void:
	var nearest := 999.0
	for c in get_tree().get_nodes_in_group("creature"):
		if c.visible and c.is_active():
			nearest = minf(nearest, c.global_position.distance_to(global_position))
	var target := clampf(1.0 - (nearest - 4.0) / 18.0, 0.0, 1.0)
	fear = lerpf(fear, target, 2.0 * delta)
	if has_card("corazon"):
		_heart_cd -= delta
		if _heart_cd <= 0.0:
			_heart_cd = lerpf(1.1, 0.42, fear)
			Sfx.play("heartbeat", lerpf(-12.0, 0.0, fear))


func _card_events(delta: float) -> void:
	if state == State.DEAD:
		return
	if has_card("diablito"):
		_hallu_cd -= delta
		if _hallu_cd <= 0.0:
			_hallu_cd = randf_range(18.0, 38.0)
			game.spawn_hallucination(self)
	if has_card("sirena"):
		_whisper_cd -= delta
		if _whisper_cd <= 0.0:
			_whisper_cd = randf_range(22.0, 45.0)
			var a := randf() * TAU
			var p := global_position + Vector3(cos(a), 0.3, sin(a)) * randf_range(6.0, 12.0)
			Sfx.play_at("whisper", p, game, 6.0, randf_range(0.85, 1.1), 30.0)
			game.toast_local("…%s…  (someone whispers your name)" % display_name.to_lower())


func _footsteps(delta: float) -> void:
	if state == State.DEAD or not game:
		_last_pos = global_position
		return
	var moved := Vector2(global_position.x - _last_pos.x, global_position.z - _last_pos.z).length()
	_last_pos = global_position
	if moved > 0.5:   # teleport / sync jump
		return
	_step_accum += moved
	var stride := 1.3 if crouching else 2.0
	if _step_accum > stride:
		_step_accum = 0.0
		var vol := -18.0 if crouching else -8.0
		if is_local():
			Sfx.play("step", vol, randf_range(0.9, 1.1))
		else:
			Sfx.play_at("step", global_position, game, vol + 4.0, randf_range(0.9, 1.1), 25.0)


# --- State changes (called on every peer by the game) ---------------------------------

func set_state(s: int) -> void:
	state = s
	var col := get_node_or_null("Col") as CollisionShape3D
	if col:
		col.disabled = s == State.DEAD
	if s == State.DOWNED:
		downed_timer = DOWNED_TIME
	if is_local():
		if s == State.DEAD:
			flashlight_on = false
		hold_progress = 0.0


func refill_battery() -> void:
	battery = 1.0
