extends PanelContainer
## F1 dev menu for playtesting (solo or host only). Teleport, poke the
## creatures, skip time, bring items, peek at the answer, swap your card.

const Style := preload("res://ui/style.gd")
const CardsDB := preload("res://player/cards.gd")
const PlayerScript := preload("res://player/player.gd")

var game: Node
var answer_label: Label
var status_label: Label
var _toggles := {}



func setup(g: Node) -> void:
	game = g


func _ready() -> void:
	theme = Style.theme()
	custom_minimum_size = Vector2(430, 0)
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(420, 640)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(sc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(v)
	v.add_child(Style.label("DEV MENU  ·  F1", 22, Style.MARIGOLD))
	status_label = Style.label("", 13, Style.DIM)
	v.add_child(status_label)

	_section(v, "Teleport")
	var tg := _grid(v, 3)
	for s in game.map.teleports:
		var pos: Vector3 = s[1]
		tg.add_child(_btn(s[0], func(): game.dev_teleport(pos)))

	_section(v, "Creatures")
	var cg := _grid(v, 2)
	cg.add_child(_btn("Summon Llorona", func(): game.dev_summon("Llorona")))
	cg.add_child(_btn("Lechuza whistles", func(): game.dev_summon("Lechuza")))
	cg.add_child(_btn("Wake La Mano", func(): game.dev_summon("Mano")))
	cg.add_child(_toggle("Freeze creatures", func(on): game.dev_freeze(on)))
	cg.add_child(_toggle("Show on map / F3", func(on): Settings.set_value("show_debug", on), Settings.show_debug))

	_section(v, "Time")
	var tg2 := _grid(v, 3)
	tg2.add_child(_btn("+30 min", func(): game.dev_skip(game.night_seconds / 12.0)))
	tg2.add_child(_btn("Go to 5:50", func(): game.dev_skip(game.night_seconds * (350.0 / 360.0) - game.elapsed)))
	tg2.add_child(_toggle("Pause objective", func(on): game.mode_paused = on))
	for sp in [1.0, 2.0, 4.0]:
		var speed: float = sp
		tg2.add_child(_btn("Speed ×%d" % int(sp), func(): Engine.time_scale = speed))

	_section(v, "Items")
	var ig := _grid(v, 2)
	ig.add_child(_btn("Bring next objective item", _bring_next))
	ig.add_child(_btn("Bring matches", func(): game.dev_bring("cerillos")))
	ig.add_child(_btn("Bring batteries", func(): game.dev_bring("pilas")))
	ig.add_child(_btn("Refill flashlight", func(): game.local_player().refill_battery()))

	_section(v, "Answer (spoiler)")
	v.add_child(_btn("Reveal this night's answer", _reveal))
	answer_label = Style.label("", 15, Color("#f2d9a6"))
	answer_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	answer_label.custom_minimum_size.x = 400
	v.add_child(answer_label)

	_section(v, "Your Lotería card")
	var card_opt := OptionButton.new()
	card_opt.add_item("No card")
	for id in CardsDB.ALL:
		card_opt.add_item(CardsDB.info(id)["name"])
	var me: Node = game.local_player()
	if me and not me.cards.is_empty():
		card_opt.select(CardsDB.ALL.find(me.cards[0]) + 1)
	card_opt.item_selected.connect(func(i): game.dev_set_card("" if i == 0 else CardsDB.ALL[i - 1]))
	v.add_child(card_opt)

	_section(v, "You")
	var pg := _grid(v, 2)
	pg.add_child(_toggle("God mode", func(on): Settings.set_value("invincible", on), Settings.invincible))
	pg.add_child(_toggle("Noclip (fly)", func(on): game.local_player().noclip = on))
	pg.add_child(_btn("Revive me", func(): game.server_set_state(game.multiplayer.get_unique_id(), PlayerScript.State.ALIVE)))
	pg.add_child(_btn("Knock me down", _knock_down))

	_section(v, "End the night")
	var eg := _grid(v, 2)
	eg.add_child(_btn("Force WIN", func(): game.server_end(true, "Forced win (dev menu).")))
	eg.add_child(_btn("Force LOSS", func(): game.server_end(false, "Forced loss (dev menu).")))


func _bring_next() -> void:
	var n: String = game.mode.dev_next_item()
	if n == "":
		game.toast_local("Nothing left to bring.")
	else:
		game.dev_bring(n)


func _reveal() -> void:
	var a: String = game.mode.dev_answer()
	answer_label.text = a if a != "" else "No hidden answer in this mode."


func _knock_down() -> void:
	var was: bool = Settings.invincible
	Settings.invincible = false
	game.server_down_player(game.multiplayer.get_unique_id(), "Dev menu.")
	Settings.invincible = was


func _process(_delta: float) -> void:
	if visible and game:
		var me: Node = game.local_player()
		status_label.text = "%s · seed %s · %s · speed ×%.0f%s" % [game.mode.title(), str(game.config.get("seed", 0)), game.clock_text(),
			Engine.time_scale, ("  · pos %s" % str(me.global_position.snapped(Vector3.ONE))) if me else ""]


func _section(v: VBoxContainer, text: String) -> void:
	var l := Style.label(text.to_upper(), 13, Style.DIM)
	v.add_child(l)


func _grid(v: VBoxContainer, cols: int) -> GridContainer:
	var g := GridContainer.new()
	g.columns = cols
	g.add_theme_constant_override("h_separation", 6)
	g.add_theme_constant_override("v_separation", 6)
	v.add_child(g)
	return g


func _btn(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_size_override("font_size", 14)
	b.custom_minimum_size = Vector2(0, 34)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.pressed.connect(func(): Sfx.play("click", -8.0))
	b.pressed.connect(cb)
	return b


func _toggle(text: String, cb: Callable, start := false) -> CheckButton:
	var c := CheckButton.new()
	c.text = text
	c.add_theme_font_size_override("font_size", 14)
	c.button_pressed = start
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	c.toggled.connect(cb)
	return c
