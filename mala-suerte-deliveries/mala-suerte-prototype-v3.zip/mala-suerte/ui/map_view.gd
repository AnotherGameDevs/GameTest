extends Control
## Hand-drawn style map of the pueblo (hold or toggle [M]).
## Shows buildings, you and your friends, and the mode's points of interest.
## Creatures only appear when debug info (F3) is on.

const Style := preload("res://ui/style.gd")

var game: Node


func _process(_delta: float) -> void:
	if visible:
		queue_redraw()


func _w2m(p: Vector3, area: Rect2, b: AABB) -> Vector2:
	# World X -> map x, world Z -> map y (north = +Z = up)
	var u := (p.x - b.position.x) / b.size.x
	var v := 1.0 - (p.z - b.position.z) / b.size.z
	return area.position + Vector2(u * area.size.x, v * area.size.y)


func _draw() -> void:
	if game == null or game.map == null:
		return
	var b: AABB = game.map.BOUNDS
	draw_rect(Rect2(Vector2.ZERO, size), Color(0, 0, 0, 0.78))     # dim the game behind
	var aspect := b.size.x / b.size.z
	var h := size.y - 90.0
	var w := h * aspect
	var area := Rect2((size.x - w) * 0.5, 50.0, w, h)
	draw_rect(area.grow(10), Color("#e3d6b6"))                      # paper
	draw_rect(area.grow(10), Color("#4a3a2a"), false, 3.0)
	draw_rect(area, Color("#cdbb92"))
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(area.position.x - 10, 30), "EL PUEBLO", HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Style.MARIGOLD)
	draw_string(font, Vector2(area.end.x - 30, 30), "N ↑", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Style.BONE)
	for r in game.map.map_rects:
		var rect: Rect2 = r[0]
		var a := _w2m(Vector3(rect.position.x, 0, rect.end.y), area, b)
		var c := _w2m(Vector3(rect.end.x, 0, rect.position.y), area, b)
		var mr := Rect2(a, c - a).abs()
		var col: Color = r[1]
		draw_rect(mr, col.darkened(0.2))
		draw_rect(mr, Color("#2a2018"), false, 1.5)
		var label: String = r[2]
		if label != "":
			var tw := font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, 12).x
			draw_string(font, Vector2(mr.get_center().x - tw * 0.5, mr.position.y - 3), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#2a2018"))
	# Points of interest
	for mk in game.mode.map_markers():
		var mp := _w2m(mk[0], area, b)
		draw_circle(mp, 7, Color(0, 0, 0, 0.6))
		draw_circle(mp, 5, mk[2])
		draw_string(font, mp + Vector2(9, 5), mk[1], HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#1a1210"))
	# Creatures (debug only)
	if Settings.show_debug:
		for cr in game.creatures_root.get_children():
			if cr.active:
				var cp := _w2m(cr.global_position, area, b)
				draw_circle(cp, 5, Color("#b3202a"))
				draw_string(font, cp + Vector2(7, -6), String(cr.name), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#b3202a"))
	# Players as arrows
	var me: Node = game.local_player()
	for p in game.get_players():
		if p.state == p.State.DEAD:
			continue
		var pp := _w2m(p.global_position, area, b)
		var fwd: Vector3 = -p.global_transform.basis.z
		var d := Vector2(fwd.x, -fwd.z).normalized()
		var side := Vector2(-d.y, d.x)
		var col: Color = p.PLAYER_COLORS[p.color_idx % p.PLAYER_COLORS.size()]
		var s := 9.0 if p == me else 7.0
		draw_colored_polygon(PackedVector2Array([pp + d * s, pp - d * s * 0.6 + side * s * 0.6, pp - d * s * 0.6 - side * s * 0.6]), col)
		if p == me:
			draw_arc(pp, s + 4, 0, TAU, 16, Color.WHITE, 1.5)
	draw_string(font, Vector2(area.position.x, area.end.y + 28), "[M] close", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Style.DIM)
