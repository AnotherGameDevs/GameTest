extends PanelContainer
## Settings screen (used from the main menu and the in-game pause menu).
## Every change saves immediately.

signal closed

const Style := preload("res://ui/style.gd")

var _box: VBoxContainer


func _ready() -> void:
	theme = Style.theme()
	custom_minimum_size = Vector2(620, 560)
	var outer := VBoxContainer.new()
	outer.add_theme_constant_override("separation", 10)
	add_child(outer)
	outer.add_child(Style.label("AJUSTES · SETTINGS", 28, Style.MARIGOLD))
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer.add_child(scroll)
	_box = VBoxContainer.new()
	_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_box.add_theme_constant_override("separation", 6)
	scroll.add_child(_box)

	_section("Audio")
	_slider("Master volume", "master_volume", 0.0, 1.0, 0.05, true)
	_slider("Ambience (wind, drones)", "ambience_volume", 0.0, 1.0, 0.05, true)
	_slider("Sound effects", "sfx_volume", 0.0, 1.0, 0.05, true)

	_section("PS1 look")
	_toggle("Pixelation", "pixelation")
	_slider("Pixel size", "pixel_size", 2, 6, 1)
	_toggle("Color dithering", "dithering")
	_toggle("Vertex wobble", "vertex_wobble")

	_section("Display")
	_toggle("Fullscreen", "fullscreen")
	_toggle("VSync", "vsync")
	_slider("Brightness", "brightness", 0.6, 1.8, 0.05)
	_slider("Field of view", "fov", 60, 100, 1)

	_section("Controls")
	_slider("Mouse sensitivity", "mouse_sensitivity", 0.05, 1.0, 0.01)
	_toggle("Invert mouse Y", "invert_y")

	_section("Testing")
	_toggle("Invincible (solo / host only)", "invincible")
	_toggle("Show debug info (F3)", "show_debug")

	var back := Style.button("Back", func(): closed.emit())
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	outer.add_child(back)


func _section(text: String) -> void:
	var l := Style.label(text.to_upper(), 16, Style.DIM)
	l.add_theme_constant_override("line_spacing", 0)
	var spacer := Control.new()
	spacer.custom_minimum_size.y = 6
	_box.add_child(spacer)
	_box.add_child(l)


func _row(text: String) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var l := Style.label(text, 18)
	l.custom_minimum_size.x = 260
	row.add_child(l)
	_box.add_child(row)
	return row


func _slider(text: String, key: String, mn: float, mx: float, step: float, percent := false) -> void:
	var row := _row(text)
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = step
	s.value = float(Settings.get(key))
	s.custom_minimum_size = Vector2(200, 24)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(s)
	var val := Style.label("", 16, Style.DIM)
	val.custom_minimum_size.x = 56
	row.add_child(val)
	var fmt := func(v: float) -> String:
		if percent:
			return "%d%%" % int(round(v * 100.0))
		return str(int(v)) if step >= 1.0 else "%.2f" % v
	val.text = fmt.call(s.value)
	s.value_changed.connect(func(v: float):
		val.text = fmt.call(v)
		Settings.set_value(key, int(v) if step >= 1.0 else v))


func _toggle(text: String, key: String) -> void:
	var row := _row(text)
	var c := CheckButton.new()
	c.button_pressed = bool(Settings.get(key))
	c.toggled.connect(func(on: bool):
		Sfx.play("click", -6.0)
		Settings.set_value(key, on))
	row.add_child(c)
