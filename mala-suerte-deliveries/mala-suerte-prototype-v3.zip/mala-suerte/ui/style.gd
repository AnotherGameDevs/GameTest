extends RefCounted
## Shared UI look: dark wood, bone text, marigold accents.

const BG := Color("#0d0a0b")
const PANEL := Color("#18120f")
const BONE := Color("#ebe1c8")
const DIM := Color("#9c907a")
const MARIGOLD := Color("#e8a33d")
const BLOOD := Color("#b3202a")

static var _theme: Theme


static func theme() -> Theme:
	if _theme:
		return _theme
	var t := Theme.new()
	t.default_font_size = 18
	var normal := _box(Color("#221915"), Color("#4a3a2c"))
	var hover := _box(Color("#2e2119"), MARIGOLD)
	var pressed := _box(Color("#3a2a1e"), MARIGOLD)
	var disabled := _box(Color("#151110"), Color("#2a221c"))
	for cls in ["Button", "OptionButton", "CheckButton"]:
		t.set_stylebox("normal", cls, normal)
		t.set_stylebox("hover", cls, hover)
		t.set_stylebox("pressed", cls, pressed)
		t.set_stylebox("disabled", cls, disabled)
		t.set_stylebox("focus", cls, _box(Color(0, 0, 0, 0), MARIGOLD))
		t.set_color("font_color", cls, BONE)
		t.set_color("font_hover_color", cls, MARIGOLD)
		t.set_color("font_pressed_color", cls, MARIGOLD)
		t.set_color("font_disabled_color", cls, Color("#5a5048"))
	t.set_stylebox("normal", "LineEdit", _box(Color("#120e0c"), Color("#4a3a2c")))
	t.set_stylebox("focus", "LineEdit", _box(Color("#120e0c"), MARIGOLD))
	t.set_color("font_color", "LineEdit", BONE)
	t.set_color("font_color", "Label", BONE)
	t.set_stylebox("panel", "PanelContainer", _box(Color(0.07, 0.05, 0.045, 0.94), Color("#3a2c22"), 2, 14))
	t.set_stylebox("panel", "Panel", _box(Color(0.07, 0.05, 0.045, 0.94), Color("#3a2c22"), 2, 14))
	var slider_bg := StyleBoxFlat.new()
	slider_bg.bg_color = Color("#2a201a")
	slider_bg.content_margin_top = 3
	slider_bg.content_margin_bottom = 3
	t.set_stylebox("slider", "HSlider", slider_bg)
	var fill := StyleBoxFlat.new()
	fill.bg_color = MARIGOLD.darkened(0.2)
	fill.content_margin_top = 3
	fill.content_margin_bottom = 3
	t.set_stylebox("grabber_area", "HSlider", fill)
	t.set_stylebox("grabber_area_highlight", "HSlider", fill)
	var pb_bg := StyleBoxFlat.new()
	pb_bg.bg_color = Color(0, 0, 0, 0.5)
	var pb_fill := StyleBoxFlat.new()
	pb_fill.bg_color = BONE
	t.set_stylebox("background", "ProgressBar", pb_bg)
	t.set_stylebox("fill", "ProgressBar", pb_fill)
	t.set_font_size("font_size", "ProgressBar", 1)
	_theme = t
	return t


static func _box(bg: Color, border: Color, bw := 2, margin := 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.content_margin_left = margin + 4
	s.content_margin_right = margin + 4
	s.content_margin_top = margin * 0.6
	s.content_margin_bottom = margin * 0.6
	return s


static func label(text: String, size := 18, color := BONE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func button(text: String, cb: Callable, min_w := 220) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(min_w, 44)
	b.pressed.connect(func(): Sfx.play("click", -4.0))
	b.pressed.connect(cb)
	return b


## Anchor a control to a point of its parent (0..1) and offset it in pixels.
static func place(c: Control, ax: float, ay: float, x: float, y: float, w := 0.0, h := 0.0) -> void:
	c.anchor_left = ax
	c.anchor_right = ax
	c.anchor_top = ay
	c.anchor_bottom = ay
	c.offset_left = x
	c.offset_top = y
	c.offset_right = x + w
	c.offset_bottom = y + h
