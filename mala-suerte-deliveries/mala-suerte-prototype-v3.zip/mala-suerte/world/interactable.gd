extends Node3D
## Something a player can look at and press E on.
## The `handler` (usually the game mode) decides the prompt and what happens.
## Interactions are sent to the host, which runs `handler.on_interact`.

var key := ""                 # identifier the handler understands
var handler: Object = null
var area: Area3D


func setup(k: String, h: Object, shape_size := Vector3(0.8, 0.8, 0.8), shape_offset := Vector3.ZERO) -> void:
	key = k
	handler = h
	name = k
	area = Area3D.new()
	area.collision_layer = 8
	area.collision_mask = 0
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = shape_size
	cs.shape = sh
	cs.position = shape_offset
	area.add_child(cs)
	area.set_meta("owner_node", self)
	add_child(area)
	add_to_group("interactables")


func get_prompt(player) -> String:
	if has_meta("note_title"):
		return "[E] Read: %s" % get_meta("note_title")
	if handler and handler.has_method("prompt_for"):
		return handler.prompt_for(self, player)
	return ""


func hold_time(player) -> float:
	if handler and handler.has_method("hold_for"):
		return handler.hold_for(self, player)
	return 0.0


## Host only.
func server_interact(peer_id: int) -> void:
	if handler and handler.has_method("on_interact"):
		handler.on_interact(self, peer_id)
