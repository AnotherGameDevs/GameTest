extends "res://world/interactable.gd"
## A pickup. The host owns its state (who holds it, placed, used up) and
## broadcasts it; every peer just renders what the host says.

const Palette := preload("res://world/palette.gd")

const NAMES := {
	"cerillos": "Matches", "pilas": "Batteries", "coffin": "Coffin",
	"sombrero": "Sombrero", "tequila": "Bottle of tequila", "guitarra": "Old guitar", "cigarros": "Pack of cigarros",
	"rosario": "Rosary", "costurero": "Sewing tin", "cafe": "Cup of café de olla", "pan": "Pan dulce",
	"baraja": "Deck of cards", "radio": "Transistor radio", "cerveza": "Bottle of beer", "gorra": "Baseball cap",
	"huevo": "Egg", "ruda": "Ruda (rue)", "romero": "Romero (rosemary)", "albahaca": "Albahaca (basil)", "copal": "Copal resin",
}

var kind := ""
var holder := 0          # peer id holding it, 0 = nobody
var placed := false      # set down on an altar
var consumed := false    # used up / gone
var home := Vector3.ZERO # where it spawned (wrong offerings return here)
var visual: Node3D


func setup_item(item_name: String, item_kind: String, h: Object) -> void:
	kind = item_kind
	var big := kind == "coffin"
	setup(item_name, h, Vector3(2.2, 0.8, 0.9) if big else Vector3(0.6, 0.6, 0.6), Vector3(0, 0.3, 0) if big else Vector3.ZERO)
	visual = _build_visual(kind)
	add_child(visual)
	add_to_group("items")


func display_name() -> String:
	return NAMES.get(kind, kind.capitalize())


func apply_state(h: int, p: bool, c: bool, pos: Vector3) -> void:
	holder = h
	placed = p
	consumed = c
	visible = not c
	area.collision_layer = 8 if (holder == 0 and not c) else 0
	if holder == 0:
		global_position = pos
		rotation = Vector3.ZERO


func _process(_delta: float) -> void:
	if holder == 0 or consumed:
		return
	var pl: Node = get_tree().get_first_node_in_group("game").get_player(holder) if is_inside_tree() else null
	if pl == null:
		return
	if kind == "coffin":
		var fwd: Vector3 = -pl.global_transform.basis.z
		global_position = pl.global_position + fwd * 1.0 + Vector3.UP * 0.75
		global_rotation = Vector3(0, pl.global_rotation.y + PI * 0.5, 0)
	else:
		global_transform = pl.hand.global_transform


func _mesh(m: Mesh, mat: Material, pos := Vector3.ZERO, rot := Vector3.ZERO, scl := Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = m
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot
	mi.scale = scl
	return mi


func _boxm(s: Vector3) -> BoxMesh:
	var b := BoxMesh.new()
	b.size = s
	return b


func _cylm(r: float, h: float, tr := -1.0) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.bottom_radius = r
	c.top_radius = r if tr < 0.0 else tr
	c.height = h
	c.radial_segments = 8
	c.rings = 1
	return c


func _sphm(r: float) -> SphereMesh:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = 8
	s.rings = 4
	return s


func _build_visual(k: String) -> Node3D:
	var root := Node3D.new()
	var glow := 0.25   # items glow a touch so they're findable in the dark
	match k:
		"cerillos":
			root.add_child(_mesh(_boxm(Vector3(0.18, 0.05, 0.1)), Palette.color(Color("#c0392b"), glow)))
		"pilas":
			root.add_child(_mesh(_cylm(0.03, 0.14), Palette.color(Color("#d4ac0d"), glow), Vector3(-0.04, 0, 0), Vector3(0, 0, 90)))
			root.add_child(_mesh(_cylm(0.03, 0.14), Palette.color(Color("#d4ac0d"), glow), Vector3(0.04, 0, 0), Vector3(0, 0, 90)))
		"coffin":
			root.add_child(_mesh(_boxm(Vector3(2.1, 0.55, 0.7)), Palette.surface("wood")))
			root.add_child(_mesh(_boxm(Vector3(0.7, 0.04, 0.08)), Palette.color(Color("#d6c08a"), 0.3), Vector3(0, 0.3, 0)))
			root.add_child(_mesh(_boxm(Vector3(0.08, 0.04, 0.4)), Palette.color(Color("#d6c08a"), 0.3), Vector3(-0.15, 0.3, 0)))
		"sombrero":
			root.add_child(_mesh(_cylm(0.32, 0.03), Palette.color(Color("#c9a86a"), glow)))
			root.add_child(_mesh(_cylm(0.12, 0.18, 0.08), Palette.color(Color("#c9a86a"), glow), Vector3(0, 0.1, 0)))
		"tequila", "cerveza":
			var bc := Color("#cfe3d0") if k == "tequila" else Color("#8a5a1a")
			root.add_child(_mesh(_cylm(0.05, 0.22), Palette.color(bc, glow)))
			root.add_child(_mesh(_cylm(0.02, 0.1), Palette.color(bc, glow), Vector3(0, 0.15, 0)))
		"guitarra":
			root.add_child(_mesh(_sphm(0.16), Palette.color(Color("#a0642c"), glow), Vector3.ZERO, Vector3.ZERO, Vector3(1, 1.2, 0.35)))
			root.add_child(_mesh(_boxm(Vector3(0.05, 0.45, 0.03)), Palette.color(Color("#5a3a1a"), glow), Vector3(0, 0.38, 0)))
		"cigarros", "baraja":
			root.add_child(_mesh(_boxm(Vector3(0.1, 0.03, 0.14)), Palette.color(Color("#eeeeee") if k == "cigarros" else Color("#2a4aa8"), glow)))
		"rosario":
			var t := TorusMesh.new()
			t.inner_radius = 0.07
			t.outer_radius = 0.09
			t.rings = 8
			t.ring_segments = 4
			root.add_child(_mesh(t, Palette.color(Color("#5a3a2a"), glow)))
			root.add_child(_mesh(_boxm(Vector3(0.02, 0.07, 0.02)), Palette.color(Color("#d6c08a"), glow), Vector3(0, 0, 0.12)))
		"costurero":
			root.add_child(_mesh(_cylm(0.12, 0.07), Palette.color(Color("#2e5a9a"), glow)))
		"cafe":
			root.add_child(_mesh(_cylm(0.05, 0.09, 0.06), Palette.color(Color("#b5552e"), glow)))
		"pan":
			root.add_child(_mesh(_sphm(0.08), Palette.color(Color("#d9a35a"), glow), Vector3.ZERO, Vector3.ZERO, Vector3(1, 0.6, 1)))
		"radio":
			root.add_child(_mesh(_boxm(Vector3(0.22, 0.14, 0.08)), Palette.color(Color("#7a7a6a"), glow)))
		"gorra":
			root.add_child(_mesh(_sphm(0.1), Palette.color(Color("#a83232"), glow), Vector3.ZERO, Vector3.ZERO, Vector3(1, 0.6, 1)))
			root.add_child(_mesh(_boxm(Vector3(0.12, 0.01, 0.1)), Palette.color(Color("#a83232"), glow), Vector3(0, -0.02, 0.1)))
		"huevo":
			root.add_child(_mesh(_sphm(0.04), Palette.color(Color("#f2ead8"), glow), Vector3.ZERO, Vector3.ZERO, Vector3(1, 1.3, 1)))
		"ruda", "romero", "albahaca":
			var hc: Color = {"ruda": Color("#6b8f3a"), "romero": Color("#4a6b4a"), "albahaca": Color("#3fa33f")}[k]
			for i in 3:
				root.add_child(_mesh(_cylm(0.04, 0.22, 0.0), Palette.color(hc, glow), Vector3((i - 1) * 0.04, 0.08, 0)))
			root.add_child(_mesh(_boxm(Vector3(0.1, 0.02, 0.02)), Palette.color(Color("#d6c08a"), glow)))
		"copal":
			root.add_child(_mesh(_boxm(Vector3(0.09, 0.06, 0.07)), Palette.color(Color("#e0b84a"), 0.4), Vector3.ZERO, Vector3(20, 30, 0)))
		_:
			root.add_child(_mesh(_boxm(Vector3(0.15, 0.15, 0.15)), Palette.color(Color.MAGENTA, glow)))
	return root
