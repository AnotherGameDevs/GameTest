extends RefCounted
## Materials for the greybox world, all using the PS1 shader.
## Textures are tiny generated noise images so everything has that crunchy grain.

const PS1 := preload("res://shaders/ps1.gdshader")

static var _cache := {}
static var _all: Array[ShaderMaterial] = []

const SURFACES := {
	"dirt": {"color": Color("#4a3a2a"), "tex": "speckle", "scale": 0.5},
	"road": {"color": Color("#5c4a35"), "tex": "speckle", "scale": 0.6, "bias": 0.0004},
	"adobe": {"color": Color("#a8835c"), "tex": "blotch", "scale": 0.8},
	"adobe_dark": {"color": Color("#7c5e40"), "tex": "blotch", "scale": 0.8},
	"wood": {"color": Color("#6b4a2e"), "tex": "planks", "scale": 1.0},
	"wood_dark": {"color": Color("#3d2a1b"), "tex": "planks", "scale": 1.0},
	"roof": {"color": Color("#8c4a2f"), "tex": "planks", "scale": 1.5},
	"stone": {"color": Color("#77756e"), "tex": "blotch", "scale": 1.0},
	"plaster": {"color": Color("#d9d2c0"), "tex": "blotch", "scale": 1.0},
	"cloth_black": {"color": Color("#151215"), "tex": "", "scale": 1.0},
	"cloth_white": {"color": Color("#e8e2d4"), "tex": "", "scale": 1.0},
	"water": {"color": Color("#16303a"), "tex": "speckle", "scale": 0.3, "bias": 0.0004},
	"cactus": {"color": Color("#3f5a32"), "tex": "speckle", "scale": 2.0},
	"leaves": {"color": Color("#2a3a22"), "tex": "speckle", "scale": 2.0},
	"metal": {"color": Color("#3a3a3e"), "tex": "", "scale": 1.0},
	"marigold": {"color": Color("#e8901a"), "tex": "", "scale": 1.0},
	"candle": {"color": Color("#efe6cc"), "tex": "", "scale": 1.0},
	"sidewalk": {"color": Color("#6e675c"), "tex": "blotch", "scale": 1.2, "bias": 0.0003},
	"paving": {"color": Color("#5d5850"), "tex": "blotch", "scale": 0.9, "bias": 0.0002},
	"concrete": {"color": Color("#8a857b"), "tex": "blotch", "scale": 1.0},
	"field": {"color": Color("#3d3424"), "tex": "speckle", "scale": 0.7},
	"grass": {"color": Color("#2f3a24"), "tex": "speckle", "scale": 1.5},
}


static func surface(name: String) -> ShaderMaterial:
	if _cache.has(name):
		return _cache[name]
	var d: Dictionary = SURFACES.get(name, {"color": Color.MAGENTA, "tex": "", "scale": 1.0})
	var m := _new_mat(d["color"])
	if d["tex"] != "":
		m.set_shader_parameter("albedo_tex", _texture(d["tex"]))
		m.set_shader_parameter("use_tex", true)
		m.set_shader_parameter("world_uv", true)
		m.set_shader_parameter("uv_scale", Vector2.ONE * d["scale"])
	if d.has("bias"):
		m.set_shader_parameter("depth_bias", d["bias"])
	_cache[name] = m
	return m


## A wall/plaster material in any colour, keeping the base surface's texture (painted adobe facades).
static func tinted(base: String, c: Color) -> ShaderMaterial:
	var key := "t_%s_%s" % [base, c.to_html()]
	if _cache.has(key):
		return _cache[key]
	var d: Dictionary = SURFACES.get(base, SURFACES["plaster"])
	var m := _new_mat(c)
	if d["tex"] != "":
		m.set_shader_parameter("albedo_tex", _texture(d["tex"]))
		m.set_shader_parameter("use_tex", true)
		m.set_shader_parameter("world_uv", true)
		m.set_shader_parameter("uv_scale", Vector2.ONE * d["scale"])
	_cache[key] = m
	return m


## A flat color material. Optional glow for eyes, flames, etc.
static func color(c: Color, glow := 0.0) -> ShaderMaterial:
	var key := "c_%s_%.2f" % [c.to_html(), glow]
	if _cache.has(key):
		return _cache[key]
	var m := _new_mat(c)
	if glow > 0.0:
		m.set_shader_parameter("emission_color", c)
		m.set_shader_parameter("emission_strength", glow)
	_cache[key] = m
	return m


static func _new_mat(c: Color) -> ShaderMaterial:
	var m := ShaderMaterial.new()
	m.shader = PS1
	m.set_shader_parameter("albedo_color", c)
	m.set_shader_parameter("wobble", 1.0 if Settings.vertex_wobble else 0.0)
	_all.append(m)
	return m


static func apply_settings() -> void:
	for m in _all:
		m.set_shader_parameter("wobble", 1.0 if Settings.vertex_wobble else 0.0)


static func _texture(kind: String) -> ImageTexture:
	var key := "tex_" + kind
	if _cache.has(key):
		return _cache[key]
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(kind)
	var size := 32
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	for y in size:
		for x in size:
			var v := 1.0
			match kind:
				"speckle":
					v = rng.randf_range(0.7, 1.15)
				"blotch":
					v = 0.85 + 0.15 * sin(x * 0.7 + rng.randf() * 0.5) * cos(y * 0.5) + rng.randf_range(-0.08, 0.08)
				"planks":
					var plank := int(y / 8)
					v = 0.8 + 0.12 * fmod(plank * 0.37, 1.0) + rng.randf_range(-0.06, 0.06)
					if y % 8 == 0:
						v = 0.55
			img.set_pixel(x, y, Color(v, v, v))
	img.generate_mipmaps()   # far-away texels average out instead of sparkling
	var t := ImageTexture.create_from_image(img)
	_cache[key] = t
	return t
