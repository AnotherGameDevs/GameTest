extends "res://creatures/creature.gd"
## LA LECHUZA — a witch in the shape of a huge owl, perched on the rooftops.
## RULE: When you hear her whistle, DON'T LOOK UP at her.
## If she catches your eyes she marks you and dives. Only a roof over your head saves you.

enum { PERCH, WHISTLE, DIVE, FLY }

var state := PERCH
var perch := Vector3.ZERO
var timer := 8.0
var marked_peer := 0
var fly_target := Vector3.ZERO
var _wings: Array = []
var _flap := 0.0
var _reported := false


func build_visual() -> Node3D:
	var root := Node3D.new()
	var feather := Palette.color(Color("#3b2e22"))
	var body := SphereMesh.new()
	body.radius = 0.45
	body.height = 1.1
	body.radial_segments = 8
	body.rings = 4
	root.add_child(m(body, feather, Vector3(0, 0.6, 0)))
	var face := SphereMesh.new()
	face.radius = 0.33
	face.height = 0.5
	face.radial_segments = 8
	face.rings = 4
	root.add_child(m(face, Palette.color(Color("#d8cbb0"), 0.25), Vector3(0, 1.1, -0.18), Vector3(1, 1, 0.5)))
	var eye := SphereMesh.new()
	eye.radius = 0.08
	eye.height = 0.16
	eye.radial_segments = 6
	eye.rings = 3
	root.add_child(m(eye, Palette.color(Color("#ffcc22"), 4.0), Vector3(-0.13, 1.14, -0.33)))
	root.add_child(m(eye, Palette.color(Color("#ffcc22"), 4.0), Vector3(0.13, 1.14, -0.33)))
	var ear := BoxMesh.new()
	ear.size = Vector3(0.08, 0.25, 0.08)
	root.add_child(m(ear, feather, Vector3(-0.22, 1.4, -0.05), Vector3.ONE, Vector3(0, 0, 20)))
	root.add_child(m(ear, feather, Vector3(0.22, 1.4, -0.05), Vector3.ONE, Vector3(0, 0, -20)))
	var wing := BoxMesh.new()
	wing.size = Vector3(1.0, 0.06, 0.5)
	for side in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(0.35 * side, 0.8, 0)
		pivot.add_child(m(wing, feather, Vector3(0.5 * side, 0, 0)))
		root.add_child(pivot)
		_wings.append(pivot)
	return root


func creature_ready() -> void:
	collision_mask = 0   # she flies through everything
	if map and not map.perches.is_empty():
		perch = map.perches.pick_random()
		global_position = perch


func sync_props() -> Array:
	return super.sync_props() + [":state", ":marked_peer"]


func server_tick(delta: float) -> void:
	var prog: float = game.progress()
	match state:
		PERCH:
			global_position = global_position.move_toward(perch, 10.0 * delta)
			var players := alive_players()
			if not players.is_empty():
				var nearest: Node = players[0]
				for p in players:
					if p.global_position.distance_to(global_position) < nearest.global_position.distance_to(global_position):
						nearest = p
				face(nearest.global_position)
			timer -= delta
			if timer <= 0.0:
				# Hop to a rooftop near someone, then whistle
				if randf() < 0.5 and not players.is_empty():
					var p: Node = players.pick_random()
					var best: Vector3 = map.perches[0]
					for pr in map.perches:
						if pr.distance_to(p.global_position) < best.distance_to(p.global_position):
							best = pr
					perch = best
				state = WHISTLE
				timer = 4.0
				game.server_sound("whistle", global_position, 8.0, 60.0)
		WHISTLE:
			timer -= delta
			if fmod(timer, 2.0) < delta and timer > 0.5:
				game.server_sound("whistle", global_position, 8.0, 60.0)
			if timer <= 0.0:
				state = PERCH
				timer = (randf_range(14.0, 22.0) - prog * 6.0) / game.diff
		DIVE:
			var p: Node = game.get_player(marked_peer)
			if p == null or not (p in alive_players()):
				_fly_home()
				return
			var tgt: Vector3 = p.global_position + Vector3.UP * 1.4
			global_position = global_position.move_toward(tgt, (11.0 + prog * 3.0) * game.diff * delta)
			face(tgt)
			if global_position.distance_to(tgt) < 1.4:
				if _sheltered(p):
					game.server_sound("screech", global_position, 6.0, 50.0)
					game.server_toast_to(marked_peer, "She couldn't reach you under the roof.")
				else:
					game.server_down_player(marked_peer, "La Lechuza carried you off.")
				_fly_home()
		FLY:
			global_position = global_position.move_toward(fly_target, 12.0 * delta)
			face(fly_target)
			if global_position.distance_to(fly_target) < 0.5:
				state = PERCH
				timer = randf_range(10.0, 16.0)
	anim = 1 if state == DIVE or state == FLY else 0


func _sheltered(p: Node) -> bool:
	if map.is_indoors(p.global_position):
		return true
	var from: Vector3 = p.global_position + Vector3.UP * 1.0
	var q := PhysicsRayQueryParameters3D.create(from, from + Vector3.UP * 12.0, 1)
	return not get_world_3d().direct_space_state.intersect_ray(q).is_empty()


func _fly_home() -> void:
	marked_peer = 0
	perch = map.perches.pick_random()
	fly_target = perch
	state = FLY
	game.server_sound("screech", global_position, 0.0, 50.0)


## Host: a client says they looked up at her while she was whistling.
func mark(peer: int) -> void:
	if state != WHISTLE and state != PERCH:
		return
	marked_peer = peer
	state = DIVE
	game.server_sound("screech", global_position, 8.0, 70.0)
	game.server_toast_to(peer, "LA LECHUZA SAW YOU. Get under a roof!")


func client_tick(delta: float) -> void:
	_flap += delta * (14.0 if anim == 1 else 2.0)
	var a := sin(_flap) * (0.9 if anim == 1 else 0.08)
	if _wings.size() == 2:
		_wings[0].rotation.z = a - (0.0 if anim == 1 else 1.2)
		_wings[1].rotation.z = -a + (0.0 if anim == 1 else 1.2)
	# RULE: looking up at her while she whistles marks you
	var me: Node = local_player()
	if me == null or me.state != PlayerScript.State.ALIVE:
		return
	if state == WHISTLE:
		var cam := local_camera()
		if cam and global_position.y > cam.global_position.y + 0.8 and local_looking_at(global_position + Vector3.UP * 0.9, 0.93, 40.0):
			if not _reported:
				_reported = true
				game.report_looked_up(name)
	else:
		_reported = false
