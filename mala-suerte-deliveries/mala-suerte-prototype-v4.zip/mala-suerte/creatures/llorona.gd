extends "res://creatures/creature.gd"
## LA LLORONA — wanders between the water and the houses, weeping.
## Built to be LEARNABLE: every state has one clear tell and one clear way out.
##   WANDER   You hear her weeping, from where she is (it's positional: turn your head and you can tell).
##   NOTICE   She saw or heard you. The weeping suddenly sounds FAR AWAY and muffled ("when she sounds far,
##            she's near"), a whisper, and she stops and turns to you. HUD: "SHE HAS NOTICED YOU".
##   STALK    She glides to where she last saw/heard you, about walking pace, wet footsteps.
##            Way out: get out of her sight AND be quiet (crouch or stand still) for 3 s. A bar fills while you hide.
##   CHASE    She screams and charges. Way out: sprint round a corner, then crouch out of sight for 3 s.
## What makes her charge: getting within ~4.5 m, staring at her (~0.8 s), sprinting near her, staying exposed too long.
## When you shake her, the weeping comes back and the HUD says "She lost you".

enum { WANDER, STALK, CHASE, RETREAT, NOTICE }

const NOTICE_TIME := 1.4      # she stops and turns to you before stalking: your moment to react
const LOSE_TIME := 3.0        # out of sight + quiet this long = she loses you
const QUIET_NOISE := 2.5      # crouch-walking (2.0) and standing still (0.5) are quiet; walking (6) is not
const CHARGE_DIST := 4.5
const STARE_LIMIT := 0.8

var state := WANDER
var target_peer := 0
var wander_target := Vector3.ZERO
var chase_time := 0.0
var lost_time := 0.0           # kept for older tests/tools: mirrors hide_t
var retreat_time := 0.0
var enraged := 0.0             # set by mistakes (wrong offering etc.): she knows exactly where you are
var stare_time := {}           # peer -> seconds stared (host)
var stalk_time := 0.0          # seconds she has had you in sight/earshot while stalking
var calm := 0.0                # after losing someone she ignores players briefly
var notice_t := 0.0
var hide_t := 0.0
var hide_progress := 0.0       # synced, 0..1, drives the target's "hiding" bar
var last_known := Vector3.ZERO
var _tracked := -1
var _stuck_t := 0.0
var _last_pos := Vector3.ZERO

var _cry: AudioStreamPlayer3D
var _far: AudioStreamPlayer
var _bob := 0.0
var _prev_state := -1
var _drip_cd := 0.0
var _glow: OmniLight3D


static func make_visual() -> Node3D:
	var root := Node3D.new()
	var dress_mat := Palette.color(Color("#c9c4b6"), 0.22)
	var dress := CylinderMesh.new()
	dress.top_radius = 0.16
	dress.bottom_radius = 0.6
	dress.height = 1.8
	dress.radial_segments = 8
	root.add_child(m(dress, dress_mat, Vector3(0, 0.9, 0)))
	var veil := CylinderMesh.new()
	veil.top_radius = 0.02
	veil.bottom_radius = 0.28
	veil.height = 0.55
	veil.radial_segments = 8
	root.add_child(m(veil, dress_mat, Vector3(0, 2.05, 0.02)))
	var head := SphereMesh.new()
	head.radius = 0.15
	head.height = 0.32
	head.radial_segments = 8
	head.rings = 4
	root.add_child(m(head, Palette.color(Color("#bdb8ae"), 0.15), Vector3(0, 1.92, 0)))
	var hair := BoxMesh.new()
	hair.size = Vector3(0.36, 1.1, 0.12)
	root.add_child(m(hair, Palette.color(Color("#050505")), Vector3(0, 1.6, -0.15)))   # over the face
	root.add_child(m(hair, Palette.color(Color("#050505")), Vector3(0, 1.55, 0.13)))
	var arm := BoxMesh.new()
	arm.size = Vector3(0.06, 0.95, 0.06)
	root.add_child(m(arm, dress_mat, Vector3(-0.3, 1.35, -0.25), Vector3.ONE, Vector3(-55, 0, 8)))   # reaching
	root.add_child(m(arm, dress_mat, Vector3(0.3, 1.35, -0.25), Vector3.ONE, Vector3(-55, 0, -8)))
	var glow := OmniLight3D.new()
	glow.light_color = Color("#9fb6c9")
	glow.light_energy = 0.8
	glow.omni_range = 3.0
	glow.position = Vector3(0, 1.6, -0.6)
	root.add_child(glow)
	return root


func build_visual() -> Node3D:
	var v := make_visual()
	for c in v.get_children():
		if c is OmniLight3D:
			_glow = c
	return v


func creature_ready() -> void:
	_ensure_far_bus()
	# Positional weeping: you can hear WHERE she is.
	_cry = AudioStreamPlayer3D.new()
	_cry.stream = Sfx.streams["cry"]
	_cry.bus = "SFX"
	_cry.unit_size = 7.0
	_cry.max_distance = 75.0
	_cry.volume_db = -80.0
	_cry.position = Vector3(0, 1.6, 0)
	add_child(_cry)
	_cry.play()
	# The same weeping, muffled and distant: what you hear once she has noticed you.
	_far = AudioStreamPlayer.new()
	_far.stream = Sfx.streams["cry"]
	_far.bus = "Far"
	_far.volume_db = -80.0
	add_child(_far)
	_far.play()
	if map:
		wander_target = map.water_points.pick_random()


static func _ensure_far_bus() -> void:
	if AudioServer.get_bus_index("Far") != -1:
		return
	AudioServer.add_bus()
	var i := AudioServer.bus_count - 1
	AudioServer.set_bus_name(i, "Far")
	AudioServer.set_bus_send(i, "SFX" if AudioServer.get_bus_index("SFX") != -1 else "Master")
	var lp := AudioEffectLowPassFilter.new()
	lp.cutoff_hz = 650.0
	AudioServer.add_bus_effect(i, lp)
	var rv := AudioEffectReverb.new()
	rv.room_size = 0.95
	rv.wet = 0.55
	rv.dry = 0.35
	AudioServer.add_bus_effect(i, rv)


func sync_props() -> Array:
	return super.sync_props() + [":state", ":target_peer", ":hide_progress"]


func hunting() -> bool:
	return state == NOTICE or state == STALK or state == CHASE


# --- Host AI ------------------------------------------------------------------------

func server_tick(delta: float) -> void:
	if not active and state != RETREAT:
		return
	var prog: float = game.progress()
	var players := alive_players()
	enraged = maxf(0.0, enraged - delta)
	calm = maxf(0.0, calm - delta)
	_check_stuck(delta)
	if hunting():
		var p: Node = game.get_player(target_peer)
		if p == null or not (p in players):
			_lose(false)
		else:
			_hunt(p, prog, delta)
	elif state == WANDER:
		hide_progress = 0.0
		move_to(wander_target, 1.4 * game.diff, delta)
		if global_position.distance_to(wander_target) < 2.0 or agent.is_navigation_finished():
			wander_target = _next_wander(players, prog)
		var t := _pick_target(players, 22.0) if calm <= 0.0 else null
		if t:
			target_peer = t.peer_id
			state = NOTICE
			notice_t = NOTICE_TIME / game.diff
	elif state == RETREAT:
		retreat_time -= delta
		if retreat_time <= 0.0:
			active = true
			state = WANDER
	for k in stare_time.keys():
		stare_time[k] = maxf(0.0, stare_time[k] - delta * 0.3)
	game.mode_creature_near(self)


func _perceives(p: Node) -> bool:
	var d := global_position.distance_to(p.global_position)
	var heard: bool = p.noise > QUIET_NOISE and d < p.noise + 2.0
	return heard or can_see(p, 30.0)


func _hunt(p: Node, prog: float, delta: float) -> void:
	if _tracked != target_peer:          # a new target (also when a mode or the dev menu points her at someone)
		_tracked = target_peer
		last_known = p.global_position
		hide_t = 0.0
		stalk_time = 0.0
		if state == NOTICE and notice_t <= 0.0:
			notice_t = NOTICE_TIME
	var d := global_position.distance_to(p.global_position)
	var perceived := _perceives(p) or enraged > 0.0
	if perceived:
		last_known = p.global_position
		hide_t = maxf(0.0, hide_t - delta * 2.0)
	else:
		hide_t += delta
	lost_time = hide_t
	hide_progress = clampf(hide_t / LOSE_TIME, 0.0, 1.0)
	if hide_t >= LOSE_TIME:
		_lose(true)
		return
	var stared: float = stare_time.get(target_peer, 0.0)
	var sprinting_near: bool = p.noise >= 10.0 and d < p.noise + 4.0
	match state:
		NOTICE:
			velocity = Vector3.ZERO
			face(p.global_position)
			notice_t -= delta
			if (perceived and d < CHARGE_DIST) or stared > STARE_LIMIT or enraged > 0.0:
				_charge(p)
			elif notice_t <= 0.0:
				state = STALK
				stalk_time = 0.0
		STALK:
			move_to(last_known, (3.1 + prog * 0.5) * game.diff, delta)
			if perceived:
				stalk_time += delta
			if (perceived and d < CHARGE_DIST) or stared > STARE_LIMIT or sprinting_near or enraged > 0.0 or stalk_time > 16.0 / game.diff:
				_charge(p)
		CHASE:
			chase_time += delta
			var goal: Vector3 = p.global_position if enraged > 0.0 else last_known
			# Full charge only while she can see/hear you; once you've broken away she slows to a searching glide.
			var spd: float = (4.4 + prog * 1.0) * game.diff + (0.8 if enraged > 0.0 else 0.0)
			if not perceived:
				spd = (3.0 + prog * 0.4) * game.diff
			move_to(goal, spd, delta)
			if d < 1.3:
				game.server_down_player(target_peer, "La Llorona took you.")
				_retreat()
				return
			if chase_time > 16.0:
				_lose(true)


func _charge(p: Node) -> void:
	state = CHASE
	chase_time = 0.0
	last_known = p.global_position


## She lost her target: back to the water, weeping again, and she leaves people alone for a moment.
func _lose(shaken: bool) -> void:
	state = WANDER
	stare_time[target_peer] = 0.0
	calm = 8.0 if shaken else 2.0
	hide_t = 0.0
	hide_progress = 0.0
	lost_time = 0.0
	_tracked = -1
	wander_target = map.water_points.pick_random()


## She drifts toward the living: early in the night she mostly roams the water,
## later she more and more often heads for somewhere near a random player.
func _next_wander(players: Array, prog: float) -> Vector3:
	if not players.is_empty() and randf() < 0.45 + prog * 0.35:
		var p: Node = players.pick_random()
		var a := randf() * TAU
		var r := randf_range(10.0, 22.0)
		return _reachable(p.global_position + Vector3(cos(a) * r, 0, sin(a) * r))
	return (map.water_points + map.wander_points).pick_random()


## Keeps a wander goal inside the map and on walkable ground (a point near a player standing in a
## corner can land outside the map, and she would stand still trying to path there).
func _reachable(p: Vector3) -> Vector3:
	var b: AABB = map.BOUNDS.grow(-3.0)
	p.x = clampf(p.x, b.position.x, b.end.x)
	p.z = clampf(p.z, b.position.z, b.end.z)
	var nav_map := agent.get_navigation_map()
	if nav_map.is_valid() and NavigationServer3D.map_get_iteration_id(nav_map) > 0:
		p = NavigationServer3D.map_get_closest_point(nav_map, p)
	return p


## If she hasn't moved for a while (snagged on a corner), unstick her.
func _check_stuck(delta: float) -> void:
	if state == RETREAT or state == NOTICE:
		_last_pos = global_position
		_stuck_t = 0.0
		return
	if global_position.distance_to(_last_pos) < 0.02:
		_stuck_t += delta
	else:
		_stuck_t = 0.0
	_last_pos = global_position
	if _stuck_t > 2.5:
		_stuck_t = 0.0
		if state == WANDER:
			wander_target = _next_wander(alive_players(), game.progress())
		else:
			var nxt := agent.get_next_path_position()
			global_position = global_position.move_toward(Vector3(nxt.x, global_position.y, nxt.z), 1.0)


func _pick_target(players: Array, sight: float) -> Node:
	var best: Node = null
	var best_d := 999.0
	for p in players:
		var d := global_position.distance_to(p.global_position)
		var heard: bool = p.noise > QUIET_NOISE and d < p.noise + 2.0
		if (heard or can_see(p, sight)) and d < best_d:
			best = p
			best_d = d
	return best


func _retreat() -> void:
	state = RETREAT
	retreat_time = 6.0
	active = false
	hide_progress = 0.0
	_tracked = -1
	global_position = map.water_points.pick_random()
	stare_time.clear()


func add_stare(peer: int, seconds: float) -> void:
	stare_time[peer] = stare_time.get(peer, 0.0) + seconds


func enrage(seconds: float, at_peer: int) -> void:
	enraged = seconds
	if at_peer > 0 and game.get_player(at_peer):
		target_peer = at_peer
		state = CHASE
		chase_time = 0.0
		if not active:
			active = true
			var p: Node = game.get_player(at_peer)
			global_position = p.global_position + Vector3(12, 0, 0)


# --- Every peer: the tells --------------------------------------------------------

func client_tick(delta: float) -> void:
	_bob += delta
	visual.position.y = 0.08 + sin(_bob * 1.6) * 0.06
	var cam := local_camera()
	var hunt := active and hunting()
	# Weeping: positional while she wanders; muffled and "far away" once she's noticed someone.
	var d := cam.global_position.distance_to(global_position) if cam else 999.0
	_cry.volume_db = lerpf(_cry.volume_db, 0.0 if (active and state == WANDER) else -80.0, 6.0 * delta)
	var far_target := -80.0
	if hunt and d < 45.0:
		far_target = -14.0
	_far.volume_db = lerpf(_far.volume_db, far_target, 8.0 * delta)
	if _glow:
		_glow.light_energy = lerpf(_glow.light_energy, 2.2 if state == CHASE else 0.8, 4.0 * delta)
	# One-shot cues on state changes
	if state != _prev_state:
		if active and cam and d < 50.0:
			if state == NOTICE:
				Sfx.play_at("whisper", global_position + Vector3.UP * 1.6, self, 4.0, 0.8, 30.0)
			elif state == CHASE:
				Sfx.play_at("screech", global_position + Vector3.UP * 1.6, self, 2.0, 0.55, 60.0)
		_prev_state = state
	# Wet footsteps while she comes for someone
	if hunt and state != NOTICE and d < 30.0:
		_drip_cd -= delta
		if _drip_cd <= 0.0:
			_drip_cd = 0.33 if state == CHASE else 0.6
			Sfx.play_at("step", global_position, self, -4.0, randf_range(0.55, 0.7), 30.0)
	if cam == null or not active:
		return
	# Staring at her is reported to the host (it makes her charge)
	var me: Node = local_player()
	var looking: bool = me != null and me.state == PlayerScript.State.ALIVE and local_looking_at(global_position + Vector3.UP * 1.5, 0.965, 16.0)
	if looking:
		game.report_stare(name, delta)
