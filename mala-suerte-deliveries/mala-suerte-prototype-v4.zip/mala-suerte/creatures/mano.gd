extends "res://creatures/creature.gd"
## LA MANO PELUDA — a huge hairy hand that lives under the wooden floors.
## RULE: Indoors, keep moving. Stand still on the floorboards and it grabs you.
## Mash [E] to break free, or a friend can pull you out.

const STILL_LIMIT := 3.5
const GRAB_TIME := 6.0
const STRUGGLE_NEEDED := 9

var still := {}            # peer -> seconds standing still indoors
var last_pos := {}
var grabbed_peer := 0
var grab_timer := 0.0
var struggles := 0
var cooldown := 10.0
var rise := 0.0            # synced-ish via position; visual only
var _warned := {}
var _sample_t := 0.0          # movement is sampled every 0.5s so network jitter doesn't count as standing still


func build_visual() -> Node3D:
	var root := Node3D.new()
	var fur := Palette.color(Color("#2a1d14"))
	var skin := Palette.color(Color("#5a4030"))
	var palm := BoxMesh.new()
	palm.size = Vector3(0.55, 0.65, 0.22)
	root.add_child(m(palm, fur, Vector3(0, 0.35, 0)))
	var finger := BoxMesh.new()
	finger.size = Vector3(0.1, 0.5, 0.1)
	for i in 4:
		var x := -0.21 + i * 0.14
		root.add_child(m(finger, skin, Vector3(x, 0.88, -0.05), Vector3(1, 1.0 - absf(i - 1.5) * 0.12, 1), Vector3(-30, 0, 0)))
		var claw := BoxMesh.new()
		claw.size = Vector3(0.06, 0.12, 0.06)
		root.add_child(m(claw, Palette.color(Color("#d8cfb5")), Vector3(x, 1.15, -0.22), Vector3.ONE, Vector3(-60, 0, 0)))
	root.add_child(m(finger, skin, Vector3(0.36, 0.45, -0.05), Vector3.ONE, Vector3(0, 0, -50)))
	# Fur tufts
	var tuft := BoxMesh.new()
	tuft.size = Vector3(0.04, 0.2, 0.04)
	for i in 14:
		root.add_child(m(tuft, fur, Vector3(randf_range(-0.28, 0.28), randf_range(0.05, 0.6), randf_range(-0.14, 0.14)), Vector3.ONE, Vector3(randf_range(-40, 40), 0, randf_range(-40, 40))))
	return root


var warn_peer := 0   # synced: the player it is about to grab (they hear scratching; HUD says keep moving)


func sync_props() -> Array:
	return super.sync_props() + [":warn_peer"]


func creature_ready() -> void:
	collision_layer = 0
	collision_mask = 0
	active = false
	global_position = Vector3(0, -3, 0)


func server_tick(delta: float) -> void:
	cooldown = maxf(0.0, cooldown - delta)
	if grabbed_peer != 0:
		_hold(delta)
		return
	var prog: float = game.progress()
	var limit: float = (STILL_LIMIT - prog * 1.0) / game.diff
	_sample_t += delta
	var sample := _sample_t >= 0.5
	if sample:
		_sample_t = 0.0
	for p in alive_players():
		if p.state != PlayerScript.State.ALIVE:
			continue
		var id: int = p.peer_id
		var pos: Vector3 = p.global_position
		if not map.is_indoors(pos):
			still[id] = 0.0
			_warned[id] = false
			if warn_peer == id:
				warn_peer = 0
			last_pos[id] = pos
			continue
		if not sample:
			continue
		var lp: Vector3 = last_pos.get(id, pos)
		last_pos[id] = pos
		var moved := Vector2(pos.x - lp.x, pos.z - lp.z).length()   # metres in the last 0.5s
		if moved < 0.25:
			still[id] = still.get(id, 0.0) + 0.5
		else:
			still[id] = 0.0
			_warned[id] = false
			if warn_peer == id:
				warn_peer = 0
		if still[id] > limit - 1.5 and not _warned.get(id, false):
			_warned[id] = true
			warn_peer = id
			game.server_sound_to(id, "grab", -14.0)   # scratching under the floor
		if still[id] > limit and cooldown <= 0.0:
			_grab(p)
			return


func _grab(p: Node) -> void:
	warn_peer = 0
	grabbed_peer = p.peer_id
	grab_timer = GRAB_TIME
	struggles = 0
	still[grabbed_peer] = 0.0
	active = true
	visible = true
	global_position = p.global_position + Vector3(0, -1.2, 0)
	rotation.y = p.rotation.y
	game.server_set_state(grabbed_peer, PlayerScript.State.GRABBED)
	game.server_sound("grab", p.global_position, 6.0, 30.0)


func _hold(delta: float) -> void:
	var p: Node = game.get_player(grabbed_peer)
	if p == null or p.state != PlayerScript.State.GRABBED:
		_release()
		return
	var fwd: Vector3 = -p.global_transform.basis.z
	global_position = global_position.move_toward(p.global_position + fwd * 0.55 + Vector3(0, -0.35, 0), 2.0 * delta)
	face(p.global_position)
	grab_timer -= delta
	if grab_timer <= 0.0:
		game.server_down_player(grabbed_peer, "La Mano Peluda dragged you under.")
		_release()


## Host: the grabbed player pressed E.
func struggle(peer: int) -> void:
	if peer != grabbed_peer:
		return
	struggles += 1
	if struggles >= STRUGGLE_NEEDED:
		free_player()


## Host: break free (struggle or a teammate pulled them).
func free_player() -> void:
	if grabbed_peer == 0:
		return
	game.server_set_state(grabbed_peer, PlayerScript.State.ALIVE)
	game.server_toast_to(grabbed_peer, "You tore free. Keep moving.")
	_release()


func _release() -> void:
	grabbed_peer = 0
	cooldown = 12.0
	active = false
	visible = false
	global_position = Vector3(0, -3, 0)


func is_active() -> bool:
	return active and grabbed_peer != 0 if multiplayer.is_server() else active
