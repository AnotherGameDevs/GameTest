extends Node3D
## One night of play. Built identically on every peer from the host's config.
## The host is the referee: creatures, items, player states and win/lose all
## run here on the host and get broadcast with RPCs.

const MapScript := preload("res://world/map.gd")
const Palette := preload("res://world/palette.gd")
const PlayerScript := preload("res://player/player.gd")
const ItemScript := preload("res://world/item.gd")
const HudScript := preload("res://ui/hud.gd")
const PostFx := preload("res://shaders/post.gdshader")
const CardsDB := preload("res://player/cards.gd")

const MODE_SCRIPTS := {
	"velorio": preload("res://modes/velorio.gd"),
	"procesion": preload("res://modes/procesion.gd"),
	"ofrenda": preload("res://modes/ofrenda.gd"),
	"limpia": preload("res://modes/limpia.gd"),
}
const CREATURE_SCRIPTS := {
	"llorona": preload("res://creatures/llorona.gd"),
	"lechuza": preload("res://creatures/lechuza.gd"),
	"mano": preload("res://creatures/mano.gd"),
}

var config := {}
var running := false
var ended := false
var elapsed := 0.0
var night_seconds := 480.0

var map: Node3D
var mode: Node
var hud: CanvasLayer
var post: ColorRect
var players_root: Node3D
var creatures_root: Node3D
var world_root: Node3D
var items := {}             # name -> item node
var held_by := {}           # peer -> item name   (host)
var downed_at := {}         # peer -> elapsed     (host)
var lives := {}             # peer -> self-revives left (synced)
var diff := 1.0             # creature speed/aggression multiplier
var stats := {"distance": 0.0, "downed": 0, "grabbed": 0, "notes": 0, "pickups": 0, "close_calls": 0, "self_revives": 0}
var frozen := false         # dev: creatures paused
var mode_paused := false    # dev: objective timers/fail checks paused
var _close_cd := 0.0

var _time_sync_cd := 0.0
var _check_cd := 0.0
var _stare_buf := {}
var _stare_cd := 0.0
var _ambience: AudioStreamPlayer


func start(cfg: Dictionary) -> void:
	config = cfg
	night_seconds = float(cfg.get("night_seconds", 480.0))
	diff = float(Net.DIFFICULTY.get(cfg.get("difficulty", "normal"), 1.0))
	name = "Game"
	add_to_group("game")


func _ready() -> void:
	_build_environment()

	world_root = Node3D.new()
	world_root.name = "World"
	add_child(world_root)

	map = Node3D.new()
	map.set_script(MapScript)
	map.name = "Map"
	world_root.add_child(map)
	map.build()
	if multiplayer.is_server():
		map.bake_navigation()

	players_root = Node3D.new()
	players_root.name = "Players"
	add_child(players_root)
	creatures_root = Node3D.new()
	creatures_root.name = "Creatures"
	add_child(creatures_root)

	# Mode builds its objects (same seed on every peer)
	mode = Node.new()
	mode.set_script(MODE_SCRIPTS.get(config.get("mode", "velorio"), MODE_SCRIPTS["velorio"]))
	mode.name = "Mode"
	add_child(mode)
	mode.setup(self, map, int(config.get("seed", 1)))

	# Players
	var ids: Array = config["players"].keys()
	ids.sort()
	var my_cards: Array = config.get("cards", {}).get(multiplayer.get_unique_id(), [])
	for i in ids.size():
		var id: int = ids[i]
		var p := CharacterBody3D.new()
		p.set_script(PlayerScript)
		p.setup(id, config["players"][id], my_cards if id == multiplayer.get_unique_id() else [], self)
		players_root.add_child(p)
		p.global_position = map.spawn_points[i % map.spawn_points.size()]
		lives[id] = int(config.get("lives", 1))

	# Creatures
	var crng := RandomNumberGenerator.new()
	crng.seed = int(config.get("seed", 1)) + 99
	var allowed: Array = config.get("creatures", ["llorona", "lechuza", "mano"])
	for cname in mode.creature_list():
		if config.get("mode", "") != "limpia" and not (cname in allowed):
			continue
		var c := CharacterBody3D.new()
		c.set_script(CREATURE_SCRIPTS[cname])
		c.setup(self, map, cname.capitalize())
		creatures_root.add_child(c)
		if cname == "llorona":
			# start her at water well away from where the players appear (never in the next patio)
			var far := []
			for wp in map.water_points:
				if wp.distance_to(map.spawn_points[0]) > 35.0:
					far.append(wp)
			if far.is_empty():
				far = map.water_points
			c.global_position = far[crng.randi_range(0, far.size() - 1)]
			c.wander_target = c.global_position

	hud = CanvasLayer.new()
	hud.set_script(HudScript)
	add_child(hud)
	hud.setup(self)

	_ambience = Sfx.play("wind", -6.0, 1.0, "Ambience")
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	running = true
	multiplayer.peer_disconnected.connect(_on_peer_left)
	Settings.changed.connect(_apply_settings)
	_apply_settings()
	var me := get_player(multiplayer.get_unique_id())
	if me:
		me.rotation.y = 0.0   # spawned in front of the casa; face it
		hud.reveal_cards(me.cards)


func _on_peer_left(id: int) -> void:
	var p := get_player(id)
	if p == null:
		return
	if multiplayer.is_server():
		_server_drop(id)
	toast_local("%s left the game." % p.display_name)
	p.queue_free()


func _exit_tree() -> void:
	Engine.time_scale = 1.0
	if _ambience:
		_ambience.queue_free()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("#06070c")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#36405e")
	env.ambient_light_energy = 0.8
	env.fog_enabled = true
	env.fog_light_color = Color("#0b0e17")
	env.fog_density = 0.03
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var moon := DirectionalLight3D.new()
	moon.light_color = Color("#8da2cf")
	moon.light_energy = 0.4
	moon.rotation_degrees = Vector3(-38, 35, 0)
	add_child(moon)

	var layer := CanvasLayer.new()
	layer.layer = 5
	add_child(layer)
	post = ColorRect.new()
	post.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	post.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sm := ShaderMaterial.new()
	sm.shader = PostFx
	post.material = sm
	layer.add_child(post)


func _apply_settings() -> void:
	Palette.apply_settings()
	var sm := post.material as ShaderMaterial
	sm.set_shader_parameter("pixel_size", float(Settings.pixel_size) if Settings.pixelation else 1.0)
	sm.set_shader_parameter("dither", Settings.dithering)
	sm.set_shader_parameter("brightness", Settings.brightness)
	var res := get_viewport().get_visible_rect().size
	var ps := float(Settings.pixel_size) if Settings.pixelation else 1.0
	for mat in Palette._all:
		mat.set_shader_parameter("snap_res", res / ps)   # snap to whole game pixels (PS1-style); 2-pixel steps made the floor swim


# --- Queries ------------------------------------------------------------------------

func get_player(id: int) -> Node:
	return players_root.get_node_or_null(str(id)) if players_root else null


func get_players() -> Array:
	return players_root.get_children() if players_root else []


func local_player() -> Node:
	return get_player(multiplayer.get_unique_id())


func progress() -> float:
	return clampf(elapsed / night_seconds, 0.0, 1.0)


func clock_text() -> String:
	var minutes := int(progress() * 360.0)
	var h := minutes / 60
	return "%d:%02d AM" % [12 if h == 0 else h, minutes % 60]


func carry_speed_mult(peer: int) -> float:
	var iname: String = held_by.get(peer, "")
	if iname == "":
		# clients don't track held_by; look at the item itself
		for it in items.values():
			if it.holder == peer:
				iname = it.name
				break
	if iname == "" or not items.has(iname) or items[iname].kind != "coffin":
		return 1.0
	var coffin: Node3D = items[iname]
	var helpers := 0
	for p in get_players():
		if p.peer_id != peer and p.state == PlayerScript.State.ALIVE and p.global_position.distance_to(coffin.global_position) < 3.2:
			helpers += 1
	return clampf(0.5 + 0.22 * helpers, 0.5, 0.95)


func mode_creature_near(c: Node) -> void:
	mode.on_creature_near(c)


# --- Main loop ---------------------------------------------------------------------

func _process(delta: float) -> void:
	if not running:
		return
	elapsed += delta
	_update_post(delta)
	_track_stats(delta)
	_flush_stares(delta)
	if not multiplayer.is_server():
		return
	if not mode_paused:
		mode.server_tick(delta)
	_time_sync_cd -= delta
	if _time_sync_cd <= 0.0 and not Net.is_solo:
		_time_sync_cd = 2.0
		_rpc_time.rpc(elapsed)
	_check_cd -= delta
	if _check_cd <= 0.0:
		_check_cd = 0.25
		_server_checks()


func _track_stats(delta: float) -> void:
	var me := local_player()
	if me == null or me.state == PlayerScript.State.DEAD:
		return
	stats["distance"] += Vector2(me.velocity.x, me.velocity.z).length() * delta
	_close_cd -= delta
	if _close_cd <= 0.0:
		for c in creatures_root.get_children():
			if c.active and c.global_position.distance_to(me.global_position) < 4.0:
				stats["close_calls"] += 1
				_close_cd = 8.0
				break


func _update_post(_delta: float) -> void:
	var me := local_player()
	if me == null:
		return
	var sm := post.material as ShaderMaterial
	var dmg := 0.0
	if me.state == PlayerScript.State.DOWNED:
		dmg = 0.6 + sin(elapsed * 3.0) * 0.1
	elif me.state == PlayerScript.State.GRABBED:
		dmg = 0.35
	sm.set_shader_parameter("damage", dmg)
	sm.set_shader_parameter("sway", 1.0 if me.has_card("borracho") else 0.0)
	sm.set_shader_parameter("fear", me.fear)


func _server_checks() -> void:
	if ended:
		return
	# Bleed out
	for p in get_players():
		if p.state == PlayerScript.State.DOWNED and downed_at.has(p.peer_id):
			if elapsed - downed_at[p.peer_id] > PlayerScript.DOWNED_TIME:
				server_set_state(p.peer_id, PlayerScript.State.DEAD)
				_rpc_toast.rpc("%s bled out." % p.display_name)
	# Anyone left standing?
	var standing := 0
	for p in get_players():
		if p.state == PlayerScript.State.ALIVE or p.state == PlayerScript.State.GRABBED:
			standing += 1
		elif p.state == PlayerScript.State.DOWNED and int(lives.get(p.peer_id, 0)) > 0:
			standing += 1   # can still pick themselves up
	if standing == 0:
		server_end(false, "Nobody was left standing.")
		return
	if elapsed >= night_seconds:
		mode.on_dawn()


# --- Host-side actions ------------------------------------------------------------------

func server_set_state(peer: int, s: int) -> void:
	_rpc_set_state.rpc(peer, s)


func server_down_player(peer: int, reason: String) -> void:
	var p := get_player(peer)
	if p == null or ended:
		return
	if p.state == PlayerScript.State.DOWNED or p.state == PlayerScript.State.DEAD:
		return
	if peer == multiplayer.get_unique_id() and Settings.invincible:
		server_toast_to(peer, "(Invincible) " + reason)
		return
	_server_drop(peer)
	var cards: Array = config.get("cards", {}).get(peer, [])
	var instant: bool = "muerte" in cards or (Net.is_solo and int(lives.get(peer, 0)) <= 0)
	_rpc_sound.rpc("sting", p.global_position, 6.0, 60.0)
	if instant:
		server_set_state(peer, PlayerScript.State.DEAD)
		_rpc_toast.rpc("%s is dead. %s" % [p.display_name, reason])
	else:
		downed_at[peer] = elapsed
		server_set_state(peer, PlayerScript.State.DOWNED)
		if Net.is_solo:
			_rpc_toast.rpc("You're down. Hold [E] to get back up (%d left). (%s)" % [int(lives.get(peer, 0)), reason])
		else:
			_rpc_toast.rpc("%s is down! Revive them. (%s)" % [p.display_name, reason])


func server_end(won: bool, text: String) -> void:
	if ended:
		return
	_rpc_end.rpc(won, text)


func server_toast_to(peer: int, text: String) -> void:
	if peer == multiplayer.get_unique_id():
		toast_local(text)
	else:
		_rpc_toast.rpc_id(peer, text)


func server_toast_all(text: String) -> void:
	_rpc_toast.rpc(text)


func server_sound(sname: String, pos: Vector3, vol := 0.0, max_dist := 40.0) -> void:
	_rpc_sound.rpc(sname, pos, vol, max_dist)


func server_sound_to(peer: int, sname: String, vol := 0.0) -> void:
	if peer == multiplayer.get_unique_id():
		Sfx.play(sname, vol)
	else:
		_rpc_sound_2d.rpc_id(peer, sname, vol)


func mode_call(fn: String, args := []) -> void:
	_rpc_mode_call.rpc(fn, args)


# --- Items --------------------------------------------------------------------------------

## Called by modes during setup on every peer (deterministic).
func spawn_item(item_name: String, kind: String, pos: Vector3) -> Node3D:
	var it := Node3D.new()
	it.set_script(ItemScript)
	it.setup_item(item_name, kind, self)
	world_root.add_child(it)
	it.global_position = pos
	it.home = pos
	items[item_name] = it
	return it


func server_item(it: Node, holder: int, placed: bool, consumed: bool, pos: Vector3) -> void:
	for k in held_by.keys():
		if held_by[k] == it.name:
			held_by.erase(k)
	if holder != 0:
		held_by[holder] = it.name
	_rpc_item.rpc(it.name, holder, placed, consumed, pos)


func held_item(peer: int) -> Node:
	var n: String = held_by.get(peer, "")
	if n == "":
		for it in items.values():
			if it.holder == peer:
				return it
		return null
	return items.get(n)


func _server_drop(peer: int) -> void:
	var it := held_item(peer)
	if it == null:
		return
	var p := get_player(peer)
	var fwd: Vector3 = -p.global_transform.basis.z
	var pos: Vector3 = p.global_position + fwd * 0.9 + Vector3.UP * 0.6
	var q := PhysicsRayQueryParameters3D.create(pos, pos + Vector3.DOWN * 4.0, 1)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit:
		pos = hit.position + Vector3.UP * (0.05 if it.kind != "coffin" else 0.3)
	server_item(it, 0, false, false, pos)


# Interactable handler for items (the game is their handler)
func prompt_for(node: Node, player: Node) -> String:
	if not node.has_method("display_name"):
		return ""
	if node.consumed or node.placed or node.holder != 0:
		return ""
	var custom: String = mode.item_prompt(node, player)
	if custom != "":
		return custom
	match node.kind:
		"cerillos":
			return "[E] Take matches"
		"pilas":
			return "[E] Take batteries"
	if held_item(player.peer_id) != null:
		return "Hands full — [G] drop"
	return "[E] Pick up %s" % node.display_name()


func hold_for(_node: Node, _player: Node) -> float:
	return 0.0


func on_interact(node: Node, peer: int) -> void:
	if not node.has_method("display_name") or node.consumed or node.placed or node.holder != 0:
		return
	if mode.item_interact(node, peer):
		return
	match node.kind:
		"cerillos":
			mode.add_matches(3)
			server_item(node, 0, false, true, node.global_position)
			server_sound("match", node.global_position, 0.0, 15.0)
			return
		"pilas":
			server_item(node, 0, false, true, node.global_position)
			if peer == multiplayer.get_unique_id():
				_rpc_battery(peer)
			else:
				_rpc_battery.rpc_id(peer, peer)
			return
	if held_item(peer) != null:
		return
	server_item(node, peer, false, false, node.global_position)
	server_sound("pickup", node.global_position, -4.0, 10.0)


# --- Client requests -----------------------------------------------------------------------

func request_interact(node: Node) -> void:
	if node.has_meta("note_title"):
		hud.show_note(node.get_meta("note_title"), node.get_meta("note_body"))
		stats["notes"] += 1
		Sfx.play("pickup", -10.0)
		return
	_req_interact.rpc_id(1, String(get_path_to(node)))


func request_drop() -> void:
	_req_drop.rpc_id(1)


func request_struggle() -> void:
	_req_struggle.rpc_id(1)


func report_stare(creature_name: String, secs: float) -> void:
	_stare_buf[creature_name] = _stare_buf.get(creature_name, 0.0) + secs


func _flush_stares(delta: float) -> void:
	_stare_cd -= delta
	if _stare_cd > 0.0:
		return
	_stare_cd = 0.25
	for k in _stare_buf.keys():
		if _stare_buf[k] > 0.0:
			_req_stare.rpc_id(1, k, _stare_buf[k])
	_stare_buf.clear()


func report_looked_up(creature_name: String) -> void:
	_req_looked_up.rpc_id(1, creature_name)


func rpc_bell(peer: int) -> void:
	_rpc_bell.rpc(peer)


func toast_local(text: String) -> void:
	if hud:
		hud.toast(text)


func spawn_hallucination(p: Node) -> void:
	var cam: Camera3D = p.camera
	if cam == null:
		return
	var fwd := -cam.global_transform.basis.z
	fwd.y = 0
	fwd = fwd.normalized().rotated(Vector3.UP, randf_range(-0.45, 0.45))
	var pos: Vector3 = p.global_position + fwd * randf_range(11.0, 18.0)
	var q := PhysicsRayQueryParameters3D.create(pos + Vector3.UP * 5.0, pos + Vector3.DOWN * 5.0, 1)
	var hit := get_world_3d().direct_space_state.intersect_ray(q)
	if hit:
		pos = hit.position
	var LloronaScript = CREATURE_SCRIPTS["llorona"]
	var ghost: Node3D = LloronaScript.make_visual() if randf() < 0.7 else _fake_owl()
	add_child(ghost)
	ghost.global_position = pos
	ghost.look_at(Vector3(p.global_position.x, pos.y, p.global_position.z), Vector3.UP, true)
	Sfx.play_at("whisper", pos, self, 2.0, 0.7, 30.0)
	var t := get_tree().create_timer(randf_range(1.0, 2.2))
	t.timeout.connect(ghost.queue_free)


func _fake_owl() -> Node3D:
	var root := Node3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.06
	sm.height = 0.12
	for x in [-0.15, 0.15]:
		var e := MeshInstance3D.new()
		e.mesh = sm
		e.material_override = Palette.color(Color("#ffcc22"), 5.0)
		e.position = Vector3(x, 1.6, 0)
		root.add_child(e)
	return root


# --- RPCs: host -> everyone ------------------------------------------------------------------

@rpc("authority", "call_local", "reliable")
func _rpc_set_state(peer: int, s: int) -> void:
	var p := get_player(peer)
	if p:
		p.set_state(s)
		if peer == multiplayer.get_unique_id():
			if s == PlayerScript.State.DOWNED:
				stats["downed"] += 1
			elif s == PlayerScript.State.GRABBED:
				stats["grabbed"] += 1
	if multiplayer.is_server() and s != PlayerScript.State.DOWNED:
		downed_at.erase(peer)


@rpc("authority", "call_local", "reliable")
func _rpc_item(item_name: String, holder: int, placed: bool, consumed: bool, pos: Vector3) -> void:
	var it: Node = items.get(item_name)
	if it:
		if holder == multiplayer.get_unique_id() and it.holder != holder:
			stats["pickups"] += 1
		it.apply_state(holder, placed, consumed, pos)


@rpc("authority", "call_local", "reliable")
func _rpc_toast(text: String) -> void:
	toast_local(text)


@rpc("authority", "call_local", "unreliable")
func _rpc_sound(sname: String, pos: Vector3, vol: float, max_dist: float) -> void:
	Sfx.play_at(sname, pos, self, vol, 1.0, max_dist)


@rpc("authority", "call_local", "reliable")
func _rpc_sound_2d(sname: String, vol: float) -> void:
	Sfx.play(sname, vol)


@rpc("authority", "call_local", "unreliable")
func _rpc_time(t: float) -> void:
	elapsed = t


@rpc("authority", "call_local", "reliable")
func _rpc_mode_call(fn: String, args: Array) -> void:
	if mode and mode.has_method(fn):
		mode.callv(fn, args)


@rpc("authority", "call_local", "reliable")
func _rpc_end(won: bool, text: String) -> void:
	ended = true
	running = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	Sfx.play("win" if won else "sting", 0.0)
	Engine.time_scale = 1.0
	_write_log(won, text)
	hud.show_end(won, text)


@rpc("authority", "call_local", "reliable")
func _rpc_battery(_peer: int) -> void:
	var me := local_player()
	if me:
		me.refill_battery()
		toast_local("Fresh batteries.")


# --- RPCs: anyone -> host / everyone ----------------------------------------------------------

@rpc("any_peer", "call_local", "reliable")
func _req_interact(path: String) -> void:
	if not multiplayer.is_server() or ended:
		return
	var peer := multiplayer.get_remote_sender_id()
	var p := get_player(peer)
	var node := get_node_or_null(path)
	if p == null or node == null or p.state != PlayerScript.State.ALIVE:
		return
	if (node as Node3D).global_position.distance_to(p.global_position) > 5.0:
		return
	if node.get_script() == PlayerScript:
		if node.state == PlayerScript.State.DOWNED:
			server_set_state(node.peer_id, PlayerScript.State.ALIVE)
			_rpc_toast.rpc("%s revived %s." % [p.display_name, node.display_name])
		elif node.state == PlayerScript.State.GRABBED:
			var mano := creatures_root.get_node_or_null("Mano")
			if mano:
				mano.free_player()
		return
	if node.has_method("server_interact"):
		node.server_interact(peer)


@rpc("any_peer", "call_local", "reliable")
func _req_drop() -> void:
	if multiplayer.is_server():
		_server_drop(multiplayer.get_remote_sender_id())


@rpc("any_peer", "call_local", "reliable")
func _req_struggle() -> void:
	if not multiplayer.is_server():
		return
	var mano := creatures_root.get_node_or_null("Mano")
	if mano:
		mano.struggle(multiplayer.get_remote_sender_id())


@rpc("any_peer", "call_local", "reliable")
func _req_stare(creature_name: String, secs: float) -> void:
	if not multiplayer.is_server():
		return
	var c := creatures_root.get_node_or_null(creature_name)
	if c and c.has_method("add_stare"):
		c.add_stare(multiplayer.get_remote_sender_id(), secs)


@rpc("any_peer", "call_local", "reliable")
func _req_looked_up(creature_name: String) -> void:
	if not multiplayer.is_server():
		return
	var c := creatures_root.get_node_or_null(creature_name)
	if c and c.has_method("mark"):
		c.mark(multiplayer.get_remote_sender_id())


@rpc("any_peer", "call_local", "unreliable")
func _rpc_bell(peer: int) -> void:
	var p := get_player(peer)
	if p:
		Sfx.play_at("bell", p.global_position + Vector3.UP, self, 4.0, randf_range(0.95, 1.05), 45.0)


@rpc("authority", "call_local", "reliable")
func _rpc_lives(peer: int, n: int) -> void:
	lives[peer] = n


@rpc("any_peer", "call_local", "reliable")
func _req_self_revive() -> void:
	if not multiplayer.is_server() or ended:
		return
	var peer := multiplayer.get_remote_sender_id()
	var p := get_player(peer)
	if p == null or p.state != PlayerScript.State.DOWNED or int(lives.get(peer, 0)) <= 0:
		return
	_rpc_lives.rpc(peer, int(lives[peer]) - 1)
	server_set_state(peer, PlayerScript.State.ALIVE)
	server_toast_all("%s got back up. (%d left)" % [p.display_name, int(lives[peer])])


func request_self_revive() -> void:
	stats["self_revives"] += 1
	_req_self_revive.rpc_id(1)


# --- Playtest log -------------------------------------------------------------------------

const LOG_PATH := "user://playtest_log.csv"
const NOTES_PATH := "user://playtest_notes.txt"


func night_summary() -> Dictionary:
	var me := local_player()
	return {
		"mode": config.get("mode", ""), "seed": config.get("seed", 0), "difficulty": config.get("difficulty", "normal"),
		"clock": clock_text(), "seconds": int(elapsed), "cards": ",".join(me.cards if me else []),
		"players": config.get("players", {}).size(),
	}


func _write_log(won: bool, text: String) -> void:
	var exists := FileAccess.file_exists(LOG_PATH)
	var f := FileAccess.open(LOG_PATH, FileAccess.READ_WRITE if exists else FileAccess.WRITE)
	if f == null:
		return
	if exists:
		f.seek_end()
	else:
		f.store_line("date,mode,seed,difficulty,players,result,reached,seconds,cards,distance_m,downed,grabbed,close_calls,notes_read,pickups,self_revives,end_text")
	var s := night_summary()
	var row := [Time.get_datetime_string_from_system(), s["mode"], s["seed"], s["difficulty"], s["players"], "WIN" if won else "LOSS",
		s["clock"], s["seconds"], s["cards"], int(stats["distance"]), stats["downed"], stats["grabbed"], stats["close_calls"],
		stats["notes"], stats["pickups"], stats["self_revives"], "\"" + text.replace("\"", "'") + "\""]
	f.store_line(",".join(row.map(func(v): return str(v))))
	f.close()


func save_note(text: String) -> void:
	if text.strip_edges() == "":
		return
	var exists := FileAccess.file_exists(NOTES_PATH)
	var f := FileAccess.open(NOTES_PATH, FileAccess.READ_WRITE if exists else FileAccess.WRITE)
	if f == null:
		return
	if exists:
		f.seek_end()
	var me := local_player()
	var s := night_summary()
	f.store_line("[%s] %s seed=%s %s pos=%s card=%s :: %s" % [Time.get_datetime_string_from_system(), s["mode"], s["seed"], s["clock"],
		str(me.global_position.snapped(Vector3.ONE)) if me else "?", s["cards"], text])
	f.close()
	toast_local("Note saved.")


# --- Dev tools (host / solo only) ------------------------------------------------------------

func dev_teleport(pos: Vector3) -> void:
	var me := local_player()
	if me:
		me.global_position = pos
		me.velocity = Vector3.ZERO


func dev_summon(cname: String) -> void:
	var c := creatures_root.get_node_or_null(cname)
	var me := local_player()
	if c == null or me == null:
		toast_local("%s isn't in this night." % cname)
		return
	var back: Vector3 = me.global_transform.basis.z * 12.0
	match cname:
		"Llorona":
			c.active = true
			c.global_position = me.global_position + back
			c.state = c.NOTICE
			c.notice_t = c.NOTICE_TIME
			c.target_peer = me.peer_id
		"Lechuza":
			var best: Vector3 = map.perches[0]
			for pr in map.perches:
				if pr.distance_to(me.global_position) < best.distance_to(me.global_position):
					best = pr
			c.perch = best
			c.global_position = best
			c.state = c.WHISTLE
			c.timer = 4.0
			server_sound("whistle", best, 8.0, 60.0)
		"Mano":
			c.cooldown = 0.0
			toast_local("La Mano is hungry. Stand still indoors.")


func dev_freeze(on: bool) -> void:
	frozen = on
	for c in creatures_root.get_children():
		c.set_physics_process(not on)


func dev_skip(seconds: float) -> void:
	elapsed = minf(elapsed + seconds, night_seconds - 1.0)
	if not Net.is_solo:
		_rpc_time.rpc(elapsed)


func dev_bring(item_name: String) -> void:
	var me := local_player()
	if me == null:
		return
	var it: Node = items.get(item_name)
	if it == null:
		for x in items.values():
			if x.kind == item_name and not x.consumed and not x.placed and x.holder == 0:
				it = x
				break
	if it == null or it.consumed or it.placed:
		toast_local("Nothing like that left to bring.")
		return
	if it.holder != 0:
		_server_drop(it.holder)
	var fwd: Vector3 = -me.global_transform.basis.z
	server_item(it, 0, false, false, me.global_position + fwd * 1.2 + Vector3.UP * 0.8)
	toast_local("Brought: %s" % it.display_name())


func dev_set_card(id: String) -> void:
	var me := local_player()
	if me == null:
		return
	me.cards = [] if id == "" else [id]
	me.flashlight.spot_range = 9.0 if me.has_card("luna") else 18.0
	config["cards"][me.peer_id] = me.cards.duplicate()
	hud.refresh_corner_cards(me.cards)
	toast_local("Card is now: %s" % (CardsDB.info(id)["name"] if id != "" else "none"))
