extends Node
## Automated test + screenshot runner. Not used in normal play.
##   godot --path . -- --autotest=menu --shots=/tmp/shots
##   godot --path . -- --autotest=solo:velorio --shots=/tmp/shots
##   godot --path . -- --autotest=logic:ofrenda
##   godot --path . -- --autotest=host:velorio   (and in a 2nd window)  --autotest=join

var mode := ""
var arg := ""
var shots := "user://shots"
var results := []


func _ready() -> void:
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--autotest="):
			var v := a.trim_prefix("--autotest=").split(":")
			mode = v[0]
			arg = v[1] if v.size() > 1 else ""
		elif a.begins_with("--shots="):
			shots = a.trim_prefix("--shots=")
	DirAccess.make_dir_recursive_absolute(shots)
	Settings.invincible = false
	await get_tree().create_timer(0.5).timeout
	match mode:
		"check": _check_scripts("res://")
		"menu": await _menu()
		"solo": await _solo(arg)
		"logic": await _logic(arg)
		"ai": await _ai(arg)
		"tour": await _tour()
		"aisuite": await _aisuite(arg)
		"mouse": await _mouse_test()
		"tools": await _tools_test()
		"tour2": await _tour2()
		"shimmer": await _shimmer(arg)
		"views": await _views(arg)
		"llshots": await _llshots()
		"warnings": await _warnings()
		"navprobe": await _navprobe()
		"navdebug": await _navdebug()
		"host": await _host(arg)
		"join": await _join()
	for r in results:
		print("AUTOTEST ", r)
	print("AUTOTEST DONE")
	get_tree().quit()


func shot(file: String) -> void:
	await RenderingServer.frame_post_draw
	var img := get_viewport().get_texture().get_image()
	img.save_png(shots.path_join(file + ".png"))
	print("AUTOTEST shot ", file)


func wait(t: float) -> void:
	await get_tree().create_timer(t).timeout


func check(name: String, ok: bool) -> void:
	results.append(("PASS " if ok else "FAIL ") + name)


func game() -> Node:
	return get_tree().get_first_node_in_group("game")


func me() -> Node:
	return game().local_player()


func look(p: Node, at: Vector3) -> void:
	var from: Vector3 = p.global_position + Vector3.UP * 1.6
	var d := at - from
	p.rotation.y = atan2(-d.x, -d.z)
	p.head_pitch = atan2(d.y, Vector2(d.x, d.z).length())


func place(p: Node, pos: Vector3, at: Vector3) -> void:
	p.global_position = pos
	p.velocity = Vector3.ZERO
	look(p, at)


# --- Menu ---------------------------------------------------------------------------

func _menu() -> void:
	await wait(0.6)
	await shot("menu_title")
	Net.start_solo()
	await wait(0.4)
	await shot("menu_lobby")
	Net.set_lobby_option("mode", "ofrenda")
	await wait(0.3)
	await shot("menu_lobby_ofrenda")
	var menu: Node = get_parent().menu
	menu.settings_holder.visible = true
	await wait(0.3)
	await shot("menu_settings")


# --- Solo walkthrough with screenshots --------------------------------------------------

func _start(m: String) -> void:
	Net.start_solo()
	Net.set_lobby_option("mode", m)
	Net.set_lobby_option("night", "normal")
	Net.start_game()
	await wait(2.0)


func _solo(m: String) -> void:
	await _start(m)
	var g := game()
	var p := me()
	await shot("%s_01_card" % m)
	g.hud._reveal_time = 0.01
	# Park the creatures out of the way for the establishing shots
	var ll: Node = g.creatures_root.get_node_or_null("Llorona")
	var le: Node = g.creatures_root.get_node_or_null("Lechuza")
	if ll:
		ll.global_position = Vector3(-40, 0, 96)
		ll.state = ll.WANDER
		ll.wander_target = Vector3(-40, 0, 96)
	await wait(0.6)
	await shot("%s_02_spawn" % m)
	match m:
		"velorio":
			place(p, Vector3(-3, 0.1, 3.4), g.map.body_pos + Vector3(0, 0.9, 0))
			await wait(0.5)
			await shot("velorio_03_wake")
			g.mode.set_candle(0, false)
			place(p, g.map.candle_spots[0] + Vector3(1.2, 0.1, 0.4), g.map.candle_spots[0] + Vector3(0, 1.1, 0))
			await wait(0.4)
			await shot("velorio_04_relight_prompt")
		"procesion":
			p.global_position = g.map.body_pos + Vector3(0, 0.1, 1.6)
			look(p, g.mode.coffin.global_position)
			await wait(0.4)
			await shot("procesion_03_coffin")
			g._req_interact.rpc_id(1, String(g.get_path_to(g.mode.coffin)))
			place(p, Vector3(0, 0.1, 50), Vector3(0, 1.0, 80))
			await wait(0.6)
			await shot("procesion_04_carrying_road")
		"ofrenda":
			place(p, g.map.altar_pos + Vector3(0.5, 0.1, 3.0), g.map.altar_pos + Vector3(0, 1.0, 0))
			await wait(0.5)
			await shot("ofrenda_03_altar")
			var note: Node = g.get_node("World").get_node("clue_0")
			g.request_interact(note)
			await wait(0.3)
			await shot("ofrenda_04_clue")
			g.hud.close_note()
		"limpia":
			place(p, g.map.barn_altar_pos + Vector3(-5.5, 0.1, 0), g.map.barn_altar_pos + Vector3(0, 1.0, 0))
			await wait(0.5)
			await shot("limpia_03_barn")
			var sign: Node = g.get_node("World").get_node("sign_0")
			place(p, sign.global_position + Vector3(0, 0.1, 1.6), sign.global_position)
			await wait(0.4)
			await shot("limpia_04_sign")
	# Creature close-ups
	if ll:
		place(p, Vector3(0, 0.1, 40), Vector3(0, 1.4, 48))
		ll.global_position = Vector3(0, 0, 48)
		ll.state = ll.RETREAT
		ll.retreat_time = 99.0
		ll.active = true
		await wait(0.5)
		await shot("%s_05_llorona" % m)
	if le:
		le.state = le.PERCH
		le.timer = 99.0
		le.perch = g.map.perches[1]
		le.global_position = g.map.perches[1]
		place(p, Vector3(g.map.perches[1].x + 5.0, 0.1, g.map.perches[1].z + 3.0), g.map.perches[1] + Vector3(0, 1, 0))
		await wait(0.5)
		await shot("%s_06_lechuza" % m)
	var mano: Node = g.creatures_root.get_node_or_null("Mano")
	if mano:
		place(p, Vector3(5.0, 0.1, -2.5), Vector3(5.0, 0.0, -4.5))
		await wait(0.2)
		mano._grab(p)
		mano.global_position = p.global_position + Vector3(0, -0.6, -1.2)
		await wait(1.2)
		await shot("%s_07_mano" % m)
		mano.free_player()
	Settings.pixelation = false
	Settings.apply()
	place(p, Vector3(0, 0.1, 64), Vector3(0, 2.0, 80))
	await wait(0.5)
	await shot("%s_08_cemetery_nopixel" % m)
	place(p, Vector3(0, 0.1, 77), Vector3(0, 1.5, 92))
	await wait(0.4)
	await shot("%s_09_inside_cemetery" % m)
	Settings.load_settings()
	Settings.apply()


# --- Logic tests (no screenshots needed) ------------------------------------------------

func _logic(m: String) -> void:
	Settings.invincible = false
	await _start(m)
	var g := game()
	var p := me()
	g.hud._reveal_time = 0.01
	for c in g.creatures_root.get_children():
		c.global_position = Vector3(80, -20, 150)   # keep them away during logic tests
		c.set_physics_process(false)
	await wait(0.3)
	match m:
		"velorio":
			var before: int = g.mode.matches
			g.mode.set_candle(2, false)
			p.global_position = g.map.candle_spots[2] + Vector3(1, 0, 0)
			g._req_interact.rpc_id(1, String(g.get_path_to(g.get_node("World/candle_2"))))
			check("velorio relight uses a match", g.mode.lit[2] and g.mode.matches == before - 1)
			var m0: Node = g.items["cerillos_0"]
			p.global_position = m0.global_position
			g._req_interact.rpc_id(1, String(g.get_path_to(m0)))
			check("velorio matches pickup +3", g.mode.matches == before + 2 and m0.consumed)
			for i in g.mode.lit.size():
				g.mode.set_candle(i, false)
			g.mode.dark_time = g.mode.DARK_LIMIT - 0.1
			await wait(0.5)
			check("velorio darkness loses", g.ended)
		"procesion":
			var coffin: Node = g.mode.coffin
			p.global_position = coffin.global_position + Vector3(0, 0, 1)
			g._req_interact.rpc_id(1, String(g.get_path_to(coffin)))
			check("procesion lift coffin", coffin.holder == p.peer_id)
			check("procesion carry slows", g.carry_speed_mult(p.peer_id) < 0.6)
			p.global_position = g.map.cemetery_goal
			await wait(0.6)
			check("procesion delivered wins", g.ended)
		"ofrenda":
			var prof: Dictionary = g.mode.profile
			var wrong := ""
			for k in ["sombrero", "rosario", "baraja"]:
				if not (k in prof["items"]):
					wrong = k
					break
			var altar: Node = g.get_node("World/altar")
			_give(g, p, "of_" + wrong)
			p.global_position = altar.global_position + Vector3(0, 0, 1)
			g._req_interact.rpc_id(1, String(g.get_path_to(altar)))
			check("ofrenda wrong offering rejected", g.mode.mistakes == 1 and g.mode.placed.is_empty())
			for k in prof["items"]:
				_give(g, p, "of_" + k)
				p.global_position = altar.global_position + Vector3(0, 0, 1)
				g._req_interact.rpc_id(1, String(g.get_path_to(altar)))
			await wait(0.2)
			check("ofrenda 4 correct wins", g.ended and g.mode.placed.size() == 4)
		"limpia":
			var altar: Node = g.get_node("World/altar")
			var remedy: String = g.mode.REMEDY[g.mode.curse]
			var wrong_herb := "albahaca"
			_give(g, p, wrong_herb)
			p.global_position = altar.global_position + Vector3(1, 0, 0)
			g._req_interact.rpc_id(1, String(g.get_path_to(altar)))
			check("limpia wrong herb rejected", g.mode.slots["herb"] == "")
			_give(g, p, "huevo")
			p.global_position = altar.global_position + Vector3(1, 0, 0)
			g._req_interact.rpc_id(1, String(g.get_path_to(altar)))
			_give(g, p, remedy)
			p.global_position = altar.global_position + Vector3(1, 0, 0)
			g._req_interact.rpc_id(1, String(g.get_path_to(altar)))
			check("limpia altar ready", g.mode.ritual_ready)
			check("limpia only cursed creature spawned (%s)" % g.mode.curse, g.creatures_root.get_child_count() == 1)
			g._req_interact.rpc_id(1, String(g.get_path_to(altar)))
			await wait(0.2)
			check("limpia ritual wins", g.ended)
	# Shared: down + death in solo, darkness etc.
	print("AUTOTEST end text: ", g.hud.end_panel != null)


func _give(g: Node, p: Node, item_name: String) -> void:
	var it: Node = g.items[item_name]
	var held: Node = g.held_item(p.peer_id)
	if held:
		g._server_drop(p.peer_id)
	p.global_position = it.global_position + Vector3(0, 0, 0.5)
	g._req_interact.rpc_id(1, String(g.get_path_to(it)))


# --- Multiplayer -----------------------------------------------------------------------

func _host(m: String) -> void:
	Settings.player_name = "Leon (host)"
	Net.host()
	Net.set_lobby_option("mode", m)
	var t := 0.0
	while Net.players.size() < 2 and t < 30.0:
		await wait(0.5)
		t += 0.5
	check("host sees client in lobby", Net.players.size() == 2)
	await wait(1.0)
	await shot("mp_host_lobby")
	Net.start_game()
	await wait(3.0)
	var g := game()
	g.hud._reveal_time = 0.01
	var p := me()
	for c in g.creatures_root.get_children():
		c.global_position = Vector3(80, 0, 150)
	place(p, Vector3(1.5, 0.1, 12), Vector3(-1.5, 1.4, 14))
	await wait(2.0)
	g.mode_call("set_candle", [1, false])
	await wait(4.0)
	var client: Node = null
	for pl in g.get_players():
		if pl.peer_id != 1:
			client = pl
	check("host sees client player", client != null)
	if client:
		print("AUTOTEST host sees client at ", client.global_position)
		check("client movement synced to host", client.global_position.distance_to(Vector3(-1.5, 0.1, 14)) < 1.0)
	await shot("mp_host_view")
	# Revive test: host goes down, client revives
	g.server_down_player(1, "test")
	await wait(0.5)
	check("host is downed", p.state == p.State.DOWNED)
	var t2 := 0.0
	while p.state == p.State.DOWNED and t2 < 10.0:
		await wait(0.25)
		t2 += 0.25
	check("client revived host", p.state == p.State.ALIVE)
	# La Llorona notices the CLIENT: the client's HUD must say so (state + target + hide bar are synced)
	var ll: Node = g.creatures_root.get_node_or_null("Llorona")
	if ll and client:
		ll.set_physics_process(false)
		ll.active = true
		ll.global_position = client.global_position + Vector3(0, 0, 14)
		ll.target_peer = client.peer_id
		ll.state = ll.STALK
		ll.hide_progress = 0.5
		await wait(5.0)
		ll.state = ll.WANDER
		ll.hide_progress = 0.0
	await wait(3.0)


func _join() -> void:
	Settings.player_name = "Amigo"
	Net.join("127.0.0.1")
	var t := 0.0
	while game() == null and t < 40.0:
		await wait(0.5)
		t += 0.5
	check("client got game start", game() != null)
	if game() == null:
		return
	await wait(1.0)
	var g := game()
	g.hud._reveal_time = 0.01
	var p := me()
	place(p, Vector3(-1.5, 0.1, 14), Vector3(1.5, 1.4, 12))
	await wait(6.0)
	var host_p: Node = g.get_player(1)
	print("AUTOTEST client sees host at ", host_p.global_position)
	check("host movement synced to client", host_p.global_position.distance_to(Vector3(1.5, 0.1, 12)) < 1.0)
	check("candle state synced to client", g.mode.lit.size() > 1 and g.mode.lit[1] == false)
	check("client has own secret card", p.cards.size() == 1)
	check("client doesn't display host card", host_p.cards.is_empty())
	await shot("mp_client_view")
	var t2 := 0.0
	while host_p.state != host_p.State.DOWNED and t2 < 10.0:
		await wait(0.25)
		t2 += 0.25
	check("client sees host downed", host_p.state == host_p.State.DOWNED)
	await wait(0.5)
	await shot("mp_client_host_downed")
	p.global_position = host_p.global_position + Vector3(0, 0, 1.2)
	g.request_interact(host_p)
	await wait(1.0)
	check("revive synced back to client", host_p.state == host_p.State.ALIVE)
	var seen := ""
	var bar := false
	var t3 := 0.0
	while t3 < 9.0 and seen == "":
		await wait(0.25)
		t3 += 0.25
		if g.hud.threat_label.text == "SHE HAS NOTICED YOU":
			seen = g.hud.threat_label.text
			await wait(0.5)
			bar = g.hud.hide_bar.visible
			await shot("mp_client_llorona_noticed")
	check("client HUD shows La Llorona noticed THEM (host-run AI, synced)", seen != "")
	check("client sees the synced hiding bar", bar)
	await wait(2.0)


func _check_scripts(dir: String) -> void:
	for f in DirAccess.get_files_at(dir):
		if f.ends_with(".gd"):
			var s = load(dir.path_join(f))
			check("load " + dir.path_join(f), s != null and s.can_instantiate())
	for d in DirAccess.get_directories_at(dir):
		if not d.begins_with("."):
			_check_scripts(dir.path_join(d))


# --- Creature AI tests ----------------------------------------------------------------

func _ai(which: String) -> void:
	Net.lobby["lives"] = 0   # hardcore: being caught in solo = dead
	await _start("velorio")
	var g := game()
	var p := me()
	g.hud._reveal_time = 0.01
	g.mode.set_physics_process(false)
	g.mode.matches = 99
	# Keep the other creatures away
	for c in g.creatures_root.get_children():
		if c.name.to_lower() != which:
			c.global_position = Vector3(80, -20, 150)
			c.set_physics_process(false)
	match which:
		"llorona":
			var ll: Node = g.creatures_root.get_node("Llorona")
			place(p, Vector3(0, 0.1, 40), Vector3(0, 1.4, 60))
			ll.global_position = Vector3(1.5, 0, 58)
			ll.state = ll.WANDER
			ll.wander_target = Vector3(1.5, 0, 58)
			var start: Vector3 = ll.global_position
			var saw_chase := false
			var t := 0.0
			while t < 20.0 and not g.ended:
				await wait(0.25)
				t += 0.25
				look(p, ll.global_position + Vector3.UP * 1.5)   # staring at her
				if ll.state == ll.CHASE:
					saw_chase = true
			print("AUTOTEST llorona moved ", start.distance_to(ll.global_position), " in ", t, "s")
			check("llorona navigates (moved > 3m)", saw_chase or start.distance_to(ll.global_position) > 3.0)
			check("llorona chases a staring player", saw_chase)
			check("llorona catch kills solo player", p.state == p.State.DEAD and g.ended)
		"lechuza":
			var le: Node = g.creatures_root.get_node("Lechuza")
			place(p, Vector3(-3, 0.1, 1), Vector3(-3, 1, -3))
			le.global_position = g.map.perches[0]
			le.state = le.WHISTLE
			le.mark(1)
			await wait(4.0)
			check("lechuza can't take you under a roof", p.state == p.State.ALIVE)
			place(p, Vector3(10, 0.1, 45), Vector3(10, 1, 52))
			await wait(1.0)
			le.state = le.WHISTLE
			le.global_position = g.map.perches[1]
			le.mark(1)
			await wait(6.0)
			check("lechuza takes you in the open", p.state == p.State.DEAD)
		"mano":
			var mano: Node = g.creatures_root.get_node("Mano")
			mano.cooldown = 0.0
			place(p, Vector3(4.5, 0.1, -3), Vector3(4.5, 1, -5))
			var t := 0.0
			while p.state != p.State.GRABBED and t < 8.0:
				await wait(0.25)
				t += 0.25
			check("mano grabs a player standing still indoors (%.1fs)" % t, p.state == p.State.GRABBED)
			for i in 9:
				g._req_struggle.rpc_id(1)
			await wait(0.2)
			check("mashing E breaks free", p.state == p.State.ALIVE)
			mano.cooldown = 0.0
			t = 0.0
			while p.state != p.State.DEAD and t < 16.0:
				await wait(0.25)
				t += 0.25
			check("held too long = dragged under", p.state == p.State.DEAD)


# --- Scripted camera tour for recording a video (use with --write-movie) ---------------

func _tour() -> void:
	await _start("velorio")
	var g := game()
	var p := me()
	for c in g.creatures_root.get_children():
		c.global_position = Vector3(80, -20, 150)
		c.set_physics_process(false)
	g.mode.set_physics_process(false)
	g.mode._wind_cd = 999.0
	var ll: Node = g.creatures_root.get_node("Llorona")
	var keys := [
		[0.0, Vector3(0, 0.1, 14), Vector3(-2.5, 1.3, 0)],
		[3.0, Vector3(-2.5, 0.1, 7.0), Vector3(-3, 1.0, -1)],
		[6.0, Vector3(-1.3, 0.1, 2.2), Vector3(-3, 1.0, -1)],
		[8.5, Vector3(-1.3, 0.1, 2.2), g.map.candle_spots[0] + Vector3(0, 1.0, 0)],
		[10.5, Vector3(-2.5, 0.1, 4.2), Vector3(-2.5, 1.5, 14)],
		[13.5, Vector3(-2.0, 0.1, 13.0), Vector3(0, 1.6, 30)],
		[17.5, Vector3(-1.5, 0.1, 15.5), Vector3(0, 1.6, 26)],
		[18.3, Vector3(-1.6, 0.1, 15.0), Vector3(-2.5, 1.4, 0)],
		[21.0, Vector3(-2.5, 0.1, 5.5), Vector3(-3, 1.2, -1)],
	]
	var t := -2.5
	var events := {6.5: "blow", 9.0: "relight", 12.0: "llorona", 17.4: "chase"}
	while t < 21.5:
		await get_tree().process_frame
		var dt := get_process_delta_time()
		t += dt
		if t < 0.0:
			continue
		if t > 0.0 and g.hud._reveal_time > 0.0:
			g.hud._reveal_time = 0.01
		for e in events.keys():
			if t >= e:
				_tour_event(events[e], g, p, ll)
				events.erase(e)
		var i := 0
		while i < keys.size() - 2 and t > keys[i + 1][0]:
			i += 1
		var a: Array = keys[i]
		var b: Array = keys[i + 1]
		var k := clampf((t - a[0]) / (b[0] - a[0]), 0.0, 1.0)
		k = k * k * (3.0 - 2.0 * k)
		p.global_position = (a[1] as Vector3).lerp(b[1], k)
		var look_at_pt: Vector3 = (a[2] as Vector3).lerp(b[2], k)
		var from: Vector3 = p.global_position + Vector3.UP * 1.6
		var d := look_at_pt - from
		p.rotation.y = lerp_angle(p.rotation.y, atan2(-d.x, -d.z), 0.25)
		p.head_pitch = lerpf(p.head_pitch, atan2(d.y, Vector2(d.x, d.z).length()), 0.25)
		if ll.active and ll.state == ll.RETREAT:
			var tgt: Vector3 = p.global_position
			tgt.y = 0
			var speed := 1.2 if t < 17.4 else 6.0
			ll.global_position = ll.global_position.move_toward(tgt, speed * dt)
			ll.face(tgt)


func _tour_event(e: String, g: Node, p: Node, ll: Node) -> void:
	match e:
		"blow":
			g.mode.set_candle(0, false)
			Sfx.play_at("puff", g.map.candle_spots[0] + Vector3.UP, g, 6.0)
			g.toast_local("A cold draft. One of the candles goes out.")
		"relight":
			g.mode.set_matches(g.mode.matches - 1)
			g.mode.set_candle(0, true)
			Sfx.play("match", 0.0)
		"llorona":
			ll.set_physics_process(true)
			ll.global_position = Vector3(1.5, 0, 34)
			ll.state = ll.RETREAT
			ll.retreat_time = 999.0
			ll.active = true
		"chase":
			g.toast_local("She's coming for you. RUN.")
			Sfx.play("sting", -4.0)


# --- Thorough AI suite ----------------------------------------------------------------

func _setup_ai_night(m := "velorio", difficulty := "normal") -> void:
	Net.start_solo()
	Net.set_lobby_option("mode", m)
	Net.set_lobby_option("night", "endless")
	Net.set_lobby_option("difficulty", difficulty)
	Net.set_lobby_option("card", "none")
	Net.start_game()
	await wait(2.0)
	game().hud._reveal_time = 0.01
	game().mode_paused = true


func _only(which: String) -> void:
	for c in game().creatures_root.get_children():
		if c.name.to_lower() != which:
			c.global_position = Vector3(80, -20, 150)
			c.set_physics_process(false)
			c.active = false
			c.visible = false


func _aisuite(part: String) -> void:
	Settings.invincible = true
	match part:
		"llorona_nav": await _suite_llorona_nav()
		"llorona_behavior": await _suite_llorona_behavior()
		"lechuza": await _suite_lechuza()
		"mano": await _suite_mano()
		"soak": await _suite_soak()
		"difficulty": await _suite_difficulty()
	Settings.invincible = false


## Can La Llorona physically reach every part of the map?
func _suite_llorona_nav() -> void:
	await _setup_ai_night()
	_only("llorona")
	var g := game()
	var p := me()
	var ll: Node = g.creatures_root.get_node("Llorona")
	var spots: Dictionary = g.map.test_spots   # every house, the troje, coop, well, plaza, capilla, creek, camposanto, edges
	for label in spots:
		var target: Vector3 = spots[label]
		place(p, target, target + Vector3(0, 1.6, -3))
		# Start her far away, on the other side of the map
		var start := Vector3(-29, 0, 20) if target.x > 0 else Vector3(30, 0, 66)
		ll.global_position = start
		ll.active = true
		ll.calm = 0.0
		ll.target_peer = 1
		ll.state = ll.CHASE
		ll.chase_time = -999.0     # don't give up for this test
		ll.lost_time = -999.0
		var t := 0.0
		var reached := false
		while t < 45.0:
			await wait(0.25)
			t += 0.25
			ll.chase_time = -999.0
			ll.lost_time = -999.0
			ll.enraged = 999.0     # she always knows where the target is: this tests PATHING, not hiding
			if ll.state == ll.RETREAT or ll.global_position.distance_to(p.global_position) < 1.6:
				reached = true
				break
		check("llorona reaches %s (%.1fs from %dm)" % [label, t, int(start.distance_to(target))], reached)
		ll.enraged = 0.0
		ll.state = ll.WANDER
		ll.retreat_time = 0.0


## Wander, stalk, chase, lose, give up, calm down, recover.
func _suite_llorona_behavior() -> void:
	await _setup_ai_night()
	_only("llorona")
	var g := game()
	var p := me()
	var ll: Node = g.creatures_root.get_node("Llorona")
	# 1) Nobody around: she wanders and keeps moving
	place(p, Vector3(38, 0.1, 98), Vector3(30, 1, 98))
	ll.global_position = g.map.water_points[0]
	ll.state = ll.WANDER
	var visited := 0.0
	var last: Vector3 = ll.global_position
	var max_still := 0.0
	var still := 0.0
	for i in 120:
		await wait(0.25)
		var d: float = ll.global_position.distance_to(last)
		visited += d
		still = still + 0.25 if d < 0.05 else 0.0
		if still > 2.0 and still <= 2.25:
			print("AUTOTEST wander stall at %v target %v" % [ll.global_position, ll.wander_target])
		max_still = maxf(max_still, still)
		last = ll.global_position
	print("AUTOTEST wander: %.1fm in 30s, longest pause %.1fs" % [visited, max_still])
	check("llorona wanders (>25m in 30s)", visited > 25.0)
	check("llorona never stuck > 3s while wandering", max_still <= 3.0)
	check("llorona stays inside map bounds", g.map.BOUNDS.has_point(ll.global_position + Vector3.UP))
	check("her weeping is positional (you can hear where she is)", ll._cry is AudioStreamPlayer3D)
	check("while wandering the positional weeping is on and the muffled one is off", ll._cry.volume_db > -6.0 and ll._far.volume_db < -50.0)

	# 2) A quiet player down the street, looking away: she NOTICES (stops, whispers), then stalks. Clear tells.
	_reset_llorona(ll)
	place(p, Vector3(0, 0.1, 50), Vector3(0, 1.6, 30))
	ll.global_position = Vector3(0, 0, 64)
	var states := {}
	var hud_text := ""
	var far_db := -80.0
	var cry_db := 0.0
	for i in 24:
		await wait(0.25)
		look(p, Vector3(0, 1.6, 30))  # look away
		states[ll.state] = true
		if ll.state == ll.NOTICE or ll.state == ll.STALK:
			hud_text = g.hud.threat_label.text
			far_db = maxf(far_db, ll._far.volume_db)
			cry_db = ll._cry.volume_db
		if ll.state == ll.STALK and i > 8:
			break
	check("she NOTICES a player first (a pause before she comes)", states.has(ll.NOTICE))
	check("then she stalks", states.has(ll.STALK))
	check("HUD tells the target: SHE HAS NOTICED YOU (got '%s')" % hud_text, hud_text == "SHE HAS NOTICED YOU")
	check("tell: the weeping turns muffled and far-away (%.0f dB)" % far_db, far_db > -24.0)
	check("tell: the positional weeping stops (%.0f dB)" % cry_db, cry_db < -30.0)

	# 3) COUNTERPLAY: duck into an alley out of her sight and crouch -> she loses you (and the HUD says so)
	_reset_llorona(ll)
	place(p, Vector3(0, 0.1, 18), Vector3(0, 1.6, 30))
	ll.global_position = Vector3(0, 0, 31)
	await _wait_state(ll, ll.NOTICE, 6.0)
	await _drive_to(p, Vector3(-3.0, 0.1, 16.6), "walk")
	var saw_bar := false
	var lost := false
	var lost_text := ""
	await _drive_to(p, Vector3(-8.5, 0.1, 16.6), "crouch")
	Input.action_press("crouch")
	for i in 40:
		await wait(0.25)
		saw_bar = saw_bar or g.hud.hide_bar.visible
		if ll.state == ll.WANDER:
			lost = true
			await wait(0.2)
			lost_text = g.hud.threat_label.text
			break
	Input.action_release("crouch")
	check("hiding out of sight + crouching makes her lose you", lost and p.state == p.State.ALIVE and ll.state != ll.RETREAT)
	check("a 'hiding' bar filled while you hid", saw_bar)
	check("HUD says 'She lost you.' (got '%s')" % lost_text, lost_text == "She lost you.")
	check("after losing you she leaves people alone for a moment", ll.calm > 0.0)

	# 4) NOT a way out: just walking away in plain view. She keeps you and ends up charging.
	_reset_llorona(ll)
	place(p, Vector3(0, 0.1, 30), Vector3(0, 1.6, 10))
	ll.global_position = Vector3(0, 0, 44)
	await _wait_state(ll, ll.NOTICE, 6.0)
	var lost_walking := false
	var max_hide := 0.0
	var charged_or_caught := false
	var route := [Vector3(0, 0.1, 10), Vector3(0, 0.1, 30)]
	var t := 0.0
	var leg := 0
	while t < 20.0:
		var d0 := Time.get_ticks_msec()
		await _drive_to(p, route[leg % 2], "walk", 6.0)
		leg += 1
		t += float(Time.get_ticks_msec() - d0) / 1000.0
		max_hide = maxf(max_hide, ll.hide_progress)
		if ll.state == ll.WANDER:
			lost_walking = true
		if ll.state == ll.CHASE or ll.state == ll.RETREAT:
			charged_or_caught = true
			break
	check("walking away in the open does NOT lose her", not lost_walking)
	check("...she ends up charging you", charged_or_caught)

	# 5) Staring at her makes her charge
	_reset_llorona(ll)
	place(p, Vector3(0, 0.1, 40), Vector3(0, 1.6, 55))
	ll.global_position = Vector3(0, 0, 55)
	ll.state = ll.STALK
	ll.target_peer = 1
	var charged := false
	var charge_text := ""
	for i in 24:
		await wait(0.25)
		look(p, ll.global_position + Vector3.UP * 1.5)
		if ll.state == ll.CHASE:
			charged = true
			await wait(0.1)
			charge_text = g.hud.threat_label.text
			break
	check("staring at her makes her charge", charged)
	check("HUD says SHE'S CHARGING (got '%s')" % charge_text, charge_text == "SHE'S CHARGING")

	# 6) COUNTERPLAY when she charges: sprint into the casa, through to the bedroom, crouch out of sight
	_reset_llorona(ll)
	place(p, Vector3(0, 0.1, 12), Vector3(0, 1.6, 0))
	ll.global_position = Vector3(0, 0, 26)
	ll.state = ll.CHASE
	ll.target_peer = 1
	for wp in [Vector3(-2.5, 0.1, 6.8), Vector3(-2.5, 0.1, 3.5), Vector3(1.0, 0.1, 2.0), Vector3(4.5, 0.1, 1.6), Vector3(4.5, 0.1, -1.2)]:
		await _drive_to(p, wp, "sprint", 6.0)
	await _drive_to(p, Vector3(5.8, 0.1, -2.6), "crouch", 4.0)
	Input.action_press("crouch")
	var escaped := false
	for i in 40:
		await wait(0.25)
		if ll.state == ll.WANDER:
			escaped = true
			break
		if ll.state == ll.RETREAT:
			break
	Input.action_release("crouch")
	print("AUTOTEST charge escape: state=%d hide=%.2f dist=%.1f" % [ll.state, ll.hide_progress, ll.global_position.distance_to(p.global_position)])
	check("a charge can be escaped: break line of sight, then crouch", escaped)

	# 7) Catch -> retreat to the water -> comes back to WANDER
	_reset_llorona(ll)
	place(p, Vector3(0, 0.1, 40), Vector3(0, 1.6, 55))
	ll.state = ll.CHASE
	ll.target_peer = 1
	ll.global_position = p.global_position + Vector3(0, 0, 3)
	var caught := false
	for i in 20:
		await wait(0.25)
		if ll.state == ll.RETREAT:
			caught = true
			break
	check("catch sends her back to the water (retreat)", caught and not ll.active)
	await wait(7.0)
	check("she returns after retreating", ll.active and ll.state != ll.RETREAT)

	# 8) Sprinting noise is heard through walls
	_reset_llorona(ll)
	place(p, Vector3(-7.5, 0.1, 52.1), Vector3(-7.5, 1.6, 49))   # inside the casa azul
	ll.global_position = Vector3(-16, 0, 52.1)                  # in its back patio, behind the wall: no line of sight
	p.set_physics_process(false)
	p.noise = 14.0
	var heard := false
	for i in 12:
		await wait(0.25)
		p.noise = 14.0
		if ll.state != ll.WANDER:
			heard = true
			break
	p.set_physics_process(true)
	check("she hears a sprinting player through walls", heard)

	# 9) ...but not a crouching one
	_reset_llorona(ll)
	ll.global_position = Vector3(-16, 0, 52.1)
	p.set_physics_process(false)
	p.noise = 2.0   # crouching (and clear the sprint noise left over from the step above)
	var noticed := false
	for i in 12:
		await wait(0.25)
		p.noise = 2.0
		if ll.state != ll.WANDER and not noticed:
			noticed = true
			print("AUTOTEST crouch-wall: state=%d llpos=%v ppos=%v see=%s noise=%.1f" % [ll.state, ll.global_position, p.global_position, str(ll.can_see(p, 30.0)), p.noise])
	p.set_physics_process(true)
	check("she does not hear a crouching player through a wall", not noticed)


func _reset_llorona(ll: Node) -> void:
	ll.state = ll.WANDER
	ll.active = true
	ll.calm = 0.0
	ll.enraged = 0.0
	ll.retreat_time = 0.0
	ll.stare_time.clear()
	ll._tracked = -1
	ll.hide_t = 0.0
	ll.hide_progress = 0.0
	ll.target_peer = 0
	Input.action_release("crouch")
	Input.action_release("sprint")
	Input.action_release("move_forward")


func _wait_state(c: Node, st: int, timeout: float) -> bool:
	var t := 0.0
	while c.state != st and t < timeout:
		await wait(0.1)
		t += 0.1
	return c.state == st


## Walks the REAL player (physics + collisions) to a point by holding W (and Shift / C).
func _drive_to(p: Node, target: Vector3, how := "walk", timeout := 15.0) -> bool:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	var t := 0.0
	var ok := false
	while t < timeout:
		var to: Vector3 = target - p.global_position
		to.y = 0
		if to.length() < 0.6:
			ok = true
			break
		p.rotation.y = atan2(-to.x, -to.z)
		p.head_pitch = 0.0
		Input.action_press("move_forward")
		if how == "sprint":
			Input.action_press("sprint")
		else:
			Input.action_release("sprint")
		if how == "crouch":
			Input.action_press("crouch")
		else:
			Input.action_release("crouch")
		await get_tree().physics_frame
		t += get_physics_process_delta_time()
	Input.action_release("move_forward")
	Input.action_release("sprint")
	return ok


func _suite_lechuza() -> void:
	await _setup_ai_night()
	_only("lechuza")
	var g := game()
	var p := me()
	var le: Node = g.creatures_root.get_node("Lechuza")
	place(p, Vector3(38, 0.1, 98), Vector3(30, 1, 98))
	# 1) Idle cycle: perches, whistles repeatedly, stays on rooftops
	var whistles := 0
	var perches := {}
	var prev: int = le.state
	le.timer = 2.0
	for i in 240:
		await wait(0.25)
		if le.state == le.WHISTLE and prev != le.WHISTLE:
			whistles += 1
		prev = le.state
		perches[str(le.perch)] = true
		if is_nan(le.global_position.x):
			break
	print("AUTOTEST lechuza: %d whistles, %d perches in 60s" % [whistles, perches.size()])
	check("lechuza whistles periodically (>=2 in 60s)", whistles >= 2)
	check("lechuza position valid", not is_nan(le.global_position.x) and g.map.BOUNDS.has_point(le.global_position))
	# 2) Looking at her while she whistles marks you (via the real client check)
	var perch: Vector3 = g.map.perches[1]
	le.perch = perch
	le.global_position = perch
	le.state = le.WHISTLE
	le.timer = 4.0
	le._reported = false
	place(p, Vector3(perch.x + 4.5, 0.1, perch.z + 2.0), perch + Vector3(0, 1.0, 0))   # on the street below her
	var marked := false
	for i in 16:
		await wait(0.25)
		look(p, le.global_position + Vector3.UP * 0.9)
		if le.state == le.DIVE:
			marked = true
			break
	check("looking up at a whistling lechuza marks you", marked)
	# 3) Not looking while she whistles = safe
	le.state = le.WHISTLE
	le.timer = 4.0
	le.marked_peer = 0
	le.global_position = perch
	le._reported = false
	place(p, Vector3(perch.x + 4.5, 0.1, perch.z + 2.0), perch + Vector3(20, 1.0, 0))
	var safe := true
	for i in 14:
		await wait(0.25)
		look(p, perch + Vector3(20, 1.0, 0))
		if le.state == le.DIVE:
			safe = false
	check("looking away keeps you safe", safe)
	# 4) Dive escape: run under a roof during the dive
	le.state = le.WHISTLE
	le.global_position = g.map.perches[0] + Vector3(0, 6, 25)
	place(p, Vector3(-2.5, 0.1, 12), Vector3(-2.5, 1, 0))
	le.mark(1)
	await wait(0.3)
	place(p, Vector3(-3, 0.1, 1.5), Vector3(-3, 1, -3))   # into the casa
	var t := 0.0
	while le.state == le.DIVE and t < 8.0:
		await wait(0.25)
		t += 0.25
	check("lechuza gives up on a sheltered player and flies home", le.state == le.FLY or le.state == le.PERCH)
	check("sheltered player survived", p.state == p.State.ALIVE)
	await wait(6.0)
	check("lechuza lands back on a perch", le.state == le.PERCH)


func _suite_mano() -> void:
	await _setup_ai_night()
	_only("mano")
	var g := game()
	var p := me()
	var mano: Node = g.creatures_root.get_node("Mano")
	mano.cooldown = 0.0
	# 1) Walking around indoors in small steps (like a network-synced player) never triggers
	p.set_physics_process(false)
	var center := Vector3(-4, 0.1, 1)
	var grabbed := false
	for i in 120:   # 15s, teleporting in 0.1s steps at walking speed
		await wait(0.125)
		var a := i * 0.12
		p.global_position = center + Vector3(cos(a) * 1.8, 0, sin(a) * 1.8)
		if p.state == p.State.GRABBED:
			grabbed = true
	check("walking indoors is safe (15s, jittery updates)", not grabbed)
	# 2) Standing still OUTSIDE is safe
	p.global_position = Vector3(0, 0.1, 20)
	for i in 32:
		await wait(0.25)
		if p.state == p.State.GRABBED:
			grabbed = true
	check("standing still outdoors is safe (8s)", not grabbed)
	# 3) Standing still indoors gets you grabbed, in every building
	var ts: Dictionary = game().map.test_spots
	for spot in [Vector3(-5, 0.1, 2), ts["casa de los pérez"], ts["casa vacía"], ts["troje"]]:
		mano.cooldown = 0.0
		p.global_position = spot
		var t := 0.0
		while p.state != p.State.GRABBED and t < 7.0:
			await wait(0.25)
			t += 0.25
		check("still indoors at %s -> grabbed in %.1fs" % [str(spot), t], p.state == p.State.GRABBED)
		check("  the hand is visible while grabbing", mano.active and mano.visible)
		for k in 9:
			g._req_struggle.rpc_id(1)
		await wait(0.3)
		check("  struggling frees you", p.state == p.State.ALIVE and not mano.active)
	# 4) Cooldown: right after escaping it can't grab again immediately
	p.global_position = Vector3(-5, 0.1, 2)
	var regrab := false
	for i in 20:
		await wait(0.25)
		if p.state == p.State.GRABBED:
			regrab = true
	check("cooldown after escaping (no instant re-grab)", not regrab)
	p.set_physics_process(true)


## A bot wanders the whole map for a full short night with all creatures on.
var _soak_prev := -1


func _soak_night(night: int) -> Dictionary:
	Settings.invincible = true
	Net.start_solo()
	Net.set_lobby_option("mode", "velorio")
	Net.set_lobby_option("night", "short")
	Net.set_lobby_option("card", "none")
	Net.set_lobby_option("seed", 1000 + night)
	Net.start_game()
	await wait(2.0)
	var g := game()
	g.hud._reveal_time = 0.01
	var p := me()
	Engine.time_scale = 4.0
	var ts: Dictionary = g.map.test_spots
	var route := [Vector3(0, 0.1, 13), Vector3(-2.5, 0.1, 2), Vector3(5, 0.1, 3), Vector3(5, 0.1, -3), Vector3(0, 0.1, 30),
		ts["casa de los pérez"], Vector3(0, 0.1, 45), ts["casa vacía"], Vector3(0, 0.1, 70), ts["cemetery"],
		ts["plaza"], ts["well"], ts["troje"], ts["creek"], ts["tienda"], Vector3(0, 0.1, 13)]
	var states := {"Llorona": {}, "Lechuza": {}, "Mano": {}}
	var nan := false
	var outside := false
	var grabs := 0
	var downs := 0
	var prev_state: int = p.state
	var i := 0
	var t := 0.0
	var pause_t := 0.0
	var catches := 0
	var was_retreat := false
	while not g.ended and t < 70.0:   # 70 real s * 4 = 280 game s (> 240 night)
		await get_tree().process_frame
		t += get_process_delta_time() / Engine.time_scale
		var target: Vector3 = route[i % route.size()]
		var to: Vector3 = target - p.global_position
		to.y = 0
		if pause_t > 0.0:
			pause_t -= get_process_delta_time()
			p.noise = 0.5
		elif to.length() < 1.0:
			i += 1
			pause_t = 5.0 if g.map.is_indoors(target) else 2.5   # search rooms, glance around outside
		else:
			var sprinting := fmod(t, 12.0) < 3.0   # short sprint bursts, like real stamina
			var spd := 5.8 if sprinting else 3.2
			p.global_position += to.normalized() * minf(spd * get_process_delta_time(), to.length())
			p.rotation.y = atan2(-to.x, -to.z)
			p.noise = 14.0 if sprinting else 6.0
		for c in g.creatures_root.get_children():
			var st = c.get("state")
			if st != null:
				states[String(c.name)][st] = true
			if is_nan(c.global_position.x):
				nan = true
			if c.active and not g.map.BOUNDS.grow(2.0).has_point(c.global_position + Vector3.UP * 0.5):
				outside = true
		var lls: Node = g.creatures_root.get_node("Llorona")
		if lls.state != _soak_prev:
			print("AUTOTEST soak llorona t=%.1f %d->%d d=%.1f hide=%.2f" % [t * 4.0, _soak_prev, lls.state, lls.global_position.distance_to(p.global_position), lls.hide_progress])
			_soak_prev = lls.state
		if lls.state == lls.RETREAT and not was_retreat:
			catches += 1
		was_retreat = lls.state == lls.RETREAT
		if p.state != prev_state:
			if p.state == p.State.GRABBED:
				grabs += 1
		prev_state = p.state
		if p.state == p.State.GRABBED:
			g._req_struggle.rpc_id(1)
	Engine.time_scale = 1.0
	var hunts := 0
	for st in states["Llorona"].keys():
		if st == 1 or st == 2 or st == 4:
			hunts += 1
	print("AUTOTEST soak night %d: llorona states %s, lechuza states %s, grabs %d, catches %d" % [night, str(states["Llorona"].keys()), str(states["Lechuza"].keys()), grabs, catches])
	var res := {"ended": g.ended, "nan": nan, "outside": outside, "grabs": grabs, "catches": catches,
		"hunted": states["Llorona"].has(4) or states["Llorona"].has(1), "charged": states["Llorona"].has(2),
		"lechuza": states["Lechuza"].has(0) and states["Lechuza"].has(1)}
	await wait(1.0)
	return res


## A bot that never hides plays three short nights with all creatures on.
func _suite_soak() -> void:
	var all := []
	for n in 3:
		all.append(await _soak_night(n))
		_soak_prev = -1
	var catches := 0
	var hunted := 0
	var charged := 0
	for ni in all.size():
		var r: Dictionary = all[ni]
		catches += r["catches"]
		hunted += 1 if r["hunted"] else 0
		charged += 1 if r["charged"] else 0
		check("soak: night %d completed to dawn without errors" % ni, r["ended"])
		check("soak: no NaN positions / creatures inside the map", not r["nan"] and not r["outside"])
		check("soak: Mano grabbed the bot while it stood indoors", r["grabs"] >= 1)
		check("soak: Lechuza perched and whistled", r["lechuza"])
	print("AUTOTEST soak totals: Llorona hunted the bot in %d/3 nights, charged in %d/3, caught it %d times" % [hunted, charged, catches])
	check("soak: Llorona hunts a careless player most nights (%d/3)" % hunted, hunted >= 2)
	check("soak: Llorona catches a player who never hides (%d catches in 3 nights)" % catches, catches >= 1)


func _suite_difficulty() -> void:
	var speeds := {}
	for d in ["easy", "normal", "hard"]:
		await _setup_ai_night("velorio", d)
		_only("llorona")
		var g := game()
		var p := me()
		var ll: Node = g.creatures_root.get_node("Llorona")
		place(p, Vector3(0, 0.1, 90), Vector3(0, 1, 100))
		ll.global_position = Vector3(0, 0, 40)
		ll.state = ll.CHASE
		ll.target_peer = 1
		ll.chase_time = -99.0
		ll.lost_time = -99.0
		await wait(0.5)
		var a: Vector3 = ll.global_position
		await wait(3.0)
		speeds[d] = a.distance_to(ll.global_position) / 3.0
		Net.leave()
		await wait(0.5)
	print("AUTOTEST chase speed m/s: ", speeds)
	check("difficulty changes chase speed (easy < normal < hard)", speeds["easy"] < speeds["normal"] and speeds["normal"] < speeds["hard"])


## Feeds REAL mouse-motion events through the input pipeline (like a player does).
func _mouse_test() -> void:
	await _start("velorio")
	var g := game()
	var p := me()
	print("AUTOTEST mouse mode at start: ", Input.mouse_mode)
	check("mouse is captured when the night starts", Input.mouse_mode == Input.MOUSE_MODE_CAPTURED)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	for phase in ["during card reveal", "normal play", "with a note open"]:
		if phase == "normal play":
			g.hud._reveal_time = 0.01
			await wait(0.2)
		if phase == "with a note open":
			g.hud.show_note("Test", "note")
		var yaw0: float = p.rotation.y
		var pitch0: float = p.head_pitch
		for i in 10:
			var ev := InputEventMouseMotion.new()
			ev.relative = Vector2(20, -8)
			ev.position = get_viewport().get_visible_rect().size * 0.5
			Input.parse_input_event(ev)
			await get_tree().process_frame
		check("mouse look turns the camera (%s) yaw %.2f->%.2f" % [phase, yaw0, p.rotation.y], absf(p.rotation.y - yaw0) > 0.1)
		check("mouse look tilts the camera (%s)" % phase, absf(p.head_pitch - pitch0) > 0.05)
	g.hud.close_note()
	# Esc menu frees the mouse, clicking back in recaptures
	var esc := InputEventAction.new()
	esc.action = "ui_cancel"
	esc.pressed = true
	Input.parse_input_event(esc)
	await wait(0.2)
	check("Esc opens pause and frees the mouse", g.hud.paused and Input.mouse_mode == Input.MOUSE_MODE_VISIBLE)
	g.hud._toggle_pause()
	await wait(0.2)
	check("resume recaptures the mouse", Input.mouse_mode == Input.MOUSE_MODE_CAPTURED)


func _tools_test() -> void:
	Net.start_solo()
	Net.set_lobby_option("mode", "ofrenda")
	Net.set_lobby_option("difficulty", "hard")
	Net.set_lobby_option("card", "luna")
	Net.set_lobby_option("seed", 4242)
	Net.set_lobby_option("lives", 1)
	await wait(0.4)
	await shot("tools_lobby")
	var menu: Node = get_parent().menu
	menu.bestiary_holder.visible = true
	await wait(0.3)
	await shot("tools_bestiary")
	menu.bestiary_holder.visible = false
	Net.start_game()
	await wait(2.0)
	var g := game()
	var p := me()
	check("seed is used", int(g.config["seed"]) == 4242)
	check("forced card dealt", p.cards == ["luna"])
	check("difficulty applied", is_equal_approx(g.diff, 1.25))
	check("lives set", int(g.lives[1]) == 1)
	g.hud._reveal_time = 0.01
	for c in g.creatures_root.get_children():
		c.global_position = Vector3(80, -20, 150)
	await wait(0.3)
	# Map
	g.hud.map_view.visible = true
	await wait(0.3)
	await shot("tools_map")
	g.hud.map_view.visible = false
	# Dev menu
	g.hud._toggle_dev()
	g.hud.dev_menu._reveal()
	await wait(0.3)
	await shot("tools_dev_menu")
	check("dev answer revealed", g.hud.dev_menu.answer_label.text.find(g.mode.profile["name"]) >= 0)
	g.hud._toggle_dev()
	g.dev_teleport(Vector3(0, 0.2, 117))
	await wait(0.3)
	check("dev teleport", p.global_position.distance_to(Vector3(0, 0, 117)) < 1.5)
	g.dev_teleport(Vector3(-2.5, 0.2, 9))
	await wait(0.2)
	var want: String = g.mode.dev_next_item()
	g.dev_bring(want)
	await wait(0.2)
	check("dev bring puts item next to you", g.items[want].global_position.distance_to(p.global_position) < 2.5)
	var t0: float = g.elapsed
	g.dev_skip(g.night_seconds / 12.0)
	check("dev +30min", g.elapsed - t0 > g.night_seconds / 12.0 - 1.0)
	g.dev_set_card("diablito")
	check("dev swap card", p.cards == ["diablito"])
	# Llorona summon
	g.dev_summon("Llorona")
	var ll: Node = g.creatures_root.get_node("Llorona")
	check("dev summon: llorona notices you (then stalks)", (ll.state == ll.NOTICE or ll.state == ll.STALK) and ll.target_peer == p.peer_id and ll.global_position.distance_to(p.global_position) < 14.0)
	ll.global_position = Vector3(80, -20, 150)
	ll.state = ll.RETREAT
	ll.retreat_time = 999.0
	# Self revive with lives
	g.dev_freeze(true)
	g.hud.dev_menu._knock_down()
	await wait(0.2)
	check("solo with a life: downed, not dead", p.state == p.State.DOWNED)
	await wait(0.3)
	await shot("tools_downed_getup")
	g.request_self_revive()
	await wait(0.3)
	check("get back up uses a life", p.state == p.State.ALIVE and int(g.lives[1]) == 0)
	g.save_note("autotest note: llorona felt too fast near the well")
	check("F8 note saved", FileAccess.file_exists(g.NOTES_PATH))
	g.hud.dev_menu._knock_down()
	await wait(0.6)
	check("out of lives in solo: dead", p.state == p.State.DEAD and g.ended)
	await wait(0.4)
	await shot("tools_end_stats")
	check("playtest log written", FileAccess.file_exists(g.LOG_PATH))
	var f := FileAccess.open(g.LOG_PATH, FileAccess.READ)
	var lines := f.get_as_text().strip_edges().split("\n")
	print("AUTOTEST log last row: ", lines[lines.size() - 1])
	check("log row has mode and seed", lines[lines.size() - 1].find("ofrenda,4242,hard") >= 0)
	# Replay same seed
	g.hud._replay_seed(4242)
	await wait(2.0)
	check("replay same seed", game() != null and int(game().config["seed"]) == 4242 and game() != g)


## Video: real mouse look, the map, the dev menu, La Llorona hunting you, getting back up.
func _mouse_turn(dx: float, dy: float, frames: int) -> void:
	for i in frames:
		var ev := InputEventMouseMotion.new()
		ev.relative = Vector2(dx, dy) / float(frames)
		Input.parse_input_event(ev)
		await get_tree().process_frame


func _tour2() -> void:
	Net.start_solo()
	Net.set_lobby_option("mode", "velorio")
	Net.set_lobby_option("card", "corazon")
	Net.set_lobby_option("lives", 1)
	Net.set_lobby_option("seed", 777)
	await wait(0.8)
	Net.start_game()
	await wait(2.5)
	var g := game()
	var p := me()
	g.hud._reveal_time = 0.01
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	var ll: Node = g.creatures_root.get_node("Llorona")
	ll.global_position = Vector3(-50, 0, 120)
	ll.set_physics_process(false)
	g.creatures_root.get_node("Lechuza").set_physics_process(false)
	await wait(0.4)
	# Look around with the mouse
	await _mouse_turn(-260, 0, 40)
	await _mouse_turn(520, -60, 70)
	await _mouse_turn(-260, 60, 40)
	# Map
	g.hud.map_view.visible = true
	await wait(2.2)
	g.hud.map_view.visible = false
	# Dev menu: teleport to the road, summon Llorona
	g.hud._toggle_dev()
	await wait(1.2)
	g.dev_teleport(Vector3(0, 0.2, 55))
	p.rotation.y = 0.0
	p.head_pitch = 0.0
	await wait(0.6)
	g.hud._toggle_dev()
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	ll.set_physics_process(true)
	ll.active = true
	ll.global_position = Vector3(1.5, 0, 40)
	ll.state = ll.STALK
	ll.target_peer = 1
	ll.stalk_time = 0.0
	# Turn around to face her, stare, she charges
	await _mouse_turn(0, 0, 10)
	var t := 0.0
	while t < 9.0 and p.state == p.State.ALIVE:
		var d: Vector3 = ll.global_position + Vector3.UP * 1.5 - (p.global_position + Vector3.UP * 1.6)
		var want := atan2(-d.x, -d.z)
		var diff := wrapf(want - p.rotation.y, -PI, PI)
		var pitch_want := atan2(d.y, Vector2(d.x, d.z).length())
		var ev := InputEventMouseMotion.new()
		ev.relative = Vector2(-diff * 0.25 / (Settings.mouse_sensitivity * 0.01), -(pitch_want - p.head_pitch) * 0.25 / (Settings.mouse_sensitivity * 0.01))
		Input.parse_input_event(ev)
		await get_tree().process_frame
		t += get_process_delta_time()
	await wait(2.5)
	# Get back up (hold E)
	var e := InputEventAction.new()
	e.action = "interact"
	e.pressed = true
	Input.parse_input_event(e)
	var hold_t := 0.0
	while p.state == p.State.DOWNED and hold_t < 12.0:
		await wait(0.1)
		hold_t += 0.1
	print("AUTOTEST got up after holding E for %.1fs, state=%d" % [hold_t, p.state])
	e = InputEventAction.new()
	e.action = "interact"
	e.pressed = false
	Input.parse_input_event(e)
	await _mouse_turn(300, 0, 60)   # back on your feet, look around
	await wait(4.0)


# --- Floor shimmer measurement ------------------------------------------------------------
## Renders a slow strafe+turn across a street and measures temporal flicker on the ground:
## "flicker" = pixels that jump by > 0.12 luminance one frame and jump back the next
## (sparkle / z-fighting / swimming), as a fraction of sampled ground pixels.
##   --autotest=shimmer            (wobble on, default settings)
##   --autotest=shimmer:nowobble
func _shimmer(opt: String) -> void:
	Settings.vertex_wobble = not opt.contains("nowobble")
	if opt.contains("nopost"):
		Settings.pixelation = false
		Settings.dithering = false
	await _setup_ai_night("velorio")
	_only("none")
	var g := game()
	var p := me()
	p.set_physics_process(false)
	var spot: Array = g.map.shimmer_view if "shimmer_view" in g.map else [Vector3(0, 0.1, 20), Vector3(0, 0, 60)]
	var start: Vector3 = spot[0]
	var target: Vector3 = spot[1]
	var side := (target - start).cross(Vector3.UP).normalized()
	place(p, start, target)
	p.head_pitch = deg_to_rad(-14.0)
	await wait(0.6)
	var frames := []
	for i in 24:
		p.global_position = start + side * (0.025 * i)
		p.rotation.y += deg_to_rad(0.25)
		await RenderingServer.frame_post_draw
		frames.append(get_viewport().get_texture().get_image())
	# Night scenes are dark, so a jump counts when it is large RELATIVE to the pixel's brightness
	# (and at least 2 colour levels): a dim floor pixel flashing 0.05 -> 0.12 -> 0.05 is a sparkle.
	var flick := 0
	var change := 0
	var total := 0
	var mean := 0.0
	for i in range(1, frames.size() - 1):
		var a: Image = frames[i - 1]
		var b: Image = frames[i]
		var c: Image = frames[i + 1]
		var w := a.get_width()
		var h := a.get_height()
		for y in range(int(h * 0.5), int(h * 0.85), 3):
			for x in range(int(w * 0.15), int(w * 0.85), 3):
				var la := a.get_pixel(x, y).get_luminance()
				var lb := b.get_pixel(x, y).get_luminance()
				var lc := c.get_pixel(x, y).get_luminance()
				total += 1
				mean += absf(lb - la)
				# a sparkle = up then back down (or down then up) by >= ~2 colour levels
				if absf(lb - la) > 0.06:
					change += 1
					if absf(lc - lb) > 0.06 and signf(lc - lb) != signf(lb - la):
						flick += 1
	var bright := 0.0
	var bn := 0
	for y in range(int(frames[0].get_height() * 0.5), int(frames[0].get_height() * 0.85), 6):
		for x in range(int(frames[0].get_width() * 0.15), int(frames[0].get_width() * 0.85), 6):
			bright += frames[12].get_pixel(x, y).get_luminance()
			bn += 1
	print("AUTOTEST SHIMMER floor_brightness=%.4f" % (bright / bn))
	print("AUTOTEST SHIMMER mean_abs_diff=%.5f" % (mean / maxf(1.0, total)))
	frames[12].save_png(shots.path_join("shimmer_%s.png" % (opt if opt != "" else "wobble")))
	frames[0].save_png(shots.path_join("shimmer_first_%s.png" % opt))
	frames[23].save_png(shots.path_join("shimmer_last_%s.png" % opt))
	print("AUTOTEST SHIMMER pos ", p.global_position, " cam ", p.camera.global_position)
	var fr := float(flick) / maxf(1.0, total)
	var ch := float(change) / maxf(1.0, total)
	print("AUTOTEST SHIMMER flicker=%.4f change=%.4f samples=%d" % [fr, ch, total])
	check("floor flicker under 1.5%% (got %.2f%%)" % (fr * 100.0), fr < 0.015)


# --- Map views (for checking the layout) ---------------------------------------------------------
## Aerial overview + street-level shots of the pueblo.  --autotest=views  (views:lit = brighter, for layout only)
func _views(opt: String) -> void:
	await _setup_ai_night("velorio")
	_only("none")
	var g := game()
	var p := me()
	p.set_physics_process(false)
	if opt == "lit":
		var env: Environment = g.get_node("WorldEnvironment").environment if g.has_node("WorldEnvironment") else null
		for c in g.get_children():
			if c is WorldEnvironment:
				c.environment.ambient_light_energy = 3.0
				c.environment.fog_enabled = false
		env = env
	var cam := Camera3D.new()
	g.add_child(cam)
	var b: AABB = g.map.BOUNDS
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.size = b.size.z * 1.02
	cam.far = 400.0
	cam.global_position = Vector3(b.get_center().x, 120, b.get_center().z)
	cam.rotation_degrees = Vector3(-90, 0, 0)
	cam.current = true
	await wait(0.4)
	await shot("view_00_aerial")
	cam.projection = Camera3D.PROJECTION_PERSPECTIVE
	cam.fov = 60
	cam.global_position = Vector3(30, 45, -30)
	cam.look_at(Vector3(-2, 0, 40))
	await wait(0.3)
	await shot("view_01_oblique")
	cam.current = false
	cam.queue_free()
	p.camera.current = true
	var views := [
		["view_02_casa_from_street", Vector3(0, 0.1, 16), Vector3(-1, 1.4, 4)],
		["view_03_street_north", Vector3(0.5, 0.1, 9), Vector3(0, 1.4, 40)],
		["view_04_tienda", Vector3(2.0, 0.1, 26), Vector3(-4, 1.6, 20)],
		["view_05_crossing_west", Vector3(1, 0.1, 34), Vector3(-30, 1.4, 34)],
		["view_06_plaza", Vector3(5, 0.1, 38.5), Vector3(14.5, 2.0, 47.5)],
		["view_07_capilla", Vector3(11.5, 0.1, 53.5), Vector3(14.5, 3.5, 59)],
		["view_08_west_alley", Vector3(-4.5, 0.1, 16.6), Vector3(-20, 1.4, 16.6)],
		["view_09_back_lane", Vector3(-27.5, 0.1, 20), Vector3(-27.5, 1.4, 45)],
		["view_10_troje_lane", Vector3(17, 0.1, 28), Vector3(20, 1.4, 12)],
		["view_11_camposanto", Vector3(0, 0.1, 66), Vector3(0, 1.6, 80)],
		["view_12_inside_house", g.map.test_spots.get("casa de doña chela", Vector3(7.5, 0.1, 11.8)), Vector3(2, 1.4, 11.8)],
		["view_13_street_south", Vector3(0, 0.1, 50), Vector3(0, 1.4, 10)],
	]
	for v in views:
		place(p, v[1], v[2])
		await wait(0.35)
		await shot(v[0])


## Fast reachability check: a navmesh path from the creek and from the far corral to every test spot.
func _navprobe() -> void:
	await _setup_ai_night()
	_only("none")
	var g := game()
	await wait(1.0)
	var nav_map: RID = g.map.nav.get_navigation_map()
	for label in g.map.test_spots:
		var target: Vector3 = g.map.test_spots[label]
		for start in [Vector3(-29, 0, 20), Vector3(30, 0, 66)]:
			var path := NavigationServer3D.map_get_path(nav_map, start, target, true)
			var end: Vector3 = path[path.size() - 1] if path.size() > 0 else Vector3(INF, 0, INF)
			var gap := Vector2(end.x - target.x, end.z - target.z).length()
			check("path to %s from %v ends %.1fm away" % [label, start, gap], gap < 1.0)


func _navdebug() -> void:
	await _setup_ai_night()
	_only("none")
	var g := game()
	await wait(1.0)
	var nav_map: RID = g.map.nav.get_navigation_map()
	for x in [-2.5, -3.5, -4.5, -5.5, -6.5, -7.5]:
		var q := NavigationServer3D.map_get_closest_point(nav_map, Vector3(x, 0.1, 27.2))
		print("AUTOTEST closest nav to (%.1f, 27.2): %v" % [x, q])
	var space: PhysicsDirectSpaceState3D = g.get_world_3d().direct_space_state
	for x in [-3.0, -3.5, -4.0, -5.0, -6.0, -7.0]:
		var pq := PhysicsShapeQueryParameters3D.new()
		var sh := SphereShape3D.new()
		sh.radius = 0.3
		pq.shape = sh
		pq.transform = Transform3D(Basis(), Vector3(x, 1.0, 27.2))
		var hits: Array = space.intersect_shape(pq, 8)
		var names := []
		for h in hits:
			names.append(str(h.collider.get_path()).get_file() + "@" + str(h.collider.global_position))
		print("AUTOTEST shape at x=%.1f: %s" % [x, str(names)])


## Screenshots of La Llorona's tells as the player sees them.
func _llshots() -> void:
	await _setup_ai_night()
	_only("llorona")
	var g := game()
	var p := me()
	var ll: Node = g.creatures_root.get_node("Llorona")
	place(p, Vector3(0, 0.1, 30), Vector3(0, 1.4, 44))
	ll.global_position = Vector3(0.5, 0, 44)
	ll.state = ll.WANDER
	ll.calm = 99.0
	await wait(1.0)
	await shot("llorona_1_wandering")
	ll.calm = 0.0
	ll.state = ll.NOTICE
	ll.target_peer = 1
	ll.notice_t = 99.0
	await wait(0.8)
	await shot("llorona_2_noticed")
	ll.set_physics_process(false)
	ll.state = ll.STALK
	ll.hide_progress = 0.55
	look(p, Vector3(-8, 1.4, 30))
	await wait(0.4)
	await shot("llorona_3_hiding_bar")
	ll.state = ll.CHASE
	ll.hide_progress = 0.0
	ll.global_position = Vector3(0.3, 0, 36)
	look(p, ll.global_position + Vector3(0, 1.3, 0))
	await wait(0.4)
	await shot("llorona_4_charging")
	ll.state = ll.WANDER
	await wait(0.3)
	await shot("llorona_5_lost_you")


## Every creature warning line, driven by synced creature state (host-run AI), with screenshots.
func _warnings() -> void:
	await _setup_ai_night()
	var g := game()
	var p := me()
	for c in g.creatures_root.get_children():
		c.set_physics_process(false)
		c.global_position = Vector3(80, -20, 150)
	var ll: Node = g.creatures_root.get_node("Llorona")
	var le: Node = g.creatures_root.get_node("Lechuza")
	var mano: Node = g.creatures_root.get_node("Mano")
	ll.state = ll.WANDER
	place(p, Vector3(0, 0.1, 30), Vector3(0, 1.4, 44))
	await wait(0.4)
	check("no warning when nothing is after you (got '%s')" % g.hud.threat_label.text, g.hud.threat_label.text == "")
	le.global_position = Vector3(-3.2, 3.9, 36)
	le.state = le.WHISTLE
	await wait(0.3)
	check("Lechuza whistling nearby -> warning (got '%s')" % g.hud.threat_label.text, g.hud.threat_label.text == "A WHISTLE FROM THE ROOFTOPS")
	await shot("warn_1_whistle")
	le.state = le.DIVE
	le.marked_peer = p.peer_id
	await wait(0.3)
	check("Lechuza diving at you -> warning", g.hud.threat_label.text == "LA LECHUZA IS DIVING AT YOU")
	await shot("warn_2_dive")
	le.state = le.PERCH
	le.marked_peer = 0
	mano.warn_peer = p.peer_id
	place(p, Vector3(-5, 0.1, 2), Vector3(-5, 1.4, -3))
	await wait(0.3)
	check("La Mano about to grab -> warning", g.hud.threat_label.text == "SOMETHING SCRATCHES UNDER THE FLOOR")
	await shot("warn_3_mano")
	ll.active = true
	ll.global_position = Vector3(-1, 0, 8)
	ll.target_peer = p.peer_id
	ll.state = ll.STALK
	await wait(0.3)
	check("La Llorona outranks La Mano", g.hud.threat_label.text == "SHE HAS NOTICED YOU")
	Settings.creature_hints = false
	await wait(0.2)
	check("hints off hides the 'what to do' line but keeps the warning", g.hud.threat_hint.text == "" and g.hud.threat_label.text != "")
	Settings.creature_hints = true
	mano.warn_peer = 0
	ll.state = ll.WANDER
