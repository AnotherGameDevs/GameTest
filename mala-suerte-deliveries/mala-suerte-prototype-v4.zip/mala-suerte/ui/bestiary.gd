extends PanelContainer
## Bestiario / How to play. Creatures, Lotería cards, modes and controls.
## Opened from the main menu, lobby and pause menu.

signal closed

const Style := preload("res://ui/style.gd")
const CardView := preload("res://ui/card_view.gd")
const CardsDB := preload("res://player/cards.gd")

const CREATURES := [
	{
		"name": "LA LLORONA", "color": Color("#c9c4b6"),
		"lore": "A weeping woman in white who wanders by the water at night, looking for her children. Any child will do. Anyone will do.",
		"rule": "You can hear her weeping from wherever she is. If the weeping suddenly sounds FAR AWAY and muffled, she has noticed you — and she's close.",
		"tells": "Weeping turns distant + a whisper = she noticed you. Wet footsteps = she's coming. A scream = she's charging.",
		"counter": "When she notices you: get out of her sight AND keep quiet (crouch or stand still) for 3 seconds — a bar fills while you hide. Walking in the open won't lose her. Don't look at her and don't sprint near her: both make her charge. If she charges, sprint round a corner, then crouch.",
	},
	{
		"name": "LA LECHUZA", "color": Color("#ffcc22"),
		"lore": "A witch who takes the shape of an enormous owl. She perches on rooftops and whistles to make you look.",
		"rule": "When you hear her whistle, DON'T LOOK UP at her. Meet her eyes and she marks you and dives.",
		"tells": "A two-note whistle from above. Yellow eyes on a roof edge. Huge feathers on the ground.",
		"counter": "Keep your eyes on the ground while she whistles. If she marks you, get under a roof — any roof, even the porch — before she arrives.",
	},
	{
		"name": "LA MANO PELUDA", "color": Color("#5a4030"),
		"lore": "A huge hairy hand that lives under the wooden floors and grabs whatever stands still above it.",
		"rule": "Indoors, keep moving. Stand still on the floorboards for a few seconds and it grabs your ankle.",
		"tells": "A scratching sound under the floor (that's your warning). Claw marks gouged into the boards.",
		"counter": "Mash [E] to tear free, or a teammate can hold [E] on you to pull you out. Outside on the dirt it can't reach you.",
	},
]

const MODES := [
	["EL VELORIO", "Keep the 6 candles around the body lit until 6:00 AM. Relighting costs matches — find cerillos around the pueblo.", "You lose if the room stays (almost) dark for 20 seconds, or everyone goes down."],
	["LA PROCESIÓN", "Carry the coffin up the road to the camposanto before dawn. The carrier is slow and can't use a light; friends walking next to the coffin help carry it.", "You lose if dawn catches you on the road."],
	["LA OFRENDA", "Someone is coming home. Read the notes around the pueblo to work out who, then bring the 4 things they loved to the altar in the casa.", "A wrong offering sends La Llorona after whoever placed it. You lose at dawn."],
	["LA LIMPIA", "Only one creature is out. Examine its signs, read the curandera's notebook in the barn, put an egg + the right herb on the altar, then hold [E] to perform the cleansing.", "The wrong herb provokes it. You lose at dawn."],
]

const CONTROLS := [
	["WASD", "Move"], ["Shift", "Sprint (loud)"], ["C", "Crouch (quiet)"], ["F", "Flashlight"], ["E", "Interact · hold for long actions · mash when grabbed"],
	["G", "Drop what you're holding"], ["Tab", "Look at your secret card"], ["M", "Map"], ["Esc", "Pause menu"],
	["F1", "Dev menu (solo / host)"], ["F3", "Debug info"], ["F8", "Write a playtest note"],
]


func _ready() -> void:
	theme = Style.theme()
	custom_minimum_size = Vector2(900, 600)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	add_child(v)
	v.add_child(Style.title("Bestiario", 36, Style.BONE))
	var tabs := TabContainer.new()
	tabs.size_flags_vertical = Control.SIZE_EXPAND_FILL
	tabs.add_theme_color_override("font_selected_color", Style.MARIGOLD)
	tabs.add_theme_color_override("font_unselected_color", Style.DIM)
	v.add_child(tabs)
	tabs.add_child(_creatures_tab())
	tabs.add_child(_cards_tab())
	tabs.add_child(_modes_tab())
	tabs.add_child(_controls_tab())
	var back := Style.button("Close", func(): closed.emit())
	back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(back)


func _scroll(title: String) -> Array:
	var sc := ScrollContainer.new()
	sc.name = title
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 14)
	sc.add_child(box)
	return [sc, box]


func _para(text: String, size := 17, color := Style.BONE) -> Label:
	var l := Style.label(text, size, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD
	l.custom_minimum_size.x = 820
	return l


func _creatures_tab() -> Control:
	var sb := _scroll("Creatures")
	for c in CREATURES:
		var e := VBoxContainer.new()
		e.add_theme_constant_override("separation", 4)
		e.add_child(Style.title(c["name"].capitalize(), 26, c["color"].lerp(Style.BONE, 0.35)))
		e.add_child(_para(c["lore"], 16, Style.DIM))
		e.add_child(_para("RULE — " + c["rule"], 18, Color("#f2d9a6")))
		e.add_child(_para("Signs — " + c["tells"]))
		e.add_child(_para("Survive — " + c["counter"]))
		sb[1].add_child(e)
	return sb[0]


func _cards_tab() -> Control:
	var sb := _scroll("Lotería cards")
	sb[1].add_child(_para("At the start of each night you secretly draw a Lotería card. It's a curse only you have. You can tell your friends… or not.", 16, Style.DIM))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	grid.add_theme_constant_override("v_separation", 14)
	sb[1].add_child(grid)
	for id in CardsDB.ALL:
		var info: Dictionary = CardsDB.info(id)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 12)
		var c := Control.new()
		c.set_script(CardView)
		c.custom_minimum_size = Vector2(72, 108)
		c.configure(info["num"], info["name"], info["color"], id)
		row.add_child(c)
		var t := VBoxContainer.new()
		t.add_child(Style.label(info["name"], 18, Style.MARIGOLD))
		var d := Style.label(info["desc"], 15, Style.BONE)
		d.autowrap_mode = TextServer.AUTOWRAP_WORD
		d.custom_minimum_size.x = 300
		t.add_child(d)
		row.add_child(t)
		grid.add_child(row)
	return sb[0]


func _modes_tab() -> Control:
	var sb := _scroll("Modes")
	for m in MODES:
		var e := VBoxContainer.new()
		e.add_child(Style.title(m[0].capitalize(), 24, Style.BONE))
		e.add_child(_para(m[1]))
		e.add_child(_para(m[2], 15, Style.DIM))
		sb[1].add_child(e)
	sb[1].add_child(_para("Everyone downed = night over. Downed players bleed out after 45 s unless a friend holds [E] on them. 'Get-up lives' (lobby) let you pick yourself up — in solo this is your safety net.", 15, Style.DIM))
	return sb[0]


func _controls_tab() -> Control:
	var sb := _scroll("Controls")
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 30)
	grid.add_theme_constant_override("v_separation", 8)
	sb[1].add_child(grid)
	for c in CONTROLS:
		grid.add_child(Style.label(c[0], 18, Style.MARIGOLD))
		grid.add_child(Style.label(c[1], 18))
	sb[1].add_child(_para("Dead? You become a ghost: WASD to fly, Shift up, C down. Watch your friends.", 15, Style.DIM))
	return sb[0]
