extends Control
## Draws a Lotería-style card: number, a simple painted symbol, and the name.
## Used for the secret modifier cards and the game-mode picker.

signal pressed

var number := 1
var title := "EL GALLO"
var art_color := Color("#8c1c22")
var glyph := ""
var selected := false
var clickable := false
var hover := false


func configure(num: int, card_title: String, color: Color, glyph_id: String) -> void:
	number = num
	title = card_title
	art_color = color
	glyph = glyph_id
	queue_redraw()


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP if clickable else Control.MOUSE_FILTER_IGNORE
	mouse_entered.connect(func(): hover = true; queue_redraw())
	mouse_exited.connect(func(): hover = false; queue_redraw())


func _gui_input(event: InputEvent) -> void:
	if clickable and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		pressed.emit()


func _draw() -> void:
	var r := Rect2(Vector2.ZERO, size)
	var bone := Color("#ebe1c8")
	var ink := Color("#141012")
	var lift := 0.0
	if clickable and (hover or selected):
		lift = 1.0
	if selected:
		for k in 4:   # warm glow around the chosen card
			draw_rect(r.grow(2.0 + k * 3.0), Color(0.82, 0.56, 0.24, 0.16 - k * 0.035), false, 3.0)
		draw_rect(r.grow(1.0), Color("#d08f3c"), false, 2.0)
	var face := bone if (selected or not clickable) else bone.darkened(0.12 if lift > 0 else 0.3)
	draw_rect(r, face)
	var pad := maxf(4.0, size.x * 0.05)
	var inner := r.grow(-pad)
	draw_rect(inner, ink, false, 2.0)
	var title_h := size.y * 0.16
	var art := Rect2(inner.position + Vector2(4, 4), inner.size - Vector2(8, 8 + title_h))
	draw_rect(art, art_color)
	var font := ThemeDB.fallback_font
	var fs := int(size.y * 0.08)
	draw_string(font, art.position + Vector2(6, fs + 2), str(number), HORIZONTAL_ALIGNMENT_LEFT, -1, fs, bone)
	var tfs := int(clampf(size.x * 0.095, 9, 30))
	draw_string(font, Vector2(inner.position.x, inner.end.y - title_h * 0.3), title, HORIZONTAL_ALIGNMENT_CENTER, inner.size.x, tfs, ink)
	_draw_glyph(art)


func _draw_glyph(a: Rect2) -> void:
	var c := a.get_center()
	var s := minf(a.size.x, a.size.y) * 0.32
	var bone := Color("#ebe1c8")
	var ink := Color("#141012")
	match glyph:
		"borracho":
			draw_rect(Rect2(c + Vector2(-s * 0.35, -s * 0.2), Vector2(s * 0.7, s * 1.1)), Color("#3c7a3c"))
			draw_rect(Rect2(c + Vector2(-s * 0.12, -s * 0.7), Vector2(s * 0.24, s * 0.55)), Color("#3c7a3c"))
			draw_rect(Rect2(c + Vector2(-s * 0.35, s * 0.1), Vector2(s * 0.7, s * 0.35)), bone)
		"luna":
			draw_circle(c, s, bone)
			draw_circle(c + Vector2(s * 0.45, -s * 0.2), s * 0.9, art_color)
		"corazon":
			draw_circle(c + Vector2(-s * 0.42, -s * 0.2), s * 0.5, Color("#e23b3b"))
			draw_circle(c + Vector2(s * 0.42, -s * 0.2), s * 0.5, Color("#e23b3b"))
			draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.9, -s * 0.05), c + Vector2(s * 0.9, -s * 0.05), c + Vector2(0, s * 1.0)]), Color("#e23b3b"))
		"diablito":
			draw_circle(c, s * 0.7, Color("#e04a2a"))
			draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.6, -s * 0.4), c + Vector2(-s * 0.3, -s * 0.6), c + Vector2(-s * 0.7, -s * 1.1)]), Color("#e04a2a"))
			draw_colored_polygon(PackedVector2Array([c + Vector2(s * 0.6, -s * 0.4), c + Vector2(s * 0.3, -s * 0.6), c + Vector2(s * 0.7, -s * 1.1)]), Color("#e04a2a"))
			draw_circle(c + Vector2(-s * 0.25, -s * 0.1), s * 0.1, ink)
			draw_circle(c + Vector2(s * 0.25, -s * 0.1), s * 0.1, ink)
			draw_arc(c + Vector2(0, s * 0.15), s * 0.3, 0.2, PI - 0.2, 8, ink, 2.0)
		"muerte":
			draw_circle(c + Vector2(0, -s * 0.15), s * 0.7, bone)
			draw_rect(Rect2(c + Vector2(-s * 0.35, s * 0.35), Vector2(s * 0.7, s * 0.4)), bone)
			draw_circle(c + Vector2(-s * 0.27, -s * 0.15), s * 0.18, ink)
			draw_circle(c + Vector2(s * 0.27, -s * 0.15), s * 0.18, ink)
			draw_colored_polygon(PackedVector2Array([c + Vector2(0, s * 0.05), c + Vector2(-s * 0.08, s * 0.22), c + Vector2(s * 0.08, s * 0.22)]), ink)
		"alacran":
			draw_set_transform(c, 0.0, Vector2(1.0, 0.55))
			draw_circle(Vector2.ZERO, s * 0.55, Color("#2a2010"))
			draw_set_transform(Vector2.ZERO)
			draw_arc(c + Vector2(s * 0.5, -s * 0.3), s * 0.5, -PI * 0.5, PI * 0.6, 10, Color("#2a2010"), s * 0.15)
			draw_line(c + Vector2(-s * 0.5, 0), c + Vector2(-s * 0.95, -s * 0.35), Color("#2a2010"), s * 0.12)
			draw_line(c + Vector2(-s * 0.5, 0.1), c + Vector2(-s * 0.95, s * 0.35), Color("#2a2010"), s * 0.12)
		"campana":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.35, -s * 0.7), c + Vector2(s * 0.35, -s * 0.7), c + Vector2(s * 0.85, s * 0.55), c + Vector2(-s * 0.85, s * 0.55)]), Color("#e8c24a"))
			draw_circle(c + Vector2(0, s * 0.7), s * 0.18, Color("#e8c24a"))
		"sirena":
			for i in 3:
				var y := c.y - s * 0.5 + i * s * 0.5
				var pts := PackedVector2Array()
				for k in 9:
					pts.append(Vector2(c.x - s + k * s * 0.25, y + sin(k * 1.4) * s * 0.15))
				draw_polyline(pts, bone, 3.0)
		"velorio":
			for x in [-0.5, 0.0, 0.5]:
				draw_rect(Rect2(c + Vector2(x * s - s * 0.1, -s * 0.2), Vector2(s * 0.2, s * 0.9)), bone)
				draw_circle(c + Vector2(x * s, -s * 0.38), s * 0.12, Color("#ffb347"))
		"procesion":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-s * 0.35, -s), c + Vector2(s * 0.35, -s), c + Vector2(s * 0.55, -s * 0.4), c + Vector2(s * 0.3, s), c + Vector2(-s * 0.3, s), c + Vector2(-s * 0.55, -s * 0.4)]), Color("#3d2a1b"))
			draw_rect(Rect2(c + Vector2(-s * 0.05, -s * 0.6), Vector2(s * 0.1, s * 0.7)), bone)
			draw_rect(Rect2(c + Vector2(-s * 0.25, -s * 0.45), Vector2(s * 0.5, s * 0.1)), bone)
		"ofrenda":
			for i in 8:
				var ang := i * TAU / 8.0
				draw_circle(c + Vector2(cos(ang), sin(ang)) * s * 0.55, s * 0.32, Color("#f0a020"))
			draw_circle(c, s * 0.35, Color("#c06010"))
		"limpia":
			draw_set_transform(c, 0.0, Vector2(0.75, 1.0))
			draw_circle(Vector2.ZERO, s * 0.75, bone)
			draw_set_transform(Vector2.ZERO)
			for i in 3:
				draw_line(c + Vector2(-s * 0.9 + i * 0.3 * s, s * 0.9), c + Vector2(-s * 0.6 + i * 0.3 * s, s * 0.2), Color("#5a8a3a"), 3.0)
		_:
			draw_circle(c, s * 0.5, bone)
