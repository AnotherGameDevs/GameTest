extends CanvasLayer
## In-game HUD, card reveal, notes, pause menu and end screen.

const Style := preload("res://ui/style.gd")
const CardView := preload("res://ui/card_view.gd")
const CardsDB := preload("res://player/cards.gd")
const SettingsPanel := preload("res://ui/settings_panel.gd")
const PlayerScript := preload("res://player/player.gd")

var game: Node
var root: Control
var objective: Label
var status: Label
var clock: Label
var prompt: Label
var hold_bar: ProgressBar
var stamina_bar: ProgressBar
var battery_bar: ProgressBar
var toasts: VBoxContainer
var state_label: Label
var debug_label: Label
var help_label: Label
var corner_cards: HBoxContainer
var big_cards: Control
var note_panel: PanelContainer
var pause_panel: Control
var end_panel: Control
var settings_panel: Control

var map_view: Control
var dev_menu: Control
var bestiary: Control
var note_input: LineEdit
var note_open := false
var paused := false
var _reveal_time := 0.0
var _help_time := 18.0
var threat_label: Label
var threat_hint: Label
var hide_bar: ProgressBar
var _threat_was := false
var _lost_msg_t := 0.0
var stamina_cap: Label


func setup(game_node: Node) -> void:
	game = game_node
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = Style.theme()
	add_child(root)

	var tl := VBoxContainer.new()
	tl.position = Vector2(24, 18)
	tl.custom_minimum_size.x = 540
	root.add_child(tl)
	tl.add_child(Style.title(game.mode.title().capitalize(), 26, Style.BONE))
	objective = Style.label(game.mode.objective_text(), 15, Color("#b3a994"))
	objective.autowrap_mode = TextServer.AUTOWRAP_WORD
	objective.custom_minimum_size.x = 540
	tl.add_child(objective)
	status = Style.label("", 16, Color("#e6c590"))
	tl.add_child(status)

	clock = Style.title("12:00 AM", 28, Style.BONE)
	Style.place(clock, 1, 0, -260, 16, 236, 40)
	clock.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	root.add_child(clock)
	var dawn := Style.caption("dawn at 6:00 AM")
	Style.place(dawn, 1, 0, -260, 58, 236, 20)
	dawn.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	root.add_child(dawn)

	var cross := ColorRect.new()
	cross.color = Color(0.92, 0.88, 0.8, 0.45)
	cross.size = Vector2(3, 3)
	Style.place(cross, 0.5, 0.5, -1.5, -1.5, 3, 3)
	root.add_child(cross)
	cross.mouse_filter = Control.MOUSE_FILTER_IGNORE

	prompt = Style.label("", 20, Style.BONE)
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	Style.place(prompt, 0.5, 0.5, -300, 28, 600, 30)
	prompt.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.95))
	prompt.add_theme_constant_override("shadow_offset_y", 2)
	prompt.add_theme_constant_override("shadow_outline_size", 6)
	root.add_child(prompt)
	hold_bar = ProgressBar.new()
	hold_bar.show_percentage = false
	Style.place(hold_bar, 0.5, 0.5, -90, 62, 180, 8)
	hold_bar.max_value = 1.0
	root.add_child(hold_bar)

	var bl := VBoxContainer.new()
	Style.place(bl, 0, 1, 24, -96, 0, 0)
	root.add_child(bl)
	stamina_cap = Style.caption("stamina")
	bl.add_child(stamina_cap)
	stamina_bar = _bar(Style.BONE)
	bl.add_child(stamina_bar)
	bl.add_child(Style.caption("flashlight"))
	battery_bar = _bar(Color("#f2d9a6"))
	bl.add_child(battery_bar)

	corner_cards = HBoxContainer.new()
	Style.place(corner_cards, 1, 1, -170, -150, 0, 0)
	corner_cards.add_theme_constant_override("separation", 8)
	root.add_child(corner_cards)
	var tab_hint := Style.label("[Tab] your card", 12, Style.DIM)
	Style.place(tab_hint, 1, 1, -170, -26, 0, 0)
	root.add_child(tab_hint)

	# La Llorona: what she's doing to YOU right now, and what to do about it (above the crosshair, clear of the objective text).
	threat_label = Style.title("", 28, Style.BONE)
	threat_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	Style.place(threat_label, 0.5, 0.5, -380, -196, 760, 32)

	root.add_child(threat_label)
	threat_hint = Style.label("", 16, Style.BONE)
	threat_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	Style.place(threat_hint, 0.5, 0.5, -380, -164, 760, 24)
	threat_hint.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.95))
	threat_hint.add_theme_constant_override("shadow_offset_y", 2)
	threat_hint.add_theme_constant_override("shadow_outline_size", 6)
	root.add_child(threat_hint)
	hide_bar = ProgressBar.new()
	hide_bar.show_percentage = false
	hide_bar.max_value = 1.0
	Style.place(hide_bar, 0.5, 0.5, -110, -124, 220, 8)
	root.add_child(hide_bar)

	toasts = VBoxContainer.new()
	Style.place(toasts, 0.5, 0, -320, 120, 0, 0)
	toasts.custom_minimum_size.x = 640
	toasts.alignment = BoxContainer.ALIGNMENT_BEGIN
	root.add_child(toasts)

	state_label = Style.title("", 32, Color("#c23a32"))
	state_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	Style.place(state_label, 0.5, 0.5, -400, -120, 800, 80)
	state_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	state_label.add_theme_constant_override("outline_size", 0)
	root.add_child(state_label)

	help_label = Style.label("WASD move · Shift sprint · C crouch · F flashlight · E interact · G drop · Tab card · Esc menu", 15, Style.DIM)
	Style.place(help_label, 0.5, 1, -450, -40, 900, 24)
	help_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(help_label)

	debug_label = Style.label("", 13, Color("#8fd18f"))
	_ignore_mouse.call_deferred(root)
	_build_tools.call_deferred()
	Style.place(debug_label, 1, 0, -380, 90, 360, 300)
	root.add_child(debug_label)


func _build_tools() -> void:
	map_view = Control.new()
	map_view.set_script(preload("res://ui/map_view.gd"))
	map_view.game = game
	map_view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	map_view.mouse_filter = Control.MOUSE_FILTER_IGNORE
	map_view.visible = false
	root.add_child(map_view)
	if game.multiplayer.is_server():
		dev_menu = PanelContainer.new()
		dev_menu.set_script(preload("res://ui/dev_menu.gd"))
		dev_menu.setup(game)
		root.add_child(dev_menu)
		Style.place(dev_menu, 1.0, 0.0, -460, 40, 0, 0)
		dev_menu.visible = false
	note_input = LineEdit.new()
	note_input.placeholder_text = "Playtest note (what happened? what felt off?) — Enter to save, Esc to cancel"
	Style.place(note_input, 0.5, 1.0, -360, -110, 720, 40)
	note_input.visible = false
	note_input.text_submitted.connect(_submit_note)
	root.add_child(note_input)


func _submit_note(t: String) -> void:
	game.save_note(t)
	_close_note_input()


func _close_note_input() -> void:
	note_input.visible = false
	note_input.text = ""
	note_input.release_focus()
	if not paused and end_panel == null and not (dev_menu and dev_menu.visible):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _toggle_dev() -> void:
	if dev_menu == null or end_panel:
		return
	dev_menu.visible = not dev_menu.visible
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if dev_menu.visible else Input.MOUSE_MODE_CAPTURED


func _open_bestiary(parent: Control) -> void:
	if bestiary:
		return
	var holder := CenterContainer.new()
	holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bestiary = holder
	var bp := PanelContainer.new()
	bp.set_script(preload("res://ui/bestiary.gd"))
	holder.add_child(bp)
	bp.closed.connect(func():
		bestiary.queue_free()
		bestiary = null)
	parent.add_child(holder)


## HUD widgets must never eat mouse movement (the captured cursor sits at screen center).
func _ignore_mouse(n: Node) -> void:
	if n is Control:
		(n as Control).mouse_filter = Control.MOUSE_FILTER_IGNORE
	for c in n.get_children():
		_ignore_mouse(c)


func _bar(c: Color) -> ProgressBar:
	var b := ProgressBar.new()
	b.show_percentage = false
	b.max_value = 1.0
	b.custom_minimum_size = Vector2(170, 4)
	var fill := StyleBoxFlat.new()
	fill.bg_color = c
	b.add_theme_stylebox_override("fill", fill)
	return b


func _card(id: String, w: float) -> Control:
	var info: Dictionary = CardsDB.info(id)
	var c := Control.new()
	c.set_script(CardView)
	c.custom_minimum_size = Vector2(w, w * 1.5)
	c.configure(info["num"], info["name"], info["color"], id)
	return c


# --- Card reveal ---------------------------------------------------------------------

func reveal_cards(ids: Array) -> void:
	for id in ids:
		corner_cards.add_child(_card(id, 70))
	if ids.is_empty():
		return
	big_cards = ColorRect.new()
	(big_cards as ColorRect).color = Color(0, 0, 0, 0.82)
	big_cards.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	big_cards.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(big_cards)
	var v := VBoxContainer.new()
	v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 14)
	big_cards.add_child(v)
	var head := Style.title("Tu carta" if ids.size() == 1 else "Tus cartas", 34, Style.BONE)
	head.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(head)
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 30)
	v.add_child(h)
	for id in ids:
		var col := VBoxContainer.new()
		col.add_theme_constant_override("separation", 10)
		col.add_child(_card(id, 200))
		var d := Style.label(CardsDB.info(id)["desc"], 18, Style.BONE)
		d.autowrap_mode = TextServer.AUTOWRAP_WORD
		d.custom_minimum_size.x = 260
		d.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		col.add_child(d)
		h.add_child(col)
	var hint := Style.label("Only you can see this. Don't tell the others… or do.   (hold Tab to see it again)", 15, Style.DIM)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(hint)
	_reveal_time = 6.0
	Sfx.play("bell", -8.0, 0.8)


func refresh_corner_cards(ids: Array) -> void:
	for c in corner_cards.get_children():
		c.queue_free()
	for id in ids:
		corner_cards.add_child(_card(id, 70))


# --- Notes / toasts ----------------------------------------------------------------------

func show_note(title: String, body: String) -> void:
	if note_panel:
		note_panel.queue_free()
	# A scrap of old paper, slightly askew, in ink.
	note_panel = PanelContainer.new()
	Style.place(note_panel, 0.5, 0.5, -280, -210, 0, 0)
	note_panel.custom_minimum_size = Vector2(560, 0)
	note_panel.rotation_degrees = -1.2
	var paper := StyleBoxFlat.new()
	paper.bg_color = Color("#cfc3a5")
	paper.border_color = Color("#8c7b5c")
	paper.set_border_width_all(1)
	paper.shadow_color = Color(0, 0, 0, 0.75)
	paper.shadow_size = 22
	paper.set_content_margin_all(30)
	note_panel.add_theme_stylebox_override("panel", paper)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	note_panel.add_child(v)
	var ink := Color("#2a2119")
	var t := Style.title(title, 26, ink)
	t.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0))
	v.add_child(t)
	var b := Style.label(body, 19, ink)
	b.add_theme_font_override("font", Style.serif())
	b.autowrap_mode = TextServer.AUTOWRAP_WORD
	b.custom_minimum_size.x = 500
	v.add_child(b)
	v.add_child(Style.label("[E] or [Esc] to put it down", 13, Color("#6b5d45")))
	root.add_child(note_panel)
	note_open = true


func close_note() -> void:
	if note_panel:
		note_panel.queue_free()
		note_panel = null
	note_open = false


func toast(text: String) -> void:
	var l := Style.label(text, 18, Color("#d6cbb2"))
	l.add_theme_font_override("font", Style.serif())
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_WORD
	l.custom_minimum_size.x = 640
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("shadow_offset_y", 2)
	l.add_theme_constant_override("shadow_outline_size", 5)
	toasts.add_child(l)
	while toasts.get_child_count() > 4:
		toasts.get_child(0).free()
	var tw := l.create_tween()
	tw.tween_interval(4.0)
	tw.tween_property(l, "modulate:a", 0.0, 1.0)
	tw.tween_callback(l.queue_free)


func blocking() -> bool:
	return note_open or paused or end_panel != null or _reveal_time > 0.0 or (note_input != null and note_input.visible)


# --- Per frame ------------------------------------------------------------------------------

func _process(delta: float) -> void:
	if game == null:
		return
	var me: Node = game.local_player()
	clock.text = game.clock_text()
	status.text = game.mode.status_text()
	if _reveal_time > 0.0:
		_reveal_time -= delta
		if _reveal_time <= 0.0 and big_cards:
			big_cards.visible = false
	elif big_cards:
		big_cards.visible = Input.is_action_pressed("show_card") and not paused
	_help_time -= delta
	help_label.modulate.a = clampf(_help_time / 3.0, 0.0, 1.0)

	if me:
		stamina_bar.value = me.stamina
		var sa := 0.15 if me.stamina >= 0.999 else 1.0
		stamina_bar.modulate.a = lerpf(stamina_bar.modulate.a, sa, 3.0 * delta)
		stamina_cap.modulate.a = stamina_bar.modulate.a
		battery_bar.value = me.battery
		var p := ""
		if me.interact_target and not blocking():
			p = me.interact_target.get_prompt(me)
		prompt.text = p
		hold_bar.visible = me.hold_progress > 0.0
		hold_bar.value = me.hold_progress
		match me.state:
			PlayerScript.State.DOWNED:
				var lv: int = int(game.lives.get(me.peer_id, 0))
				if lv > 0:
					state_label.text = "YOU'RE DOWN\nHold [E] to get back up (%d left) · %ds" % [lv, int(maxf(0.0, me.downed_timer))]
				else:
					state_label.text = "YOU'RE DOWN\nA teammate can revive you · %ds" % int(maxf(0.0, me.downed_timer))
			PlayerScript.State.DEAD:
				state_label.text = "YOU DIED\nYou're a ghost now. WASD fly · Shift up · C down"
				state_label.modulate.a = 0.6
			PlayerScript.State.GRABBED:
				state_label.text = "SOMETHING HAS YOUR ANKLE\nMASH [E]!"
			_:
				state_label.text = ""
	_update_threat(me, delta)
	if big_cards and big_cards.visible:
		threat_label.text = ""
		threat_hint.text = ""
		hide_bar.visible = false
	debug_label.visible = Settings.show_debug
	if Settings.show_debug:
		_update_debug(me)


## One warning line above the crosshair: which creature is after YOU right now, and (with "Creature hints" on)
## what to do about it. Most urgent first.
func _update_threat(me: Node, delta: float) -> void:
	var title := ""
	var hint := ""
	var col := Style.BONE
	var bar := -1.0
	var alive: bool = me != null and me.state == PlayerScript.State.ALIVE
	var cr: Node = game.creatures_root
	var ll: Node = cr.get_node_or_null("Llorona") if cr else null
	var le: Node = cr.get_node_or_null("Lechuza") if cr else null
	var mano: Node = cr.get_node_or_null("Mano") if cr else null
	var ll_on_me: bool = alive and ll != null and ll.active and ll.hunting() and ll.target_peer == me.peer_id
	_lost_msg_t = maxf(0.0, _lost_msg_t - delta)
	if ll_on_me:
		_threat_was = true
		bar = ll.hide_progress
		if ll.state == ll.CHASE:
			title = "SHE'S CHARGING"
			col = Style.BLOOD
			hint = "Get around a corner, then crouch [C] out of her sight."
		else:
			title = "SHE HAS NOTICED YOU"
			col = Color("#cfdbe6")
			hint = "Get out of her sight and keep quiet: crouch [C] or stand still. Don't look at her."
	else:
		if _threat_was and alive and ll and ll.state == ll.WANDER:
			_lost_msg_t = 3.0
		_threat_was = false
	if title == "" and alive and le != null and le.state == le.DIVE and le.marked_peer == me.peer_id:
		title = "LA LECHUZA IS DIVING AT YOU"
		col = Style.BLOOD
		hint = "Get under a roof. Any roof, even the porch."
	elif title == "" and alive and mano != null and mano.warn_peer == me.peer_id:
		title = "SOMETHING SCRATCHES UNDER THE FLOOR"
		col = Color("#d9b48a")
		hint = "Keep moving, or get outside onto the dirt."
	elif title == "" and alive and le != null and le.state == le.WHISTLE and le.global_position.distance_to(me.global_position) < 45.0:
		title = "A WHISTLE FROM THE ROOFTOPS"
		col = Color("#e8d27a")
		hint = "Keep your eyes down until it stops."
	elif title == "" and _lost_msg_t > 0.0:
		title = "She lost you."
		col = Color("#9fc79f")
		hint = "The weeping is back. Keep your distance."
	threat_label.text = title
	threat_label.add_theme_color_override("font_color", col)
	threat_hint.text = hint if Settings.creature_hints else ""
	hide_bar.visible = bar > 0.02
	hide_bar.value = maxf(bar, 0.0)
	var a := 1.0 if title != "She lost you." else clampf(_lost_msg_t, 0.0, 1.0)
	# a slow pulse on the urgent ones so they read at a glance without being a wall of text
	if col == Style.BLOOD:
		a *= 0.75 + 0.25 * sin(Time.get_ticks_msec() * 0.012)
	threat_label.modulate.a = a
	threat_hint.modulate.a = minf(a, 0.9)


func _update_debug(me: Node) -> void:
	var lines := ["FPS %d" % Engine.get_frames_per_second(), "t %.0fs / %.0fs" % [game.elapsed, game.night_seconds]]
	lines.append("peer %d %s" % [game.multiplayer.get_unique_id(), "HOST" if game.multiplayer.is_server() else "client"])
	if me:
		lines.append("pos %v" % me.global_position.snapped(Vector3.ONE * 0.1))
		lines.append("noise %.1f  fear %.2f  cards %s" % [me.noise, me.fear, str(me.cards)])
	for c in game.creatures_root.get_children():
		var st = c.get("state")
		lines.append("%s %s state=%s act=%s" % [c.name, c.global_position.snapped(Vector3.ONE), str(st), str(c.active)])
	debug_label.text = "\n".join(lines)


func _unhandled_input(event: InputEvent) -> void:
	if note_input and note_input.visible:
		if event.is_action_pressed("ui_cancel"):
			_close_note_input()
			get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("debug_toggle"):
		Settings.set_value("show_debug", not Settings.show_debug)
		return
	if event.is_action_pressed("map") and not paused:
		map_view.visible = not map_view.visible
		Sfx.play("pickup", -12.0, 0.7)
		return
	if event.is_action_pressed("dev_menu") and not paused:
		_toggle_dev()
		get_viewport().set_input_as_handled()
		return
	if event.is_action_pressed("quick_note") and note_input:
		note_input.visible = true
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		note_input.grab_focus.call_deferred()
		get_viewport().set_input_as_handled()
		return
	if note_open and (event.is_action_pressed("interact") or event.is_action_pressed("ui_cancel")):
		close_note()
		get_viewport().set_input_as_handled()
		return
	if _reveal_time > 0.0 and (event is InputEventKey or event is InputEventMouseButton) and event.is_pressed() and not event.is_echo():
		_reveal_time = 0.01
		get_viewport().set_input_as_handled()
		return
	if end_panel:
		return
	if event.is_action_pressed("ui_cancel"):
		_toggle_pause()
		get_viewport().set_input_as_handled()
	elif event is InputEventMouseButton and event.pressed and not paused:
		if dev_menu and dev_menu.visible:
			dev_menu.visible = false
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


# --- Pause ----------------------------------------------------------------------------------

func _toggle_pause() -> void:
	paused = not paused
	if paused:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		pause_panel = ColorRect.new()
		(pause_panel as ColorRect).color = Color(0.01, 0.01, 0.015, 0.78)
		pause_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		root.add_child(pause_panel)
		var center := CenterContainer.new()
		center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		pause_panel.add_child(center)
		var pc := PanelContainer.new()
		center.add_child(pc)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 10)
		pc.add_child(v)
		v.add_child(Style.title("Pausa", 40, Style.BONE))
		v.add_child(Style.label("(The night doesn't stop in multiplayer.)" if not Net.is_solo else "", 14, Style.DIM))
		v.add_child(Style.button("Resume", _toggle_pause))
		v.add_child(Style.button("Settings", _open_settings))
		v.add_child(Style.button("Bestiario · How to play", func(): _open_bestiary(pause_panel)))
		var leave_text := "End night (host)" if (game.multiplayer.is_server() and not Net.is_solo) else "Leave to menu"
		v.add_child(Style.button(leave_text, _leave))
		v.add_child(Style.label("WASD move · Shift sprint · C crouch\nF flashlight · E interact · G drop\nTab card · F3 debug", 14, Style.DIM))
		if Net.is_solo:
			game.get_tree().paused = true
	else:
		if pause_panel:
			pause_panel.queue_free()
			pause_panel = null
		if settings_panel:
			settings_panel.queue_free()
			settings_panel = null
		bestiary = null
		game.get_tree().paused = false
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func _open_settings() -> void:
	if settings_panel:
		return
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_panel = center
	var sp := PanelContainer.new()
	sp.set_script(SettingsPanel)
	center.add_child(sp)
	sp.closed.connect(func():
		settings_panel.queue_free()
		settings_panel = null)
	pause_panel.add_child(center)


func _leave() -> void:
	game.get_tree().paused = false
	if game.multiplayer.is_server():
		if Net.is_solo:
			Net.back_to_lobby()
		else:
			game.server_end(false, "The host ended the night.")
			_toggle_pause()
	else:
		Net.leave()


# --- End screen ---------------------------------------------------------------------------

func show_end(won: bool, text: String) -> void:
	if paused:
		_toggle_pause()
	close_note()
	if big_cards:
		big_cards.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	end_panel = ColorRect.new()
	(end_panel as ColorRect).color = Color(0.01, 0.005, 0.008, 0.86) if not won else Color(0.02, 0.02, 0.03, 0.8)
	end_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(end_panel)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	end_panel.add_child(center)
	var pc := PanelContainer.new()
	center.add_child(pc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	pc.add_child(v)
	var head := Style.title("Amaneció." if won else "Mala suerte.", 64, Color("#e6c590") if won else Color("#b02a26"))
	v.add_child(head)
	v.add_child(Style.caption("you survived the night" if won else "you did not see the dawn"))
	var body := Style.label(text, 20, Style.BONE)
	body.add_theme_font_override("font", Style.serif())
	body.autowrap_mode = TextServer.AUTOWRAP_WORD
	body.custom_minimum_size.x = 520
	v.add_child(body)
	v.add_child(Style.label("Night lasted until %s.   Seed %s · %s difficulty" % [game.clock_text(), str(game.config.get("seed", 0)), game.config.get("difficulty", "normal")], 15, Style.DIM))
	var st: Dictionary = game.stats
	var sg := GridContainer.new()
	sg.columns = 4
	sg.add_theme_constant_override("h_separation", 18)
	for pair in [["Walked", "%d m" % int(st["distance"])], ["Times downed", str(st["downed"])], ["Grabbed", str(st["grabbed"])],
			["Close calls", str(st["close_calls"])], ["Notes read", str(st["notes"])], ["Items picked up", str(st["pickups"])],
			["Got back up", str(st["self_revives"])], ["Your card", ", ".join(game.local_player().cards) if game.local_player() else "-"]]:
		sg.add_child(Style.label(pair[0], 15, Style.DIM))
		sg.add_child(Style.label(pair[1], 15, Style.BONE))
	v.add_child(sg)
	v.add_child(Style.label("Saved to the playtest log. F8 notes go to playtest_notes.txt.", 13, Style.DIM))
	v.add_child(Style.button("Open playtest log folder", func(): OS.shell_open(ProjectSettings.globalize_path("user://"))))
	if game.multiplayer.is_server():
		v.add_child(Style.button("Play again (new cards)", func(): Net.start_game()))
		var seed_now: int = int(game.config.get("seed", 0))
		v.add_child(Style.button("Replay same seed", _replay_seed.bind(seed_now)))
		v.add_child(Style.button("Back to lobby", func(): Net.back_to_lobby()))
	else:
		v.add_child(Style.label("Waiting for the host…", 16, Style.DIM))
		v.add_child(Style.button("Leave", func(): Net.leave()))


func _replay_seed(seed_value: int) -> void:
	Net.set_lobby_option("seed", seed_value)
	Net.start_game()
	Net.set_lobby_option("seed", 0)
