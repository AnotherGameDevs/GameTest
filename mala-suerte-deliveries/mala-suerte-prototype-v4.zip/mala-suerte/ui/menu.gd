extends Control
## Main menu + lobby. Solo, host, or join by IP, then pick a mode and start.

const Style := preload("res://ui/style.gd")
const CardView := preload("res://ui/card_view.gd")
const SettingsPanel := preload("res://ui/settings_panel.gd")

const MODE_INFO := {
	"velorio": {"num": 1, "title": "EL VELORIO", "color": Color("#3a2a4a"),
		"desc": "Hold the wake until dawn. Keep the candles around the body lit — the wind and something worse keep putting them out. Matches are out in the pueblo."},
	"procesion": {"num": 2, "title": "LA PROCESIÓN", "color": Color("#2a3a2a"),
		"desc": "Carry the coffin up the road to the camposanto before sunrise. Carriers are slow and can't hold a light. Someone has to lead."},
	"ofrenda": {"num": 3, "title": "LA OFRENDA", "color": Color("#6a2a1a"),
		"desc": "Someone is coming home tonight. Work out who from the clues, then bring the four things they loved to the altar. Wrong offerings invite the wrong guest."},
	"limpia": {"num": 4, "title": "LA LIMPIA", "color": Color("#1a3a3a"),
		"desc": "One creature has cursed the rancho. Read its signs, find the egg and the right herb, and perform the cleansing in the barn while it fights back."},
}

var title_screen: Control
var lobby_screen: Control
var settings_holder: Control
var message: Label
var name_edit: LineEdit
var ip_edit: LineEdit
var players_list: VBoxContainer
var mode_cards := {}
var mode_desc: Label
var night_opt: OptionButton
var cards_opt: OptionButton
var diff_opt: OptionButton
var lives_opt: OptionButton
var card_opt: OptionButton
var seed_edit: LineEdit
var creature_checks := {}
var bestiary_holder: Control
var title_label: Label
var post: ColorRect
const NIGHTS := ["short", "normal", "long", "endless"]
const DIFFS := ["easy", "normal", "hard"]
const CARD_CHOICES := ["random", "none", "borracho", "luna", "corazon", "diablito", "muerte", "alacran", "campana", "sirena"]
var start_btn: Button
var wait_label: Label
var ip_label: Label
var _t := 0.0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	theme = Style.theme()
	post = ColorRect.new()
	post.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	post.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var pm := ShaderMaterial.new()
	pm.shader = preload("res://shaders/post.gdshader")
	pm.set_shader_parameter("pixel_size", 3.0)
	pm.set_shader_parameter("fear", 0.35)
	pm.set_shader_parameter("vignette", 0.9)
	post.material = pm
	add_child(post)
	_build_title()
	_build_lobby()
	settings_holder = ColorRect.new()
	(settings_holder as ColorRect).color = Color(0, 0, 0, 0.75)
	settings_holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_holder.visible = false
	add_child(settings_holder)
	var sc := CenterContainer.new()
	sc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_holder.add_child(sc)
	var sp := PanelContainer.new()
	sp.set_script(SettingsPanel)
	sc.add_child(sp)
	sp.closed.connect(func(): settings_holder.visible = false)
	bestiary_holder = ColorRect.new()
	(bestiary_holder as ColorRect).color = Color(0, 0, 0, 0.8)
	bestiary_holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bestiary_holder.visible = false
	add_child(bestiary_holder)
	var bc := CenterContainer.new()
	bc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bestiary_holder.add_child(bc)
	var bp := PanelContainer.new()
	bp.set_script(preload("res://ui/bestiary.gd"))
	bc.add_child(bp)
	bp.closed.connect(func(): bestiary_holder.visible = false)

	Net.players_changed.connect(_refresh_lobby)
	Net.lobby_changed.connect(_refresh_lobby)
	Net.connected.connect(func(): show_lobby())
	Net.connection_failed.connect(func(r): show_title(r))
	Net.disconnected.connect(func(r): show_title(r))
	show_title("")


func _process(delta: float) -> void:
	_t += delta
	queue_redraw()
	if title_label:
		# the title gutters like a candle now and then
		var f := 1.0
		if fmod(_t, 6.7) > 6.35:
			f = 0.55 + 0.45 * randf()
		title_label.modulate.a = f


func _draw() -> void:
	# The 3D pueblo shows through. Darken the left side (where the text is) and the edges.
	var w := size.x
	var h := size.y
	var dark := Color(0.02, 0.018, 0.025, 0.92)
	var clear := Color(0.02, 0.018, 0.025, 0.0)
	var split := 0.58 if lobby_screen and lobby_screen.visible else 0.42
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(w * split, 0), Vector2(w * split, h), Vector2(0, h)]),
		PackedColorArray([dark, clear, clear, dark]))
	if lobby_screen and lobby_screen.visible:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.018, 0.025, 0.55))
	draw_polygon(PackedVector2Array([Vector2(0, h * 0.7), Vector2(w, h * 0.7), Vector2(w, h), Vector2(0, h)]),
		PackedColorArray([clear, clear, dark, dark]))
	# A torn strand of papel picado, drained of colour, stirring in the wind
	var n := int(w / 64.0) + 1
	draw_line(Vector2(0, 10), Vector2(w, 16), Color("#3a332c"), 1.5)
	for i in n:
		if i % 7 == 3:
			continue   # a missing flag
		var x := i * 64.0 + 4.0
		var y0 := 10.0 + 6.0 * (x / w)
		var sway := sin(_t * 0.9 + i * 0.7) * 2.5
		var c := Color("#c9bfa7") if i % 3 != 1 else Color("#1a1716")
		c.a = 0.16 if i % 3 != 1 else 0.5
		var torn := 10.0 if i % 5 == 2 else 0.0
		var pts := PackedVector2Array([Vector2(x, y0), Vector2(x + 52, y0), Vector2(x + 52 + sway, y0 + 50 - torn),
			Vector2(x + 39 + sway, y0 + 44), Vector2(x + 26 + sway, y0 + 52), Vector2(x + 13 + sway, y0 + 44), Vector2(x + sway, y0 + 50)])
		draw_colored_polygon(pts, c)
		draw_circle(Vector2(x + 26 + sway * 0.6, y0 + 24), 6, Color(0.02, 0.018, 0.025, 0.6))


# --- Title -------------------------------------------------------------------------

func _build_title() -> void:
	title_screen = Control.new()
	title_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(title_screen)
	var v := VBoxContainer.new()
	v.position = Vector2(88, 84)
	v.add_theme_constant_override("separation", 4)
	title_screen.add_child(v)
	title_label = Style.title("Mala Suerte", 92, Style.BONE)
	title_label.add_theme_color_override("font_shadow_color", Color(0.45, 0.05, 0.05, 0.55))
	v.add_child(title_label)
	var sub := Style.title("una noche de lotería maldita", 22, Style.DIM)
	v.add_child(sub)
	var sp := Control.new()
	sp.custom_minimum_size.y = 34
	v.add_child(sp)
	v.add_child(Style.caption("your name"))
	name_edit = LineEdit.new()
	name_edit.text = Settings.player_name
	name_edit.max_length = 16
	name_edit.custom_minimum_size = Vector2(300, 38)
	name_edit.text_changed.connect(func(t): Settings.set_value("player_name", t if t.strip_edges() != "" else "Jugador"))
	v.add_child(name_edit)
	var sp2 := Control.new()
	sp2.custom_minimum_size.y = 14
	v.add_child(sp2)
	v.add_child(Style.button("Play solo", _on_solo, 300))
	v.add_child(Style.button("Host a game", _on_host, 300))
	var join_row := HBoxContainer.new()
	join_row.add_theme_constant_override("separation", 8)
	ip_edit = LineEdit.new()
	ip_edit.text = Settings.last_ip
	ip_edit.placeholder_text = "Host IP"
	ip_edit.custom_minimum_size = Vector2(186, 38)
	join_row.add_child(ip_edit)
	join_row.add_child(Style.button("Join", _on_join, 106))
	v.add_child(join_row)
	v.add_child(Style.button("Bestiario · How to play", func(): bestiary_holder.visible = true, 300))
	v.add_child(Style.button("Settings", func(): settings_holder.visible = true, 300))
	v.add_child(Style.button("Quit", func(): get_tree().quit(), 300))
	message = Style.label("", 16, Color("#d06a5a"))
	message.autowrap_mode = TextServer.AUTOWRAP_WORD
	message.custom_minimum_size.x = 420
	v.add_child(message)
	var foot := Style.caption("co-op folklore horror  ·  prototype")
	Style.place(foot, 0, 1, 90, -40, 400, 20)
	title_screen.add_child(foot)

	# Showcase of the deck on the right
	var deck := Control.new()
	Style.place(deck, 1.0, 1.0, -470, -300)
	deck.modulate = Color(0.72, 0.66, 0.62, 0.9)
	deck.scale = Vector2(0.8, 0.8)
	title_screen.add_child(deck)
	var ids := ["muerte", "luna", "corazon", "diablito", "sirena"]
	for i in ids.size():
		var info: Dictionary = preload("res://player/cards.gd").info(ids[i])
		var c := Control.new()
		c.set_script(CardView)
		c.size = Vector2(150, 225)
		c.configure(info["num"], info["name"], info["color"], ids[i])
		c.position = Vector2(i * 82, absf(i - 2) * 18)
		c.rotation = deg_to_rad((i - 2) * 6.0)
		deck.add_child(c)


func show_title(msg: String) -> void:
	title_screen.visible = true
	lobby_screen.visible = false
	message.text = msg
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _on_solo() -> void:
	Net.start_solo()


func _on_host() -> void:
	var err := Net.host()
	if err != OK:
		message.text = "Couldn't host (error %d). Is port %d already in use?" % [err, Net.DEFAULT_PORT]


func _on_join() -> void:
	var ip := ip_edit.text.strip_edges()
	if ip == "":
		message.text = "Type the host's IP address first."
		return
	Settings.set_value("last_ip", ip)
	var err := Net.join(ip)
	if err != OK:
		message.text = "Couldn't start connecting (error %d)." % err
	else:
		message.text = "Connecting to %s…" % ip


# --- Lobby -----------------------------------------------------------------------

func _build_lobby() -> void:
	lobby_screen = Control.new()
	lobby_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(lobby_screen)
	var h := HBoxContainer.new()
	h.position = Vector2(60, 84)
	h.add_theme_constant_override("separation", 40)
	lobby_screen.add_child(h)

	var left := VBoxContainer.new()
	left.custom_minimum_size.x = 300
	left.add_theme_constant_override("separation", 10)
	h.add_child(left)
	left.add_child(Style.title("Lobby", 46, Style.BONE))
	ip_label = Style.label("", 15, Style.DIM)
	ip_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	ip_label.custom_minimum_size.x = 300
	left.add_child(ip_label)
	left.add_child(Style.caption("players"))
	players_list = VBoxContainer.new()
	left.add_child(players_list)
	var opts := GridContainer.new()
	opts.columns = 2
	opts.add_theme_constant_override("h_separation", 12)
	opts.add_theme_constant_override("v_separation", 8)
	left.add_child(opts)
	opts.add_child(Style.label("Night length", 16))
	night_opt = OptionButton.new()
	for t in ["Short (4 min)", "Normal (8 min)", "Long (12 min)", "Endless (practice)"]:
		night_opt.add_item(t)
	night_opt.item_selected.connect(func(i): Net.set_lobby_option("night", NIGHTS[i]))
	opts.add_child(night_opt)
	opts.add_child(Style.label("Cards each", 16))
	cards_opt = OptionButton.new()
	cards_opt.add_item("1 card")
	cards_opt.add_item("2 cards")
	cards_opt.item_selected.connect(func(i): Net.set_lobby_option("cards", i + 1))
	opts.add_child(cards_opt)
	start_btn = Style.button("Start the night  →", func(): Net.start_game(), 300)
	start_btn.add_theme_color_override("font_color", Color("#f0c27a"))
	left.add_child(start_btn)
	wait_label = Style.label("Waiting for the host to start…", 16, Style.DIM)
	left.add_child(wait_label)
	left.add_child(Style.button("Leave", func(): Net.leave(), 300))
	left.add_child(Style.button("Settings", func(): settings_holder.visible = true, 300))
	left.add_child(Style.button("Bestiario · How to play", func(): bestiary_holder.visible = true, 300))

	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 16)
	h.add_child(right)
	right.add_child(Style.title("Choose the night", 26, Style.BONE))
	var cards_row := HBoxContainer.new()
	cards_row.add_theme_constant_override("separation", 18)
	right.add_child(cards_row)
	for id in Net.MODES:
		var info: Dictionary = MODE_INFO[id]
		var c := Control.new()
		c.set_script(CardView)
		c.clickable = true
		c.custom_minimum_size = Vector2(160, 228)
		c.configure(info["num"], info["title"], info["color"], id)
		c.pressed.connect(func():
			if Net.is_host():
				Sfx.play("click", -4.0)
				Net.set_lobby_option("mode", id))
		cards_row.add_child(c)
		mode_cards[id] = c
	mode_desc = Style.label("", 18, Style.BONE)
	mode_desc.autowrap_mode = TextServer.AUTOWRAP_WORD
	mode_desc.custom_minimum_size = Vector2(740, 80)
	right.add_child(mode_desc)
	right.add_child(Style.caption("playtest options"))
	var pg := GridContainer.new()
	pg.columns = 4
	pg.add_theme_constant_override("h_separation", 12)
	pg.add_theme_constant_override("v_separation", 8)
	right.add_child(pg)
	pg.add_child(Style.label("Difficulty", 16))
	diff_opt = OptionButton.new()
	for t in ["Easy", "Normal", "Hard"]:
		diff_opt.add_item(t)
	diff_opt.item_selected.connect(func(i): Net.set_lobby_option("difficulty", DIFFS[i]))
	pg.add_child(diff_opt)
	pg.add_child(Style.label("Get-up lives", 16))
	lives_opt = OptionButton.new()
	for n in 4:
		lives_opt.add_item("%d" % n if n > 0 else "0 (hardcore)")
	lives_opt.item_selected.connect(func(i): Net.set_lobby_option("lives", i))
	pg.add_child(lives_opt)
	pg.add_child(Style.label("Lotería card", 16))
	card_opt = OptionButton.new()
	for id in CARD_CHOICES:
		card_opt.add_item("Random" if id == "random" else ("No card" if id == "none" else preload("res://player/cards.gd").info(id)["name"]))
	card_opt.item_selected.connect(func(i): Net.set_lobby_option("card", CARD_CHOICES[i]))
	pg.add_child(card_opt)
	pg.add_child(Style.label("Seed", 16))
	seed_edit = LineEdit.new()
	seed_edit.placeholder_text = "random"
	seed_edit.custom_minimum_size.x = 140
	seed_edit.text_changed.connect(func(t): Net.set_lobby_option("seed", int(t) if t.is_valid_int() else 0))
	pg.add_child(seed_edit)
	var cr := HBoxContainer.new()
	cr.add_theme_constant_override("separation", 16)
	right.add_child(cr)
	cr.add_child(Style.label("Creatures:", 16))
	for cid in ["llorona", "lechuza", "mano"]:
		var cb := CheckBox.new()
		cb.text = {"llorona": "La Llorona", "lechuza": "La Lechuza", "mano": "La Mano Peluda"}[cid]
		cb.button_pressed = true
		cb.add_theme_color_override("font_color", Style.BONE)
		cb.toggled.connect(func(_on): _creatures_changed())
		cr.add_child(cb)
		creature_checks[cid] = cb
	right.add_child(Style.label("(La Limpia always uses its one cursed creature.)", 13, Style.DIM))


func _creatures_changed() -> void:
	var list := []
	for cid in creature_checks:
		if creature_checks[cid].button_pressed:
			list.append(cid)
	Net.set_lobby_option("creatures", list)


func show_lobby() -> void:
	title_screen.visible = false
	lobby_screen.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_refresh_lobby()


func _refresh_lobby() -> void:
	if lobby_screen == null:
		return
	for c in players_list.get_children():
		c.queue_free()
	var ids: Array = Net.players.keys()
	ids.sort()
	for id in ids:
		var p: Dictionary = Net.players[id]
		var col: Color = preload("res://player/player.gd").PLAYER_COLORS[int(p["color"]) % 5]
		var l := Style.label("●  %s%s%s" % [p["name"], "  (host)" if id == 1 else "", "  (you)" if id == multiplayer.get_unique_id() else ""], 18, col.lightened(0.3))
		players_list.add_child(l)
	var host := Net.is_host()
	start_btn.visible = host
	wait_label.visible = not host
	night_opt.disabled = not host
	cards_opt.disabled = not host
	night_opt.select(NIGHTS.find(Net.lobby.get("night", "normal")))
	for o in [diff_opt, lives_opt, card_opt]:
		o.disabled = not host
	seed_edit.editable = host
	diff_opt.select(DIFFS.find(Net.lobby.get("difficulty", "normal")))
	lives_opt.select(int(Net.lobby.get("lives", 1)))
	card_opt.select(CARD_CHOICES.find(Net.lobby.get("card", "random")))
	var sd: int = int(Net.lobby.get("seed", 0))
	if not seed_edit.has_focus():
		seed_edit.text = str(sd) if sd != 0 else ""
	var cl: Array = Net.lobby.get("creatures", [])
	for cid in creature_checks:
		creature_checks[cid].set_pressed_no_signal(cid in cl)
		creature_checks[cid].disabled = not host
	cards_opt.select(int(Net.lobby.get("cards", 1)) - 1)
	var mode: String = Net.lobby.get("mode", "velorio")
	for id in mode_cards:
		mode_cards[id].selected = id == mode
		mode_cards[id].queue_redraw()
	mode_desc.text = MODE_INFO[mode]["desc"]
	if Net.is_solo:
		ip_label.text = "Solo night. Just you and them."
	elif host:
		var ips := []
		for a in IP.get_local_addresses():
			if a.count(".") == 3 and not a.begins_with("127.") and not a.begins_with("169.254"):
				ips.append(a)
		ip_label.text = "Friends join with your IP: %s  (port %d UDP).\nSame Wi-Fi: use the address above. Over the internet: forward the port or use a LAN tool like Radmin/Tailscale/Hamachi." % [", ".join(ips) if not ips.is_empty() else "?", Net.DEFAULT_PORT]
	else:
		ip_label.text = "Connected."
