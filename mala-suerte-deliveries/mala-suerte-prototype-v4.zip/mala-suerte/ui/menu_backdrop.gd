extends Node3D
## The living background behind the main menu: the pueblo at night, seen from the main street.
## A slow drifting camera, fog, one streetlight that flickers, wind, and now and then a pale figure
## standing far down the road that is gone the next time you look.

const MapScript := preload("res://world/map.gd")
const LloronaScript := preload("res://creatures/llorona.gd")

var cam: Camera3D
var figure: Node3D
var _t := 0.0
var _flicker: OmniLight3D
var _flick_base := 1.0
var _figure_t := 9.0
var _wind: AudioStreamPlayer
var _cry_cd := 14.0


func _ready() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color("#05060a")
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#2c3550")
	env.ambient_light_energy = 0.7
	env.fog_enabled = true
	env.fog_light_color = Color("#0a0d15")
	env.fog_density = 0.045
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var moon := DirectionalLight3D.new()
	moon.light_color = Color("#8da2cf")
	moon.light_energy = 0.3
	moon.rotation_degrees = Vector3(-38, 35, 0)
	add_child(moon)

	var map := Node3D.new()
	map.set_script(MapScript)
	add_child(map)
	map.build()
	for c in map.get_children():
		if c is OmniLight3D and absf(c.position.z - 23.0) < 0.5:
			_flicker = c
			_flick_base = c.light_energy

	figure = LloronaScript.make_visual()
	add_child(figure)
	figure.position = Vector3(0.6, 0, 60)
	figure.visible = false

	cam = Camera3D.new()
	cam.fov = 62
	cam.far = 200
	add_child(cam)
	cam.current = true

	_wind = AudioStreamPlayer.new()
	_wind.stream = Sfx.streams.get("wind")
	_wind.bus = "Ambience"
	_wind.volume_db = -10.0
	add_child(_wind)
	if _wind.stream:
		_wind.play()


func _process(delta: float) -> void:
	_t += delta
	# Slow ping-pong dolly up the street, a little head sway, always looking toward the camposanto
	var u := 0.5 - 0.5 * cos(_t * 0.035)
	var pos := Vector3(lerpf(-0.8, 0.9, u) + sin(_t * 0.21) * 0.15, 1.65 + sin(_t * 0.37) * 0.04, lerpf(11.0, 27.0, u))
	cam.position = pos
	cam.look_at(Vector3(sin(_t * 0.05) * 1.2, 1.9, 70.0))
	# A streetlight that can't decide whether it works
	if _flicker:
		var f := 1.0
		if fmod(_t, 7.3) > 6.2:
			f = 0.15 if randf() < 0.5 else 1.0
		_flicker.light_energy = _flick_base * f
	# The figure at the end of the street: there for a few seconds, then not
	_figure_t -= delta
	if _figure_t <= 0.0:
		figure.visible = not figure.visible
		_figure_t = randf_range(2.5, 4.0) if figure.visible else randf_range(10.0, 18.0)
		if figure.visible:
			figure.position.x = randf_range(-1.5, 1.5)
	# Weeping, far away
	_cry_cd -= delta
	if _cry_cd <= 0.0:
		_cry_cd = randf_range(18.0, 30.0)
		Sfx.play("whisper", -18.0, 0.7, "Ambience")
