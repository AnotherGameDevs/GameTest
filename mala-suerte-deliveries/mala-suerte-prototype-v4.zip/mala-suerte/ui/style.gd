extends RefCounted
## Shared UI look. Horror, not a website: near-black, bone-coloured text, one candle-amber accent,
## old blood for danger. Buttons are quiet text rows that light up like a candle when hovered.
## Titles use a serif system font (Georgia / Times on Windows, DejaVu/Liberation on Linux),
## falling back to Godot's default font if none is installed.

const BG := Color("#07070a")
const PANEL := Color("#0d0c0f")
const BONE := Color("#d9d0bc")
const DIM := Color("#7d7466")
const MARIGOLD := Color("#d08f3c")      # candle amber (kept the old name: used everywhere)
const BLOOD := Color("#9e1f1f")
const LINE := Color("#2c2622")

static var _theme: Theme
static var _serif: Font
static var _serif_bold: Font


static func serif(bold := false) -> Font:
	if bold and _serif_bold:
		return _serif_bold
	if not bold and _serif:
		return _serif
	var f := SystemFont.new()
	f.font_names = PackedStringArray(["Georgia", "Times New Roman", "Liberation Serif", "DejaVu Serif", "FreeSerif", "serif"])
	f.font_weight = 700 if bold else 400
	f.antialiasing = TextServer.FONT_ANTIALIASING_GRAY
	if bold:
		_serif_bold = f
	else:
		_serif = f
	return f


static func theme() -> Theme:
	if _theme:
		return _theme
	var t := Theme.new()
	t.default_font_size = 18
	# Buttons: text rows. Hover = a thin candle-coloured bar on the left and warm text.
	var normal := _flat(Color(0, 0, 0, 0.0), Color(0, 0, 0, 0), 0)
	var hover := _flat(Color(0.82, 0.56, 0.24, 0.07), MARIGOLD, 0, 2)
	var pressed := _flat(Color(0.82, 0.56, 0.24, 0.14), MARIGOLD, 0, 2)
	var disabled := _flat(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 0)
	for st in ["normal", "hover", "pressed", "hover_pressed", "focus", "disabled"]:
		t.set_stylebox(st, "CheckButton", _flat(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 0))
	for cls in ["Button"]:
		t.set_stylebox("normal", cls, normal)
		t.set_stylebox("hover", cls, hover)
		t.set_stylebox("pressed", cls, pressed)
		t.set_stylebox("hover_pressed", cls, pressed)
		t.set_stylebox("disabled", cls, disabled)
		t.set_stylebox("focus", cls, _flat(Color(0, 0, 0, 0), MARIGOLD.darkened(0.3), 0, 1))
		t.set_color("font_color", cls, BONE)
		t.set_color("font_hover_color", cls, Color("#f0c27a"))
		t.set_color("font_pressed_color", cls, MARIGOLD)
		t.set_color("font_hover_pressed_color", cls, MARIGOLD)
		t.set_color("font_focus_color", cls, BONE)
		t.set_color("font_disabled_color", cls, Color("#4a443c"))
	# Dropdowns and fields: a dark well with a hairline underline
	var well := _flat(Color(0, 0, 0, 0.45), LINE, 1)
	well.border_width_top = 0
	well.border_width_left = 0
	well.border_width_right = 0
	var well_hover: StyleBoxFlat = well.duplicate()
	well_hover.border_color = MARIGOLD.darkened(0.2)
	t.set_stylebox("normal", "OptionButton", well)
	t.set_stylebox("hover", "OptionButton", well_hover)
	t.set_stylebox("pressed", "OptionButton", well_hover)
	t.set_stylebox("disabled", "OptionButton", well)
	t.set_stylebox("focus", "OptionButton", well_hover)
	t.set_color("font_color", "OptionButton", BONE)
	t.set_color("font_hover_color", "OptionButton", Color("#f0c27a"))
	t.set_color("font_disabled_color", "OptionButton", DIM)
	t.set_stylebox("normal", "LineEdit", well)
	t.set_stylebox("focus", "LineEdit", well_hover)
	t.set_stylebox("read_only", "LineEdit", well)
	t.set_color("font_color", "LineEdit", BONE)
	t.set_color("font_placeholder_color", "LineEdit", Color("#5a5248"))
	t.set_color("caret_color", "LineEdit", MARIGOLD)
	t.set_color("font_color", "Label", BONE)
	t.set_color("font_color", "CheckBox", BONE)
	t.set_color("font_hover_color", "CheckBox", Color("#f0c27a"))
	t.set_color("font_pressed_color", "CheckBox", BONE)
	t.set_color("font_hover_pressed_color", "CheckBox", Color("#f0c27a"))
	for st in ["normal", "hover", "pressed", "hover_pressed", "focus", "disabled"]:
		t.set_stylebox(st, "CheckBox", _flat(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 0))
	# Popup menus for the dropdowns
	t.set_stylebox("panel", "PopupMenu", _flat(Color("#0b0a0d"), LINE, 1, 0, 8))
	t.set_stylebox("hover", "PopupMenu", _flat(Color(0.82, 0.56, 0.24, 0.12), Color(0, 0, 0, 0), 0))
	t.set_color("font_color", "PopupMenu", BONE)
	t.set_color("font_hover_color", "PopupMenu", Color("#f0c27a"))
	# Panels: a near-black sheet with a hairline border and a soft shadow
	var sheet := _flat(Color(0.035, 0.032, 0.04, 0.94), LINE, 1, 0, 22)
	sheet.shadow_color = Color(0, 0, 0, 0.7)
	sheet.shadow_size = 18
	t.set_stylebox("panel", "PanelContainer", sheet)
	t.set_stylebox("panel", "Panel", sheet)
	# Tabs (bestiario)
	t.set_stylebox("tab_selected", "TabContainer", _flat(Color(0, 0, 0, 0), MARIGOLD, 0, 0, 10, true))
	t.set_stylebox("tab_unselected", "TabContainer", _flat(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 0, 0, 10))
	t.set_stylebox("tab_hovered", "TabContainer", _flat(Color(0, 0, 0, 0), MARIGOLD.darkened(0.4), 0, 0, 10, true))
	t.set_stylebox("panel", "TabContainer", _flat(Color(0, 0, 0, 0.25), LINE, 1, 0, 14))
	# Sliders
	var slider_bg := StyleBoxFlat.new()
	slider_bg.bg_color = Color("#1d1a19")
	slider_bg.content_margin_top = 2
	slider_bg.content_margin_bottom = 2
	t.set_stylebox("slider", "HSlider", slider_bg)
	var fill := StyleBoxFlat.new()
	fill.bg_color = MARIGOLD.darkened(0.35)
	fill.content_margin_top = 2
	fill.content_margin_bottom = 2
	t.set_stylebox("grabber_area", "HSlider", fill)
	t.set_stylebox("grabber_area_highlight", "HSlider", fill)
	# Thin bars (stamina, flashlight, hold, hiding)
	var pb_bg := StyleBoxFlat.new()
	pb_bg.bg_color = Color(0, 0, 0, 0.45)
	var pb_fill := StyleBoxFlat.new()
	pb_fill.bg_color = BONE
	t.set_stylebox("background", "ProgressBar", pb_bg)
	t.set_stylebox("fill", "ProgressBar", pb_fill)
	t.set_font_size("font_size", "ProgressBar", 1)
	# Scrollbars: almost invisible
	var grab := StyleBoxFlat.new()
	grab.bg_color = Color("#3a332c")
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0, 0, 0, 0.2)
	t.set_stylebox("grabber", "VScrollBar", grab)
	t.set_stylebox("grabber_highlight", "VScrollBar", grab)
	t.set_stylebox("grabber_pressed", "VScrollBar", grab)
	t.set_stylebox("scroll", "VScrollBar", track)
	_theme = t
	return t


static func _flat(bg: Color, border: Color, bw := 1, left_bar := 0, margin := 10, bottom_bar := false) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	if left_bar > 0:
		s.set_border_width_all(0)
		s.border_width_left = left_bar
	if bottom_bar:
		s.set_border_width_all(0)
		s.border_width_bottom = 2
	s.content_margin_left = margin + 6
	s.content_margin_right = margin + 6
	s.content_margin_top = margin * 0.55
	s.content_margin_bottom = margin * 0.55
	return s


## Kept for older callers.
static func _box(bg: Color, border: Color, bw := 2, margin := 10) -> StyleBoxFlat:
	return _flat(bg, border, bw, 0, margin)


static func label(text: String, size := 18, color := BONE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


## A serif heading (titles, screen names, end-of-night results).
static func title(text: String, size := 40, color := BONE, bold := false) -> Label:
	var l := label(text, size, color)
	l.add_theme_font_override("font", serif(bold))
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("shadow_offset_x", 0)
	l.add_theme_constant_override("shadow_offset_y", 3)
	l.add_theme_constant_override("shadow_outline_size", 6)
	return l


## A small spaced-out caption ("AUDIO", "PLAYTEST OPTIONS").
static func caption(text: String, color := DIM) -> Label:
	var l := label(text.to_upper(), 12, color)
	var fv := FontVariation.new()
	fv.base_font = ThemeDB.fallback_font
	fv.spacing_glyph = 3
	l.add_theme_font_override("font", fv)
	return l


static func button(text: String, cb: Callable, min_w := 220) -> Button:
	var b := Button.new()
	b.text = text
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = Vector2(min_w, 40)
	b.mouse_entered.connect(func(): if not b.disabled: Sfx.play("click", -22.0, 0.7))
	b.pressed.connect(func(): Sfx.play("click", -4.0))
	b.pressed.connect(cb)
	return b


## Anchor a control to a point of its parent (0..1) and offset it in pixels.
static func place(c: Control, ax: float, ay: float, x: float, y: float, w := 0.0, h := 0.0) -> void:
	c.anchor_left = ax
	c.anchor_right = ax
	c.anchor_top = ay
	c.anchor_bottom = ay
	c.offset_left = x
	c.offset_top = y
	c.offset_right = x + w
	c.offset_bottom = y + h
