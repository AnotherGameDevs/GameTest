extends Node3D
## "El Pueblo" — one greybox map shared by all four modes. Everything is built from code.
## A small, dense rural village: one main street, a cross street, a plaza with a kiosk and
## a chapel, houses wall-to-wall along the streets with patios behind, a troje at the edge,
## the arroyo on the west side and the camposanto at the north end of the street.
## Later: replace these boxes with your own low-poly models (keep the collision).
##
## Layout (top-down, +X east, +Z north):
##   The casa (wake house) sits at the south end of Calle Principal (x = 0), facing up the street.
##   Calle Hidalgo crosses at z ~ 34. Plaza + capilla north-east of the crossing, troje east,
##   arroyo west (x ~ -34), camposanto north (z 74..98).

const Palette := preload("res://world/palette.gd")

const BOUNDS := AABB(Vector3(-46, -2, -28), Vector3(90, 30, 132))
const WALL_H := 3.2          # village houses
const PATIO_H := 2.0         # patio / lot walls: tall enough to break line of sight

var nav: NavigationRegion3D

# Points the game modes and creatures use. Filled in by build().
var spawn_points := []
var interiors := []          # wooden floors: La Mano Peluda's territory (also "a roof over your head")
var water_points := []       # La Llorona wanders between these
var perches := []            # La Lechuza lands on these rooftops
var item_spots := []         # where pickups can appear
var note_spots := []         # tables for readable notes
var sign_spots := []         # floor spots for curse signs (Limpia)
var wander_points := []      # general AI patrol points
var body_pos := Vector3(-3.0, 0.0, -1.0)            # the dead, on the table in the sala
var candle_spots := []
var map_rects := []          # [Rect2 (x, z, w, d), Color, label] for the in-game map
var altar_pos := Vector3(-3.5, 0.0, -4.2)           # ofrenda altar (back wall of the sala)
var barn_altar_pos := Vector3(27.4, 0.0, 13.0)      # limpia altar (east end of the troje)
var coop_pos := Vector3(23.0, 0.0, 3.0)             # chicken coop next to the troje (eggs)
var cemetery_goal := Vector3(0.0, 0.0, 79.0)
var cemetery_goal_radius := 6.0
var procession_route := []   # road points from the casa to the camposanto (procession candles)
var teleports := []          # [label, position] for the dev menu
var test_spots := {}         # named spots used by the automated tests
var shimmer_view := [Vector3(0, 0.1, 13), Vector3(0, 0, 50)]

var _rng := RandomNumberGenerator.new()


func build() -> void:
	_rng.seed = 20261031   # map layout is the same every run; items vary by run seed
	nav = NavigationRegion3D.new()
	nav.name = "Nav"
	add_child(nav)

	_ground()
	_streets()
	_casa()
	_west_block_south()
	_east_block_south()
	_west_block_north()
	_plaza()
	_troje()
	_arroyo()
	_camposanto()
	_fields()
	_street_furniture()
	_bounds()

	spawn_points = [Vector3(-1, 0.1, 10.5), Vector3(1, 0.1, 10.5), Vector3(-2, 0.1, 12), Vector3(2, 0.1, 12), Vector3(0, 0.1, 13.5)]
	wander_points.append_array([Vector3(0, 0, 20), Vector3(0, 0, 45), Vector3(0, 0, 62), Vector3(-15, 0, 34), Vector3(22, 0, 34),
		Vector3(14, 0, 44), Vector3(17, 0, 22), Vector3(-24, 0, 16), Vector3(-24, 0, 50), Vector3(10, 0, -9), Vector3(0, 0, 70),
		Vector3(-12, 0, 0), Vector3(30, 0, 30)])
	for z in range(10, 75, 6):
		procession_route.append(Vector3(0, 0, z))
	teleports = [["Casa", Vector3(-2.5, 0.2, 8.5)], ["Calle", Vector3(0, 0.2, 24)], ["Plaza", Vector3(12, 0.2, 42)],
		["Troje (barn)", Vector3(17, 0.2, 13)], ["Arroyo", Vector3(-28, 0.2, 34)], ["Camposanto", Vector3(0, 0.2, 77)]]
	test_spots.merge({"casa sala": Vector3(-5, 0.1, 2), "casa kitchen": Vector3(5, 0.1, 3), "casa bedroom": Vector3(5, 0.1, -3),
		"street": Vector3(0, 0.1, 24), "crossing": Vector3(0, 0.1, 34), "plaza": Vector3(9, 0.1, 44), "kiosk": Vector3(14.5, 0.1, 44),
		"troje": Vector3(24, 0.1, 13), "coop": coop_pos + Vector3(0, 0.1, 2.6), "well": Vector3(7.5, 0.1, 21.5),
		"west alley": Vector3(-14, 0.1, 16.6), "back lane": Vector3(-25, 0.1, 30), "east lane": Vector3(17, 0.1, 25),
		"creek": Vector3(-29, 0.1, 58), "cemetery": Vector3(-8, 0.1, 88), "cemetery chapel": Vector3(0, 0.1, 91.5),
		"road end": Vector3(0, 0.1, 70), "far south": Vector3(-30, 0.1, -20), "far east": Vector3(38, 0.1, 60)})


func bake_navigation() -> void:
	var nm := NavigationMesh.new()
	nm.agent_radius = 0.45   # her body is 0.35; 0.6 left only ~2 navmesh cells through a doorway
	nm.agent_height = 1.75
	nm.agent_max_climb = 0.25
	nm.cell_size = 0.3
	nm.cell_height = 0.25
	nm.geometry_parsed_geometry_type = NavigationMesh.PARSED_GEOMETRY_STATIC_COLLIDERS
	nm.geometry_source_geometry_mode = NavigationMesh.SOURCE_GEOMETRY_ROOT_NODE_CHILDREN
	nm.filter_baking_aabb = BOUNDS
	nav.navigation_mesh = nm
	nav.bake_navigation_mesh(false)


func is_indoors(p: Vector3) -> bool:
	for a in interiors:
		if a.has_point(Vector3(p.x, a.position.y + 0.5, p.z)):
			return true
	return false


# --- Building blocks ---------------------------------------------------------------

func box(center: Vector3, size: Vector3, mat: Material, collide := true, parent: Node = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	# Big faces are split into ~3 m pieces: PS1 vertex snapping on one huge quad wobbles the
	# whole surface; small pieces keep the wobble local.
	bm.subdivide_width = clampi(int(size.x / 3.0), 0, 64)
	bm.subdivide_height = clampi(int(size.y / 3.0), 0, 16)
	bm.subdivide_depth = clampi(int(size.z / 3.0), 0, 72)
	mi.mesh = bm
	mi.material_override = mat
	if collide:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = size
		cs.shape = sh
		sb.add_child(cs)
		sb.add_child(mi)
		(parent if parent else nav).add_child(sb)
		sb.position = center
		return mi
	(parent if parent else nav).add_child(mi)
	mi.position = center
	return mi


func cyl(center: Vector3, radius: float, height: float, mat: Material, collide := true, top_radius := -1.0, parent: Node = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.bottom_radius = radius
	cm.top_radius = radius if top_radius < 0.0 else top_radius
	cm.height = height
	cm.radial_segments = 8
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = mat
	if collide:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var sh := CylinderShape3D.new()
		sh.radius = maxf(radius, cm.top_radius)
		sh.height = height
		cs.shape = sh
		sb.add_child(cs)
		sb.add_child(mi)
		(parent if parent else nav).add_child(sb)
		sb.position = center
		return mi
	(parent if parent else nav).add_child(mi)
	mi.position = center
	return mi


## A wall along X (side "north"/"south") or Z ("east"/"west") with an optional doorway.
func wall_x(x0: float, x1: float, z: float, h: float, mat: Material, door_at := INF, door_w := 1.8, t := 0.25) -> void:
	if door_at == INF:
		box(Vector3((x0 + x1) * 0.5, h * 0.5, z), Vector3(x1 - x0, h, t), mat)
		return
	var a := door_at - door_w * 0.5
	var b := door_at + door_w * 0.5
	if a > x0:
		box(Vector3((x0 + a) * 0.5, h * 0.5, z), Vector3(a - x0, h, t), mat)
	if x1 > b:
		box(Vector3((b + x1) * 0.5, h * 0.5, z), Vector3(x1 - b, h, t), mat)
	if h > 2.3:
		box(Vector3(door_at, (2.2 + h) * 0.5, z), Vector3(door_w, h - 2.2, t), mat)


func wall_z(z0: float, z1: float, x: float, h: float, mat: Material, door_at := INF, door_w := 1.8, t := 0.25) -> void:
	if door_at == INF:
		box(Vector3(x, h * 0.5, (z0 + z1) * 0.5), Vector3(t, h, z1 - z0), mat)
		return
	var a := door_at - door_w * 0.5
	var b := door_at + door_w * 0.5
	if a > z0:
		box(Vector3(x, h * 0.5, (z0 + a) * 0.5), Vector3(t, h, a - z0), mat)
	if z1 > b:
		box(Vector3(x, h * 0.5, (b + z1) * 0.5), Vector3(t, h, z1 - b), mat)
	if h > 2.3:
		box(Vector3(x, (2.2 + h) * 0.5, door_at), Vector3(t, h - 2.2, door_w), mat)


func label(text: String, pos: Vector3, size := 48, color := Color("#e9dfc7")) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = size
	l.pixel_size = 0.01
	l.modulate = color
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	add_child(l)
	l.position = pos


func slab(x0: float, z0: float, x1: float, z1: float, top: float, thick: float, mat: Material, collide := false) -> MeshInstance3D:
	return box(Vector3((x0 + x1) * 0.5, top - thick * 0.5, (z0 + z1) * 0.5), Vector3(x1 - x0, thick, z1 - z0), mat, collide)


## Painted lettering on a wall (not a floating billboard).
func sign_text(text: String, pos: Vector3, normal: Vector3, size := 40, color := Color("#2a2420"), px := 0.006) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = size
	l.pixel_size = px
	l.modulate = color
	l.outline_size = 0
	l.shaded = true
	l.double_sided = false
	l.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	l.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	add_child(l)
	l.position = pos + normal * 0.03
	l.rotation.y = atan2(normal.x, normal.z)


func lamp(pos: Vector3, energy := 1.1, rng := 10.0) -> void:
	var o := OmniLight3D.new()
	o.light_color = Color("#ffb46b")
	o.light_energy = energy
	o.omni_range = rng
	o.shadow_enabled = false
	add_child(o)
	o.position = pos
	box(pos + Vector3(0, 0.12, 0), Vector3(0.45, 0.12, 0.3), Palette.color(Color("#ffcf8a"), 2.5), false)


# --- Houses ---------------------------------------------------------------------------------
# A house is a Rect2 (x, z, width, depth) plus the side its street door is on.
# Local coordinates for furnishing: u = along the street facade, v = inward from the facade.

const SIDES := {"east": Vector3(1, 0, 0), "west": Vector3(-1, 0, 0), "north": Vector3(0, 0, 1), "south": Vector3(0, 0, -1)}
const OPPOSITE := {"east": "west", "west": "east", "north": "south", "south": "north"}


func _side_wall(r: Rect2, side: String, h: float, mat: Material, door_at := INF, door_w := 1.8, t := 0.25) -> void:
	match side:
		"north": wall_x(r.position.x, r.end.x, r.end.y, h, mat, door_at, door_w, t)
		"south": wall_x(r.position.x, r.end.x, r.position.y, h, mat, door_at, door_w, t)
		"east": wall_z(r.position.y, r.end.y, r.end.x, h, mat, door_at, door_w, t)
		"west": wall_z(r.position.y, r.end.y, r.position.x, h, mat, door_at, door_w, t)


## Facade extent along the wall (u range) for a side.
func _u_range(r: Rect2, side: String) -> Vector2:
	return Vector2(r.position.x, r.end.x) if side == "north" or side == "south" else Vector2(r.position.y, r.end.y)


func _depth(r: Rect2, side: String) -> float:
	return r.size.y if side == "north" or side == "south" else r.size.x


## Local (u, y, v) -> world. v = 0 at the facade, growing inward.
func _local(r: Rect2, side: String, u: float, y: float, v: float) -> Vector3:
	match side:
		"north": return Vector3(u, y, r.end.y - v)
		"south": return Vector3(u, y, r.position.y + v)
		"east": return Vector3(r.end.x - v, y, u)
		_: return Vector3(r.position.x + v, y, u)


func _lsize(side: String, su: float, h: float, sv: float) -> Vector3:
	return Vector3(su, h, sv) if side == "north" or side == "south" else Vector3(sv, h, su)


## Something stuck flat on the OUTSIDE of a facade: centre u, height y, size along wall, height, out = distance off the wall.
func _on_facade(r: Rect2, side: String, u: float, y: float, w: float, h: float, mat: Material, out := 0.02, thick := 0.04) -> void:
	var n: Vector3 = SIDES[side]
	var c := _local(r, side, u, y, 0.0) + n * (0.125 + out + thick * 0.5)
	box(c, _lsize(side, w, h, thick), mat, false)


func _window(r: Rect2, side: String, u: float, lit: bool, boarded := false) -> void:
	var glass := Palette.color(Color("#d9a35a"), 0.7) if lit else Palette.color(Color("#101218"))
	_on_facade(r, side, u, 1.65, 0.95, 1.1, Palette.color(Color("#3a332c")), 0.01, 0.03)      # frame
	_on_facade(r, side, u, 1.65, 0.8, 0.95, glass, 0.03, 0.02)
	var bar := Palette.surface("metal")
	if boarded:
		for k in 3:
			_on_facade(r, side, u, 1.35 + k * 0.32, 1.05, 0.14, Palette.surface("wood"), 0.07, 0.04)
		return
	for k in 4:
		_on_facade(r, side, u - 0.3 + k * 0.2, 1.65, 0.035, 1.0, bar, 0.07, 0.035)
	_on_facade(r, side, u, 1.15, 1.0, 0.05, Palette.surface("concrete"), 0.04, 0.12)          # sill


## A village house: plastered adobe, flat roof with a parapet, painted lower band (guardapolvo),
## barred windows, an open metal door. opts: name, color, door_w, back_door, lit, shop, sign,
## abandoned, tinaco, h.
func house(r: Rect2, side: String, door_at: float, opts := {}) -> void:
	var h: float = opts.get("h", WALL_H)
	var col: Color = opts.get("color", Color("#c9b99a"))
	var hname: String = opts.get("name", "")
	var abandoned: bool = opts.get("abandoned", false)
	var door_w: float = opts.get("door_w", 2.0)
	var wall := Palette.tinted("plaster", col)
	var band := Palette.tinted("plaster", col.darkened(0.42) if not opts.has("band") else opts["band"])
	var n: Vector3 = SIDES[side]
	var ur := _u_range(r, side)
	var depth := _depth(r, side)
	var cu := (ur.x + ur.y) * 0.5
	slab(r.position.x, r.position.y, r.end.x, r.end.y, 0.1, 0.1, Palette.surface("wood"), true)
	interiors.append(AABB(Vector3(r.position.x, 0, r.position.y), Vector3(r.size.x, h, r.size.y)))
	map_rects.append([r, col.darkened(0.15), hname])
	test_spots[hname.to_lower()] = _local(r, side, cu, 0.1, depth * 0.5)
	for s in SIDES.keys():
		var d := INF
		var dw := door_w
		if s == side:
			d = door_at
		elif s == OPPOSITE[side] and opts.get("back_door", false):
			d = cu
			dw = 2.0
		_side_wall(r, s, h, wall, d, dw)
	# Roof + parapet (pretil) + water tank
	var roof := Palette.surface("concrete")
	slab(r.position.x - 0.15, r.position.y - 0.15, r.end.x + 0.15, r.end.y + 0.15, h + 0.2, 0.25, roof, true)
	for s in SIDES.keys():
		var e := _u_range(r, s)
		var mid: Vector3 = _local(r, s, (e.x + e.y) * 0.5, h + 0.42, 0.0) + SIDES[s] * 0.05
		box(mid, _lsize(s, e.y - e.x + 0.3, 0.45, 0.2), wall, false)
	if opts.get("tinaco", false):
		cyl(_local(r, side, ur.x + 1.2, h + 0.85, depth - 1.2), 0.55, 1.1, Palette.color(Color("#1b1c1f")), false)
	perches.append(_local(r, side, cu + 1.0, h + 0.7, 0.0) + n * 0.35)
	# Facade details: lower band, windows, rain spout
	var a := door_at - door_w * 0.5
	var b := door_at + door_w * 0.5
	if a - ur.x > 0.05:
		_on_facade(r, side, (ur.x + a) * 0.5, 0.45, a - ur.x, 0.9, band, 0.005, 0.03)
	if ur.y - b > 0.05:
		_on_facade(r, side, (b + ur.y) * 0.5, 0.45, ur.y - b, 0.9, band, 0.005, 0.03)
	var lit_left: int = opts.get("lit", 0)
	for wu in [ur.x + 1.5, ur.y - 1.5, cu]:
		if absf(wu - door_at) > door_w * 0.5 + 1.0 and (wu == cu or ur.y - ur.x > 6.0):
			_window(r, side, wu, lit_left > 0 and not abandoned, abandoned)
			lit_left -= 1
	_on_facade(r, side, ur.x + 0.6, h + 0.05, 0.12, 0.12, Palette.surface("concrete"), 0.25, 0.5)   # gárgola
	# Door: open metal leaf against the inside wall, frame on the facade
	var frame := Palette.color(Color("#3a2f28"))
	_on_facade(r, side, a - 0.06, 1.1, 0.12, 2.2, frame, 0.0, 0.05)
	_on_facade(r, side, b + 0.06, 1.1, 0.12, 2.2, frame, 0.0, 0.05)
	if not abandoned:
		var leaf_col: Color = opts.get("door_color", Color("#3b4a3f"))
		box(_local(r, side, a + 0.06, 1.05, 0.25 + 0.75), _lsize(side, 0.06, 2.1, 1.5), Palette.color(leaf_col), false)
	# Furniture, kept to the back half so the doorway is always clear
	var far_u := ur.x + 1.0 if door_at > cu else ur.y - 1.0          # side away from the door
	var near_u := ur.y - 1.0 if door_at > cu else ur.x + 1.0
	if opts.get("shop", false):
		_shop_inside(r, side, ur, depth, door_at)
	else:
		var table := _local(r, side, (cu + far_u) * 0.5, 0.45, depth - 1.5)
		box(table, _lsize(side, 1.6, 0.9, 0.9), Palette.surface("wood"))
		for k in [-0.55, 0.55]:
			box(_local(r, side, (cu + far_u) * 0.5 + k, 0.25, depth - 2.3), _lsize(side, 0.4, 0.5, 0.4), Palette.surface("wood_dark"), false)
		box(_local(r, side, near_u, 0.3, depth - 1.2), _lsize(side, 1.0, 0.6, 2.0), Palette.color(Color("#4f4033")))   # bed
		box(_local(r, side, far_u + (0.35 if far_u < cu else -0.35), 0.9, 1.5), _lsize(side, 0.5, 1.8, 1.1), Palette.surface("wood_dark"))  # alacena
		item_spots.append_array([table + Vector3(0, 0.55, 0) + _lsize(side, 0.4, 0, 0), _local(r, side, near_u, 0.7, depth - 1.0),
			_local(r, side, far_u + (0.35 if far_u < cu else -0.35), 1.05, 1.5) + n * 0.0])
		note_spots.append(table + Vector3(0, 0.5, 0) - _lsize(side, 0.45, 0, 0))
	sign_spots.append_array([_local(r, side, cu, 0.12, depth * 0.45), _local(r, side, door_at, 0.12, 1.4)])
	if opts.has("sign"):
		sign_text(opts["sign"], _local(r, side, door_at, 2.75, 0.0) + n * 0.14, n, opts.get("sign_size", 44), opts.get("sign_color", Color("#2b2a35")))


func _shop_inside(r: Rect2, side: String, ur: Vector2, depth: float, door_at: float) -> void:
	var cu := (ur.x + ur.y) * 0.5
	# Counter across the room, gap on the door side; shelves of goods on the back wall
	var counter_u := (ur.x + door_at) * 0.5 - 0.6 if door_at > cu else (door_at + ur.y) * 0.5 + 0.6
	box(_local(r, side, counter_u, 0.5, depth * 0.55), _lsize(side, 3.0, 1.0, 0.7), Palette.surface("wood"))
	for k in 3:
		box(_local(r, side, cu, 0.5 + k * 0.6, depth - 0.35), _lsize(side, ur.y - ur.x - 1.0, 0.06, 0.45), Palette.surface("wood_dark"), false)
		for g in 8:
			var gc: Color = [Color("#b8452f"), Color("#d6b44a"), Color("#3f6e9a"), Color("#e8e2d4"), Color("#5a8a4a")][(g + k) % 5]
			box(_local(r, side, ur.x + 1.0 + g * (ur.y - ur.x - 2.0) / 7.0, 0.68 + k * 0.6, depth - 0.35), _lsize(side, 0.22, 0.3, 0.22), Palette.color(gc), false)
	box(_local(r, side, ur.x + 0.7 if door_at > cu else ur.y - 0.7, 0.75, 1.0), _lsize(side, 0.8, 1.5, 0.8), Palette.color(Color("#a32d26")), true)   # cooler
	item_spots.append_array([_local(r, side, counter_u, 1.1, depth * 0.55), _local(r, side, cu, 1.32, depth - 0.35)])
	note_spots.append(_local(r, side, counter_u + 0.8, 1.05, depth * 0.55))


## Patio clutter behind a house: wash basin, clothesline, firewood or a tree.
func patio_props(c: Vector3, kind: int) -> void:
	match kind % 3:
		0:
			box(c + Vector3(0, 0.45, 0), Vector3(1.4, 0.9, 0.8), Palette.surface("concrete"))     # pila (not one of La Llorona's water spots: walled patios trap her)
		1:
			for dz in [-1.8, 1.8]:
				box(c + Vector3(0, 0.9, dz), Vector3(0.08, 1.8, 0.08), Palette.surface("wood_dark"), false)
			box(c + Vector3(0, 1.75, 0), Vector3(0.02, 0.02, 3.6), Palette.surface("metal"), false)
			for k in 3:
				var cc: Color = [Color("#b0563c"), Color("#d8d2c0"), Color("#4f6a8a")][k]
				box(c + Vector3(0, 1.4, -1.1 + k * 1.0), Vector3(0.02, 0.65, 0.7), Palette.color(cc), false)
		2:
			for k in 5:
				box(c + Vector3(0, 0.15 + k * 0.22, 0), Vector3(1.6, 0.2, 0.6), Palette.surface("wood_dark"))   # leña
	item_spots.append(c + Vector3(-1.2, 0.15, 0.8))


func _tree(p: Vector3, h := -1.0, r := -1.0) -> void:
	if h < 0.0:
		h = _rng.randf_range(2.6, 4.2)
	cyl(p + Vector3(0, h * 0.5, 0), 0.2, h, Palette.surface("wood_dark"), true, 0.13)
	var crown := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = r if r > 0.0 else _rng.randf_range(1.4, 2.2)
	sm.height = sm.radius * 1.2
	sm.radial_segments = 7
	sm.rings = 3
	crown.mesh = sm
	crown.material_override = Palette.surface("leaves")
	nav.add_child(crown)
	crown.position = p + Vector3(0, h + 0.3, 0)
	crown.scale = Vector3(1.3, 0.75, 1.3)


func _nopal(p: Vector3) -> void:
	var mat := Palette.surface("cactus")
	var root := Node3D.new()
	nav.add_child(root)
	root.position = p
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var sh := CylinderShape3D.new()
	sh.radius = 0.6
	sh.height = 2.0
	cs.shape = sh
	cs.position.y = 1.0
	body.add_child(cs)
	root.add_child(body)
	for pd in [[Vector3(0, 0.5, 0), 0.0], [Vector3(0.35, 1.2, 0), 25.0], [Vector3(-0.3, 1.25, 0.1), -30.0], [Vector3(0.1, 1.9, 0), 5.0]]:
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.4
		sm.height = 0.8
		sm.radial_segments = 6
		sm.rings = 3
		mi.mesh = sm
		mi.scale = Vector3(1.0, 1.3, 0.25)
		mi.material_override = mat
		root.add_child(mi)
		mi.position = pd[0]
		mi.rotation_degrees.z = pd[1]
	root.rotation.y = _rng.randf() * TAU


# --- Areas -----------------------------------------------------------------------------------

func _ground() -> void:
	# Visual ground in 16 m tiles (so each tile only picks up the lights near it), one collider underneath.
	var b := BOUNDS
	var mat := Palette.surface("dirt")
	var x := b.position.x
	while x < b.end.x - 0.01:
		var z := b.position.z
		while z < b.end.z - 0.01:
			var w := minf(16.0, b.end.x - x)
			var d := minf(16.0, b.end.z - z)
			box(Vector3(x + w * 0.5, -0.5, z + d * 0.5), Vector3(w, 1.0, d), mat, false)
			z += 16.0
		x += 16.0
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var sh := BoxShape3D.new()
	sh.size = Vector3(b.size.x, 1.0, b.size.z)
	cs.shape = sh
	sb.add_child(cs)
	nav.add_child(sb)
	sb.position = Vector3(b.get_center().x, -0.5, b.get_center().z)


func _streets() -> void:
	var road := Palette.surface("road")
	var walk := Palette.surface("sidewalk")
	# Calle Principal (north-south) and Calle Hidalgo (east-west)
	slab(-2.5, 6.8, 2.5, 66.0, 0.02, 0.04, road)
	slab(-30.0, 31.5, 30.0, 36.5, 0.02, 0.04, road)
	map_rects.append([Rect2(-2.5, 6.8, 5, 59.2), Color("#5c4a35"), ""])
	map_rects.append([Rect2(-30, 31.5, 60, 5), Color("#5c4a35"), ""])
	# Sidewalks (banquetas)
	for x0 in [-3.5, 2.5]:
		slab(x0, 7.2, x0 + 1.0, 30.5, 0.07, 0.1, walk)
		slab(x0, 37.5, x0 + 1.0, 64.0, 0.07, 0.1, walk)
	slab(-20.0, 30.5, -3.5, 31.5, 0.07, 0.1, walk)
	slab(-20.0, 36.5, -3.5, 37.5, 0.07, 0.1, walk)
	slab(3.5, 30.5, 15.5, 31.5, 0.07, 0.1, walk)
	# Dirt road on to the camposanto, the lane to the troje, the path along the arroyo
	slab(-2.0, 66.0, 2.0, 74.5, 0.02, 0.04, road)
	slab(15.5, 2.0, 18.5, 31.5, 0.02, 0.04, road)
	slab(-29.0, -12.0, -26.0, 76.0, 0.02, 0.04, road)
	map_rects.append([Rect2(-2, 66, 4, 8.5), Color("#5c4a35"), ""])
	map_rects.append([Rect2(15.5, 2, 3, 29.5), Color("#5c4a35"), ""])
	map_rects.append([Rect2(-29, -12, 3, 88), Color("#5c4a35"), ""])


func _casa() -> void:
	# The wake house: 14 x 10, door on the north (+Z) side, looking straight up the street.
	var x0 := -7.0
	var x1 := 7.0
	var z0 := -5.0
	var z1 := 5.0
	var h := 3.0
	var adobe := Palette.tinted("plaster", Color("#d8cfbd"))
	var plaster := Palette.surface("plaster")
	box(Vector3(0, 0.05, 0), Vector3(14, 0.1, 10), Palette.surface("wood"))
	interiors.append(AABB(Vector3(x0, 0, z0), Vector3(14, 3, 10)))
	map_rects.append([Rect2(x0, z0, 14, 10), Color("#a8835c"), "CASA"])
	wall_x(x0, x1, z1, h, adobe, -2.5, 1.8)          # front, door into the sala
	wall_x(x0, x1, z0, h, adobe)                     # back
	wall_z(z0, z1, x0, h, adobe)                     # west
	wall_z(z0, z1, x1, h, adobe, -2.5)               # east, back door from the bedroom
	# Interior: sala (west), cocina (north-east), recámara (south-east)
	wall_z(z0, z1, 2.0, h, plaster, 2.0, 2.0)
	wall_x(2.0, x1, 0.0, h, plaster, 4.5, 2.0)
	# Tiled roof with overhang
	box(Vector3(0, h + 0.15, 0), Vector3(15.5, 0.3, 11.5), Palette.surface("roof"))
	perches.append(Vector3(-1.0, h + 0.3, 5.6))   # front edge of the roof, over the porch
	# Porch beam + posts
	box(Vector3(-2.5, h - 0.1, 6.4), Vector3(6, 0.2, 0.2), Palette.surface("wood_dark"), false)
	for px in [-5.0, 0.0]:
		box(Vector3(px, h * 0.5, 6.6), Vector3(0.2, h, 0.2), Palette.surface("wood_dark"))
	box(Vector3(-2.5, h, 6.0), Vector3(6.4, 0.15, 2.4), Palette.surface("roof"), false)
	# Facade: blue lower band, windows, the black mourning bow over the door
	var r := Rect2(x0, z0, 14, 10)
	var band := Palette.tinted("plaster", Color("#3f5f7a"))
	_on_facade(r, "north", -5.25, 0.45, 3.5, 0.9, band, 0.005, 0.03)
	_on_facade(r, "north", 2.6, 0.45, 8.8, 0.9, band, 0.005, 0.03)
	_window(r, "north", 3.0, true)
	_window(r, "north", 5.6, false)
	_on_facade(r, "north", -2.5, 2.45, 0.7, 0.35, Palette.surface("cloth_black"), 0.02, 0.05)
	_on_facade(r, "north", -2.5, 2.15, 0.18, 0.5, Palette.surface("cloth_black"), 0.02, 0.05)

	# Sala: table with the body, chairs around
	box(body_pos + Vector3(0, 0.75, 0), Vector3(2.4, 0.1, 1.0), Palette.surface("wood_dark"))
	for lx in [-1.0, 1.0]:
		for lz in [-0.4, 0.4]:
			box(body_pos + Vector3(lx, 0.35, lz), Vector3(0.1, 0.7, 0.1), Palette.surface("wood_dark"), false)
	for i in 6:
		var a := float(i) / 6.0 * TAU
		candle_spots.append(body_pos + Vector3(cos(a) * 1.8, 0.0, sin(a) * 1.15))
	for cx in [-5.5, -0.5]:
		box(Vector3(cx, 0.45, 2.5), Vector3(0.5, 0.9, 0.5), Palette.surface("wood"))
	# Ofrenda altar: stepped table against the back wall
	box(altar_pos + Vector3(0, 0.4, 0), Vector3(2.6, 0.8, 0.9), Palette.color(Color("#3d1f35")))
	box(altar_pos + Vector3(0, 1.0, -0.2), Vector3(2.2, 0.4, 0.5), Palette.color(Color("#4a2642")))
	box(altar_pos + Vector3(0, 1.35, -0.3), Vector3(1.6, 0.3, 0.3), Palette.color(Color("#552c4c")))
	# Cocina
	box(Vector3(6.4, 0.5, 3.5), Vector3(1.0, 1.0, 2.5), Palette.surface("adobe_dark"))   # stove
	box(Vector3(4.6, 0.45, 4.1), Vector3(1.6, 0.9, 0.9), Palette.surface("wood"))         # table
	# Recámara
	box(Vector3(4.2, 0.3, -3.6), Vector3(2.0, 0.6, 2.4), Palette.color(Color("#5b4a3a")))  # bed
	box(Vector3(6.2, 0.6, -4.5), Vector3(1.2, 1.2, 0.6), Palette.surface("wood_dark"))     # dresser

	item_spots.append_array([Vector3(4.6, 1.0, 4.1), Vector3(6.4, 1.1, 2.6), Vector3(6.2, 1.3, -4.5),
		Vector3(4.2, 0.7, -3.2), Vector3(-5.5, 1.0, 2.5), Vector3(-6.2, 0.2, -4.0)])
	note_spots.append(Vector3(4.2, 0.95, 4.0))
	sign_spots.append_array([Vector3(-5, 0.12, 0), Vector3(5.8, 0.12, -1.5), Vector3(4.5, 0.12, 3.0), Vector3(-1, 0.12, 3.5)])

	# Back patio (walled), with a gate to the fields
	var pw := Palette.tinted("plaster", Color("#b9ae98"))
	wall_x(-7.0, 7.0, -13.0, PATIO_H, pw, 0.0, 1.8)
	wall_z(-13.0, -5.0, -7.0, PATIO_H, pw)
	wall_z(-13.0, -5.0, 7.0, PATIO_H, pw, -9.0, 1.8)
	patio_props(Vector3(-4.0, 0, -9.5), 1)
	patio_props(Vector3(3.5, 0, -10.5), 2)
	_tree(Vector3(-1.0, 0, -10.0), 3.4, 2.0)
	map_rects.append([Rect2(-7, -13, 14, 8), Color("#7b6a52"), ""])


func _west_block_south() -> void:
	house(Rect2(-11.5, 8.0, 8.0, 7.5), "east", 11.8, {"name": "Casa de los Pérez", "color": Color("#c98a6b"), "lit": 1, "tinaco": true, "back_door": true})
	house(Rect2(-10.5, 17.7, 7.0, 6.2), "east", 20.8, {"name": "Tienda", "color": Color("#e2d6b8"), "band": Color("#2f5c8a"), "door_w": 2.2,
		"shop": true, "sign": "ABARROTES LUPITA", "sign_color": Color("#2f5c8a")})
	house(Rect2(-11.5, 23.9, 8.0, 6.6), "east", 27.2, {"name": "Casa de Don Beto", "color": Color("#8fb3a0"), "lit": 0, "back_door": true, "tinaco": true})
	# Tienda awning + bench outside
	box(Vector3(-2.75, 2.45, 20.8), Vector3(1.3, 0.08, 3.6), Palette.color(Color("#2f5c8a")), false)
	box(Vector3(-3.0, 0.25, 23.0), Vector3(0.45, 0.5, 1.6), Palette.surface("wood_dark"))
	# Patio walls behind the houses (x -20 .. -11.5) with gates to the back lane
	var pw := Palette.tinted("plaster", Color("#a99a80"))
	wall_z(8.0, 15.5, -20.0, PATIO_H, pw, 11.8, 2.6)
	wall_z(17.7, 30.5, -20.0, PATIO_H, pw, 27.0, 2.6)
	wall_x(-20.0, -11.5, 8.0, PATIO_H, pw)
	wall_x(-20.0, -11.5, 15.5, PATIO_H, pw)
	wall_x(-20.0, -10.5, 17.7, PATIO_H, pw)
	wall_x(-20.0, -11.5, 23.9, PATIO_H, pw, -16.0, 2.6)
	wall_x(-20.0, -11.5, 30.5, PATIO_H, pw)
	patio_props(Vector3(-15.5, 0, 11.5), 0)
	patio_props(Vector3(-15.5, 0, 20.5), 2)
	patio_props(Vector3(-15.5, 0, 27.5), 1)
	_tree(Vector3(-17.5, 0, 9.8))
	map_rects.append([Rect2(-20, 8, 8.5, 22.5), Color("#7b6a52"), ""])
	# Callejón between the Pérez house and the tienda (open at both ends)
	wander_points.append(Vector3(-12, 0, 16.6))
	sign_spots.append(Vector3(-14.0, 0.04, 16.6))


func _east_block_south() -> void:
	house(Rect2(3.5, 8.0, 8.0, 7.5), "west", 11.8, {"name": "Casa de Doña Chela", "color": Color("#c9a35a"), "lit": 2, "back_door": true})
	house(Rect2(3.5, 22.5, 8.0, 8.0), "west", 26.5, {"name": "Casa vacía", "color": Color("#b3ada0"), "abandoned": true, "back_door": true})
	# Solar with the old well between the two houses: low front wall with a wide gap
	var pw := Palette.tinted("plaster", Color("#a99a80"))
	wall_z(15.5, 22.5, 3.6, 1.1, pw, 19.0, 3.0)
	_well(Vector3(8.5, 0, 19.0))
	_tree(Vector3(13.5, 0, 20.5))
	# Patio walls (x 11.5 .. 15.5) with gates to the lane
	wall_z(8.0, 15.5, 15.5, PATIO_H, pw, 11.8, 2.6)
	wall_z(15.5, 22.5, 15.5, PATIO_H, pw, 19.0, 2.6)
	wall_z(22.5, 30.5, 15.5, PATIO_H, pw, 26.5, 2.6)
	wall_x(11.5, 15.5, 8.0, PATIO_H, pw)
	wall_x(11.5, 15.5, 30.5, PATIO_H, pw)
	patio_props(Vector3(13.5, 0, 11.0), 1)
	patio_props(Vector3(13.5, 0, 27.0), 2)
	map_rects.append([Rect2(11.5, 8, 4, 22.5), Color("#7b6a52"), ""])
	map_rects.append([Rect2(3.5, 15.5, 8, 7), Color("#7b6a52"), "pozo"])


func _well(c: Vector3) -> void:
	cyl(c + Vector3(0, 0.45, 0), 1.1, 0.9, Palette.surface("stone"))
	cyl(c + Vector3(0, 0.92, 0), 0.85, 0.05, Palette.surface("water"), false)
	for sx in [-0.9, 0.9]:
		box(c + Vector3(sx, 1.6, 0), Vector3(0.12, 1.4, 0.12), Palette.surface("wood_dark"), false)
	box(c + Vector3(0, 2.3, 0), Vector3(2.0, 0.12, 0.12), Palette.surface("wood_dark"), false)
	water_points.append(c + Vector3(0, 0, 2))
	item_spots.append(c + Vector3(1.6, 0.1, 0.3))
	sign_spots.append(c + Vector3(-1.8, 0.04, 1.0))


func _west_block_north() -> void:
	house(Rect2(-11.5, 37.5, 8.0, 8.5), "east", 41.8, {"name": "Casa de los Ramírez", "color": Color("#ddd3b8"), "band": Color("#3f5f7a"), "lit": 1, "back_door": true})
	house(Rect2(-11.5, 48.2, 8.0, 7.8), "east", 52.1, {"name": "Casa azul", "color": Color("#7d9fc0"), "lit": 0, "tinaco": true})
	house(Rect2(-10.5, 56.0, 7.0, 7.5), "east", 59.75, {"name": "Taller", "color": Color("#a49a88"), "door_w": 2.6, "sign": "TALLER", "sign_size": 56,
		"door_color": Color("#5a3b2a")})
	var pw := Palette.tinted("plaster", Color("#a99a80"))
	wall_z(37.5, 46.0, -20.0, PATIO_H, pw, 41.8, 2.6)
	wall_z(48.2, 63.5, -20.0, PATIO_H, pw, 55.0, 2.6)
	wall_x(-20.0, -11.5, 37.5, PATIO_H, pw)
	wall_x(-20.0, -11.5, 46.0, PATIO_H, pw)
	wall_x(-20.0, -11.5, 48.2, PATIO_H, pw)
	wall_x(-20.0, -10.5, 63.5, PATIO_H, pw)
	patio_props(Vector3(-15.5, 0, 41.5), 2)
	patio_props(Vector3(-15.5, 0, 52.0), 0)
	patio_props(Vector3(-15.5, 0, 60.0), 1)
	_tree(Vector3(-17.0, 0, 57.5))
	map_rects.append([Rect2(-20, 37.5, 8.5, 26), Color("#7b6a52"), ""])
	wander_points.append(Vector3(-13, 0, 47.1))


func _plaza() -> void:
	# Paved plaza with a kiosk, laurel trees in planters, benches; the capilla on its north side.
	slab(3.5, 37.5, 25.0, 58.0, 0.05, 0.08, Palette.surface("paving"))
	map_rects.append([Rect2(3.5, 37.5, 21.5, 20.5), Color("#8a8070"), "PLAZA"])
	var k := Vector3(14.5, 0, 47.5)
	cyl(k + Vector3(0, 0.11, 0), 3.4, 0.2, Palette.surface("concrete"), false)
	for i in 8:
		var a := float(i) / 8.0 * TAU
		cyl(k + Vector3(cos(a) * 3.0, 1.7, sin(a) * 3.0), 0.09, 3.2, Palette.surface("metal"))
	cyl(k + Vector3(0, 3.55, 0), 3.6, 0.7, Palette.color(Color("#5f6b5a")), false, 0.4)
	perches.append(k + Vector3(0, 4.1, 0))
	item_spots.append(k + Vector3(1.0, 0.3, 0.5))
	sign_spots.append(k + Vector3(-1.5, 0.24, 0))
	for tp in [Vector3(7.5, 0, 41.0), Vector3(21.5, 0, 41.0), Vector3(7.5, 0, 54.0), Vector3(21.5, 0, 54.0)]:
		box(tp + Vector3(0, 0.25, 0), Vector3(2.0, 0.5, 2.0), Palette.surface("concrete"))
		_tree(tp + Vector3(0, 0.5, 0), 3.0, 2.2)
	for bp in [[Vector3(11.0, 0, 40.0), 0.0], [Vector3(18.0, 0, 40.0), 0.0], [Vector3(11.0, 0, 55.5), 0.0], [Vector3(5.2, 0, 47.5), 90.0], [Vector3(23.4, 0, 47.5), 90.0]]:
		var bm := box(bp[0] + Vector3(0, 0.45, 0), Vector3(1.8, 0.1, 0.5) if bp[1] == 0.0 else Vector3(0.5, 0.1, 1.8), Palette.surface("concrete"))
		bm = bm
		item_spots.append(bp[0] + Vector3(0.4, 0.55, 0))
	water_points.append(Vector3(14.5, 0, 52.5))
	# Capilla de San Isidro
	var cap := Rect2(9.0, 59.0, 11.0, 10.0)
	var cw := Palette.tinted("plaster", Color("#e6dccb"))
	box(Vector3(14.5, 0.05, 64.0), Vector3(11.0, 0.1, 10.0), Palette.surface("stone"))
	interiors.append(AABB(Vector3(9, 0, 59), Vector3(11, 5.2, 10)))
	map_rects.append([cap, Color("#cfc5b2"), "CAPILLA"])
	wall_x(9.0, 20.0, 59.0, 5.2, cw, 14.5, 2.2)
	wall_x(9.0, 20.0, 69.0, 5.2, cw)
	wall_z(59.0, 69.0, 9.0, 5.2, cw)
	wall_z(59.0, 69.0, 20.0, 5.2, cw, 64.0, 2.0)
	box(Vector3(14.5, 5.35, 64.0), Vector3(11.4, 0.3, 10.4), Palette.surface("concrete"))
	box(Vector3(14.5, 6.6, 59.0), Vector3(3.0, 2.4, 0.3), cw)                          # espadaña (bell gable)
	cyl(Vector3(14.5, 6.5, 59.0), 0.35, 0.6, Palette.color(Color("#6b5a2e")), false, 0.18)
	box(Vector3(14.5, 8.0, 59.0), Vector3(0.12, 0.8, 0.12), Palette.surface("wood_dark"), false)
	box(Vector3(14.5, 8.15, 59.0), Vector3(0.6, 0.12, 0.12), Palette.surface("wood_dark"), false)
	perches.append(Vector3(14.5, 7.9, 58.7))
	sign_text("SAN ISIDRO", Vector3(14.5, 3.05, 58.85), Vector3(0, 0, -1), 40, Color("#3a3228"), 0.011)
	for row in 4:
		for side in [-1.0, 1.0]:
			box(Vector3(14.5 + side * 2.6, 0.45, 61.5 + row * 1.5), Vector3(3.2, 0.9, 0.45), Palette.surface("wood_dark"))
	box(Vector3(14.5, 0.55, 67.8), Vector3(2.4, 1.1, 0.9), Palette.surface("plaster"))
	note_spots.append(Vector3(13.8, 1.15, 67.8))
	item_spots.append_array([Vector3(15.3, 1.2, 67.8), Vector3(10.0, 0.15, 68.0)])
	sign_spots.append_array([Vector3(14.5, 0.12, 63.0), Vector3(14.5, 0.12, 58.0)])
	test_spots["capilla"] = Vector3(14.5, 0.1, 60.5)
	# Comisaría on the east side of the plaza, and the sacristán's little house beside the capilla
	house(Rect2(25.5, 40.0, 8.0, 9.0), "west", 44.5, {"name": "Comisaría", "color": Color("#e0d8c8"), "band": Color("#7a2f2a"), "lit": 1,
		"sign": "COMISARÍA EJIDAL", "sign_size": 30, "sign_color": Color("#3a2a24")})
	house(Rect2(3.5, 59.0, 5.0, 7.0), "west", 62.5, {"name": "Sacristía", "color": Color("#c8b48e"), "h": 3.0})
	# Corral north-east of the plaza
	var stonewall := Palette.surface("stone")
	wall_x(21.0, 34.0, 52.0, 1.1, stonewall, 27.0, 2.0, 0.45)
	wall_x(21.0, 34.0, 70.0, 1.1, stonewall, INF, 2.0, 0.45)
	wall_z(52.0, 70.0, 34.0, 1.1, stonewall, INF, 2.0, 0.45)
	wall_z(52.0, 70.0, 21.0, 1.1, stonewall, 63.0, 2.0, 0.45)
	map_rects.append([Rect2(21, 52, 13, 18), Color("#5a4a34"), "corral"])
	_tree(Vector3(28.0, 0, 64.0))
	_tree(Vector3(31.0, 0, 56.0))
	item_spots.append(Vector3(25.0, 0.1, 67.0))
	wander_points.append(Vector3(27.0, 0, 60.0))


func _troje() -> void:
	var c := Vector3(24, 0, 13)
	var size := Vector3(10, 4, 8)
	var hw := size.x * 0.5
	var hd := size.z * 0.5
	var wood := Palette.surface("wood_dark")
	box(c + Vector3(0, 0.05, 0), Vector3(size.x, 0.1, size.z), Palette.surface("wood"))
	interiors.append(AABB(c + Vector3(-hw, 0, -hd), Vector3(size.x, size.y, size.z)))
	map_rects.append([Rect2(c.x - hw, c.z - hd, size.x, size.z), Color("#6b4a2e"), "TROJE"])
	wall_x(c.x - hw, c.x + hw, c.z + hd, size.y, wood)
	wall_x(c.x - hw, c.x + hw, c.z - hd, size.y, wood)
	wall_z(c.z - hd, c.z + hd, c.x + hw, size.y, wood)
	wall_z(c.z - hd, c.z + hd, c.x - hw, size.y, wood, c.z, 2.6)
	box(c + Vector3(0, size.y + 0.15, 0), Vector3(size.x + 1, 0.3, size.z + 1), Palette.surface("roof"))
	perches.append(c + Vector3(-hw - 0.3, size.y + 0.3, 2.0))
	# Altar for the limpia
	box(barn_altar_pos + Vector3(0, 0.45, 0), Vector3(1.0, 0.9, 2.0), Palette.color(Color("#4a3a5a")))
	box(barn_altar_pos + Vector3(0.3, 1.3, 0), Vector3(0.1, 0.8, 0.1), Palette.color(Color("#b89a5a")), false)
	box(barn_altar_pos + Vector3(0.3, 1.5, 0), Vector3(0.1, 0.1, 0.5), Palette.color(Color("#b89a5a")), false)
	# Hay bales along the back (north) wall, clear of the door
	for i in 4:
		box(c + Vector3(-3.0 + i * 1.6, 0.45, hd - 0.8), Vector3(1.4, 0.9, 1.0), Palette.color(Color("#a08a4a")))
	note_spots.append(barn_altar_pos + Vector3(0, 0.95, 0.7))
	item_spots.append_array([c + Vector3(-2.5, 1.0, hd - 0.8), c + Vector3(1.5, 0.2, -2.5)])
	sign_spots.append_array([c + Vector3(-1, 0.12, 1), c + Vector3(2, 0.12, -1.5)])
	# Chicken coop (eggs for the limpia)
	for i in 4:
		var a := float(i) / 4.0 * TAU + PI * 0.25
		box(coop_pos + Vector3(cos(a) * 2.2, 0.5, sin(a) * 2.2), Vector3(0.15, 1.0, 0.15), wood, false)
	box(coop_pos + Vector3(0, 0.6, -1.2), Vector3(2, 1.2, 1.2), wood)
	box(coop_pos + Vector3(0, 1.3, -1.2), Vector3(2.3, 0.1, 1.5), Palette.surface("roof"), false)
	map_rects.append([Rect2(coop_pos.x - 2, coop_pos.z - 2, 4, 4), Color("#4a3a2a"), "gallinero"])
	item_spots.append(coop_pos + Vector3(0.8, 0.1, 0.5))
	# Low stone walls around the troje yard
	var stonewall := Palette.surface("stone")
	wall_x(18.5, 33.0, -2.0, 1.1, stonewall, INF, 2.0, 0.45)
	wall_z(-2.0, 22.0, 33.0, 1.1, stonewall, 8.0, 2.0, 0.45)
	_tree(Vector3(30.5, 0, 21.0))
	wander_points.append(Vector3(20.0, 0, 5.0))


func _arroyo() -> void:
	# A shallow creek along the west edge, reeds on both banks, a plank bridge where Calle Hidalgo ends.
	slab(-37.0, -26.0, -31.0, 102.0, 0.03, 0.05, Palette.surface("water"))
	map_rects.append([Rect2(-37, -26, 6, 128), Color("#1f4a5a"), "arroyo"])
	for i in 50:
		var z := -24.0 + i * 2.5 + _rng.randf_range(-0.8, 0.8)
		for side in [-1.0, 1.0]:
			var x: float = -34.0 + side * _rng.randf_range(3.1, 3.9)
			box(Vector3(x, 0.4, z), Vector3(0.08, 0.8 + _rng.randf() * 0.7, 0.08), Palette.surface("leaves"), false)
	for bx in range(-38, -29, 1):
		box(Vector3(bx + 0.5, 0.12, 34.0), Vector3(0.9, 0.08, 2.4), Palette.surface("wood"), false)
	for bz in [32.9, 35.1]:
		box(Vector3(-34.0, 0.6, bz), Vector3(8.0, 0.08, 0.08), Palette.surface("wood_dark"), false)
	for z in [-14.0, 10.0, 34.0, 58.0, 84.0]:
		water_points.append(Vector3(-29.5, 0, z))
		sign_spots.append(Vector3(-29.0, 0.04, z + 2.0))
	item_spots.append_array([Vector3(-29.0, 0.1, 22.0), Vector3(-29.0, 0.1, 66.0)])
	for z in [-6.0, 20.0, 46.0, 70.0, 92.0]:
		_tree(Vector3(-40.5 + _rng.randf_range(-1.5, 1.5), 0, z))
	for z in [5.0, 48.0, 80.0]:
		_tree(Vector3(-24.5, 0, z), 3.6, 2.0)


func _camposanto() -> void:
	var stone := Palette.surface("stone")
	var x0 := -14.0
	var x1 := 14.0
	var z0 := 74.0
	var z1 := 98.0
	map_rects.append([Rect2(x0, z0, x1 - x0, z1 - z0), Color("#3a3a3e"), "CAMPOSANTO"])
	wall_x(x0, x1, z0, 1.6, stone, 0.0, 5.0, 0.5)
	wall_x(x0, x1, z1, 1.6, stone, INF, 1.4, 0.5)
	wall_z(z0, z1, x0, 1.6, stone, INF, 1.4, 0.5)
	wall_z(z0, z1, x1, 1.6, stone, INF, 1.4, 0.5)
	for gx in [-2.8, 2.8]:
		box(Vector3(gx, 1.6, z0), Vector3(0.6, 3.2, 0.6), stone)
	box(Vector3(0, 3.3, z0), Vector3(6.2, 0.4, 0.6), stone, false)
	sign_text("PANTEÓN", Vector3(0, 3.3, z0 - 0.3), Vector3(0, 0, -1), 40, Color("#d8d0bc"), 0.011)
	for i in 30:
		var gx := _rng.randf_range(-12, 12)
		var gz := _rng.randf_range(80, 91)
		if absf(gx) < 2.5:
			continue
		if _rng.randf() > 0.5:
			box(Vector3(gx, 0.5, gz), Vector3(0.12, 1.0, 0.12), Palette.color(Color("#e8e2d4")), false)
			box(Vector3(gx, 0.75, gz), Vector3(0.6, 0.12, 0.12), Palette.color(Color("#e8e2d4")), false)
		else:
			box(Vector3(gx, 0.4, gz), Vector3(0.7, 0.8, 0.2), stone)
		box(Vector3(gx, 0.08, gz - 0.9), Vector3(0.8, 0.16, 1.6), Palette.surface("dirt"), false)
	for cz in [78.0, 86.0, 94.0]:
		for cx in [-12.5, 12.5]:
			cyl(Vector3(cx, 2.4, cz), 0.6, 4.8, Palette.surface("leaves"), true, 0.15)   # cypress
	box(Vector3(0, 2, 95.5), Vector3(5, 4, 4), Palette.surface("plaster"))
	box(Vector3(0, 4.6, 95.5), Vector3(0.2, 1.2, 0.2), Palette.surface("wood_dark"), false)
	box(Vector3(0, 4.8, 95.5), Vector3(0.8, 0.2, 0.2), Palette.surface("wood_dark"), false)
	perches.append(Vector3(0, 4.2, 93.3))
	water_points.append(Vector3(-10, 0, 86))
	item_spots.append_array([Vector3(-10, 0.1, 84), Vector3(10, 0.1, 90), Vector3(4, 0.1, 92.5)])
	sign_spots.append_array([Vector3(-7, 0.04, 78), Vector3(8, 0.04, 87)])
	var lantern := OmniLight3D.new()
	lantern.light_color = Color("#ff9a3c")
	lantern.light_energy = 2.0
	lantern.omni_range = 9.0
	add_child(lantern)
	lantern.position = Vector3(0, 2.5, z0 + 1.5)
	box(Vector3(0, 2.6, z0 + 0.6), Vector3(0.3, 0.4, 0.3), Palette.color(Color("#ffb04a"), 3.0), false)


func _fields() -> void:
	# Milpa south of the casa, stone field walls (albarradas) east and west, a few nopales and mesquites.
	var field := Palette.surface("field")
	slab(-24.0, -26.0, 20.0, -15.0, 0.03, 0.05, field)
	map_rects.append([Rect2(-24, -26, 44, 11), Color("#4a3e28"), "milpa"])
	for row in 6:
		for k in 20:
			var x := -22.0 + k * 2.1 + _rng.randf_range(-0.3, 0.3)
			box(Vector3(x, 0.8, -24.5 + row * 1.7), Vector3(0.1, 1.6 + _rng.randf() * 0.5, 0.1), Palette.color(Color("#5a5a2e")), false)
	var stonewall := Palette.surface("stone")
	wall_x(-24.0, 20.0, -14.0, 1.0, stonewall, 0.0, 2.0, 0.45)
	slab(35.0, -10.0, 43.0, 44.0, 0.03, 0.05, field)
	wall_z(-12.0, 46.0, 34.5, 1.0, stonewall, 30.0, 2.0, 0.45)
	for i in 26:
		var p := Vector3(_rng.randf_range(-44, 42), 0, _rng.randf_range(-26, 102))
		var ok := (p.x < -38.5 or p.x > 36.0 or p.z < -15.0 or p.z > 99.0 or (p.z > 70.0 and absf(p.x) > 16.0))
		if not ok:
			continue
		if _rng.randf() < 0.55:
			_nopal(p)
		else:
			_tree(p)


func _street_furniture() -> void:
	# Utility poles + wires on the east sidewalk, streetlights, a parked pickup, a car, oil-drum bins.
	var pole := Palette.surface("wood_dark")
	var zs := [9.5, 23.0, 38.0, 52.0, 64.5]
	for z in zs:
		box(Vector3(3.2, 3.5, z), Vector3(0.22, 7.0, 0.22), pole)
		box(Vector3(3.2, 6.6, z), Vector3(0.12, 0.12, 1.4), pole, false)
	for i in zs.size() - 1:
		var za: float = zs[i]
		var zb: float = zs[i + 1]
		for dz in [-0.6, 0.6]:
			box(Vector3(3.2, 6.6, (za + zb) * 0.5 + dz * 0.0), Vector3(0.025, 0.025, zb - za), Palette.surface("metal"), false)
	for z in zs:
		box(Vector3(2.5, 5.3, z), Vector3(1.4, 0.08, 0.08), pole, false)
	lamp(Vector3(1.8, 5.1, 9.5))
	lamp(Vector3(1.8, 5.1, 23.0))
	lamp(Vector3(1.8, 5.1, 38.0))
	lamp(Vector3(1.8, 5.1, 52.0))
	lamp(Vector3(1.8, 5.1, 64.5))
	lamp(Vector3(8.0, 3.2, 41.0), 0.8, 8.0)
	lamp(Vector3(21.0, 3.2, 54.5), 0.8, 8.0)
	for lp in [Vector3(8.0, 0, 41.0), Vector3(21.0, 0, 54.5)]:
		box(lp + Vector3(0.4, 1.55, 0), Vector3(0.12, 3.1, 0.12), Palette.surface("metal"), false)
	# Old pickup parked on the west side of the street, a car near the tienda
	_vehicle(Vector3(-1.4, 0, 45.0), Color("#6b7a5a"), true)
	_vehicle(Vector3(1.5, 0, 18.5), Color("#8a3a30"), false)
	for bp in [Vector3(-3.0, 0, 30.0), Vector3(3.0, 0, 30.2), Vector3(-3.0, 0, 63.0)]:
		cyl(bp + Vector3(0, 0.45, 0), 0.3, 0.9, Palette.color(Color("#3a4a3e")))
	# Bougainvillea over a few walls
	for bg in [Vector3(-11.8, 2.3, 9.5), Vector3(11.8, 2.2, 14.0), Vector3(-11.8, 2.2, 40.0)]:
		box(bg, Vector3(0.5, 1.2, 1.8), Palette.color(Color("#9a2f6a")), false)


func _vehicle(p: Vector3, col: Color, pickup: bool) -> void:
	var body := Palette.color(col)
	box(p + Vector3(0, 0.75, 0), Vector3(1.8, 0.7, 4.6), body)
	box(p + Vector3(0, 1.4, 0.6 if pickup else 0.0), Vector3(1.7, 0.6, 1.6 if pickup else 2.4), body)
	box(p + Vector3(0, 1.42, (0.6 if pickup else 0.0) + (0.81 if pickup else 1.21)), Vector3(1.5, 0.45, 0.02), Palette.color(Color("#1a1e26")), false)
	for wx in [-0.9, 0.9]:
		for wz in [-1.5, 1.5]:
			var w := cyl(p + Vector3(wx, 0.38, wz), 0.38, 0.25, Palette.color(Color("#151515")), false)
			w.rotation_degrees.z = 90.0
	item_spots.append(p + Vector3(0, 1.15, -1.6) if pickup else p + Vector3(1.1, 0.1, 0))


func _bounds() -> void:
	var b := BOUNDS
	var cx := b.position.x + b.size.x * 0.5
	var cz := b.position.z + b.size.z * 0.5
	for side in [[Vector3(cx, 5, b.position.z), Vector3(b.size.x, 12, 1)], [Vector3(cx, 5, b.end.z), Vector3(b.size.x, 12, 1)],
			[Vector3(b.position.x, 5, cz), Vector3(1, 12, b.size.z)], [Vector3(b.end.x, 5, cz), Vector3(1, 12, b.size.z)]]:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = side[1]
		cs.shape = sh
		sb.add_child(cs)
		add_child(sb)   # not under nav: don't bake these
		sb.position = side[0]
	# Distant hills so the horizon isn't empty
	for i in 24:
		var a := float(i) / 24.0 * TAU
		var r := 115.0
		var hm := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = _rng.randf_range(25, 45)
		sm.height = sm.radius * 0.8
		sm.radial_segments = 6
		sm.rings = 3
		hm.mesh = sm
		hm.material_override = Palette.color(Color("#0b0d12"))
		add_child(hm)
		hm.position = Vector3(-1 + cos(a) * r, -sm.radius * 0.35, 38 + sin(a) * r)
		hm.scale = Vector3(1.6, 0.6, 1.0)
